<?php
return [ 'SITE_NAME'=>'Dental World','AJAX_ROOT'=>'prescription']; 
?>
