<?php
echo is_writable(__DIR__) ? 'Writable' : 'Not Writable';
?>