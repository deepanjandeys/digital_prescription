<?php
use App\Http\Controllers\AdminController;
use App\Http\Controllers\CounterController;
use App\Http\Controllers\OperatorController;
use App\Http\Controllers\PatientController;
use App\Http\Controllers\AppointmentController;
use App\Http\Controllers\AdviceController;
use App\Http\Controllers\TreatmentController;
use App\Http\Controllers\TreatmentTypeController;
use App\Http\Controllers\IndexController;
use App\Http\Controllers\MedicalHistoryController;
use App\Http\Controllers\OralExaminationController;
use App\Http\Controllers\AjaxController;
use App\Http\Controllers\UserExportController;
//use App\Http\Controllers\PrescriptionController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {

        if (session()->has('ADMIN_LOGIN')) 
        {
            $typeName=session('typeName');
            if($typeName !='')
                return redirect($typeName.'/dashboard');
            else 
                return view('admin.login');
        }
        else
        {
           $result['type']=1; 
           return view('admin.login',$result);
        }
    
});
/*
Route::get('data', [IndexController::class,'index'])->middleware('gourd');
Route::get('group', [IndexController::class,'group'])->middleware('gourd');
*/
Route::get('aa', [AdminController::class,'aa']);
Route::get('data', [IndexController::class,'index']);
Route::get('group', [IndexController::class,'group']);
Route::get('/UserExport', [UserExportController::class,'export']);
Route::get('/BillExport', [BillController::class,'export']);
Route::get('/EMIExport', [EMICollectionController::class,'export']);
Route::get('no-access', function () {
    echo 'no access';
});
Route::get('login', function () 
{
    session()->put('user_id',1);
});
Route::group(['middleware'=>'admin_auth'],function()
    {
        Route::get('admin/dashboard', [AdminController::class,'dashboard']);
        Route::get('admin/profile', [AdminController::class,'profile']);
        Route::post('admin/personalDetailsChange', [AdminController::class,'personalDetailsChange'])->name('admin.personalDetailsChange');
        Route::get('admin/settings', [AdminController::class,'settings']);
        Route::post('admin/userDetailsChange', [AdminController::class,'userDetailsChange'])->name('admin.userDetailsChange');
////////////////////////////////////

        Route::get('admin/operator', [OperatorController::class,'list']);
        Route::get('admin/operator/edit_operator', [OperatorController::class,'edit_operator']);
        Route::get('admin/operator/edit_operator/{id}', [OperatorController::class,'edit_operator']);
        Route::get('admin/operator/delete/{id}', [OperatorController::class,'delete']);
        Route::get('admin/operator/trash', [OperatorController::class,'trash']);
        Route::get('admin/operator/forceDelete/{id}', [OperatorController::class,'forceDelete']);
        Route::get('admin/operator/restore/{id}', [OperatorController::class,'restore']);

        Route::get('admin/operator/status/{status}/{id}', [OperatorController::class,'status']);
        Route::post('admin/operator/manage_operator_process', [OperatorController::class,'manage_operator_process'])->name('admin.manage_operator_process');
////////////////////////////////////

        Route::get('admin/patient', [PatientController::class,'list']);
        Route::get('admin/patient/edit_patient', [PatientController::class,'edit_patient']);
        Route::get('admin/patient/edit_patient/{id}', [PatientController::class,'edit_patient']);
        Route::get('admin/patient/delete/{id}', [PatientController::class,'delete']);
        Route::get('admin/patient/trash', [PatientController::class,'trash']);
        Route::get('admin/patient/forceDelete/{id}', [PatientController::class,'forceDelete']);
        Route::get('admin/patient/restore/{id}', [PatientController::class,'restore']);

        Route::get('admin/patient/status/{status}/{id}', [PatientController::class,'status']);
        Route::post('admin/patient/manage_patient_process', [PatientController::class,'manage_patient_process'])->name('admin.manage_patient_process');
////////////////////////////////////

        Route::get('admin/appointment', [AppointmentController::class,'list']);
        Route::get('admin/appointment/edit_appointment', [AppointmentController::class,'edit_appointment']);
        Route::get('admin/appointment/edit_appointment/{id}', [AppointmentController::class,'edit_appointment']);
        Route::get('admin/appointment/delete/{id}', [AppointmentController::class,'delete']);
        Route::get('admin/appointment/trash', [AppointmentController::class,'trash']);
        Route::get('admin/appointment/forceDelete/{id}', [AppointmentController::class,'forceDelete']);
        Route::get('admin/appointment/restore/{id}', [AppointmentController::class,'restore']);

        Route::get('admin/appointment/status/{status}/{id}', [AppointmentController::class,'status']);
        Route::post('admin/appointment/manage_appointment_process', [AppointmentController::class,'manage_appointment_process'])->name('admin.manage_appointment_process');
        Route::post('/admin/appointment/update-status', [AppointmentController::class, 'updateStatus']);

//////////////////////////////////////

        Route::get('admin/treatment', [TreatmentController::class,'list']);
        Route::get('admin/treatment/edit_treatment', [TreatmentController::class,'edit_treatment']);
        Route::get('admin/treatment/edit_treatment/{id}', [TreatmentController::class,'edit_treatment']);
        Route::get('admin/treatment/delete/{id}', [TreatmentController::class,'delete']);
        Route::get('admin/treatment/trash', [TreatmentController::class,'trash']);
        Route::get('admin/treatment/forceDelete/{id}', [TreatmentController::class,'forceDelete']);
        Route::get('admin/treatment/restore/{id}', [TreatmentController::class,'restore']);

        Route::get('admin/treatment/status/{status}/{id}', [TreatmentController::class,'status']);
        Route::post('admin/treatment/manage_treatment_process', [TreatmentController::class,'manage_treatment_process'])->name('admin.manage_treatment_process');
        Route::get('admin/treatment/print_prescription/{id}', [TreatmentController::class,'print_prescription']);
////////////////////////////////////////////////////////////

        Route::get('admin/counter', [CounterController::class,'list']);
        Route::get('admin/counter/edit_counter', [CounterController::class,'edit_counter']);
        Route::get('admin/counter/edit_counter/{id}', [CounterController::class,'edit_counter']);
        Route::get('admin/counter/delete/{id}', [CounterController::class,'delete']);
        Route::get('admin/counter/trash', [CounterController::class,'trash']);
        Route::get('admin/counter/forceDelete/{id}', [CounterController::class,'forceDelete']);
        Route::get('admin/counter/restore/{id}', [CounterController::class,'restore']);

        Route::get('admin/counter/status/{status}/{id}', [CounterController::class,'status']);
        Route::post('admin/counter/manage_counter_process', [CounterController::class,'manage_counter_process'])->name('admin.manage_counter_process');
///////////////////////////////
        Route::get('admin/advice', [AdviceController::class,'index']);
        Route::get('admin/advice/edit_advice', [AdviceController::class,'edit_advice']);
        Route::get('admin/advice/edit_advice/{id}', [AdviceController::class,'edit_advice']);
        Route::get('admin/advice/delete/{id}', [AdviceController::class,'delete']);
        Route::get('admin/advice/trash', [AdviceController::class,'trash']);
        Route::get('admin/advice/forceDelete/{id}', [AdviceController::class,'forceDelete']);
        Route::get('admin/advice/restore/{id}', [AdviceController::class,'restore']);

        Route::get('admin/advice/status/{status}/{id}', [AdviceController::class,'status']);
        Route::post('admin/advice/manage_advice_process', [AdviceController::class,'manage_advice_process'])->name('admin.manage_advice_process');

//////////////////////////////////////////////////////////
//////////////////////////////////

        Route::get('admin/medicalHistory', [MedicalHistoryController::class,'index']);
        Route::get('admin/medicalHistory/edit_medicalHistory', [MedicalHistoryController::class,'edit_medicalHistory']);
        Route::get('admin/medicalHistory/edit_medicalHistory/{id}', [MedicalHistoryController::class,'edit_medicalHistory']);
        Route::get('admin/medicalHistory/delete/{id}', [MedicalHistoryController::class,'delete']);
        Route::get('admin/medicalHistory/trash', [MedicalHistoryController::class,'trash']);
        Route::get('admin/medicalHistory/forceDelete/{id}', [MedicalHistoryController::class,'forceDelete']);
        Route::get('admin/medicalHistory/restore/{id}', [MedicalHistoryController::class,'restore']);

        Route::get('admin/medicalHistory/status/{status}/{id}', [MedicalHistoryController::class,'status']);
        Route::post('admin/medicalHistory/manage_medicalHistory_process', [MedicalHistoryController::class,'manage_medicalHistory_process'])->name('admin.manage_medicalHistory_process');

////////////////////////////////////

        Route::get('admin/oralExamination', [OralExaminationController::class,'index']);
        Route::get('admin/oralExamination/edit_oralExamination', [OralExaminationController::class,'edit_oralExamination']);
        Route::get('admin/oralExamination/edit_oralExamination/{id}', [OralExaminationController::class,'edit_oralExamination']);
        Route::get('admin/oralExamination/delete/{id}', [OralExaminationController::class,'delete']);
        Route::get('admin/oralExamination/trash', [OralExaminationController::class,'trash']);
        Route::get('admin/oralExamination/forceDelete/{id}', [OralExaminationController::class,'forceDelete']);
        Route::get('admin/oralExamination/restore/{id}', [OralExaminationController::class,'restore']);

        Route::get('admin/oralExamination/status/{status}/{id}', [OralExaminationController::class,'status']);
        Route::post('admin/oralExamination/manage_oralExamination_process', [OralExaminationController::class,'manage_oralExamination_process'])->name('admin.manage_oralExamination_process');

        //////////////////////////////////

        Route::get('admin/treatmentType', [TreatmentTypeController::class,'index']);
        Route::get('admin/treatmentType/edit_treatmentType', [TreatmentTypeController::class,'edit_treatmentType']);
        Route::get('admin/treatmentType/edit_treatmentType/{id}', [TreatmentTypeController::class,'edit_treatmentType']);
        Route::get('admin/treatmentType/delete/{id}', [TreatmentTypeController::class,'delete']);
        Route::get('admin/treatmentType/trash', [TreatmentTypeController::class,'trash']);
        Route::get('admin/treatmentType/forceDelete/{id}', [TreatmentTypeController::class,'forceDelete']);
        Route::get('admin/treatmentType/restore/{id}', [TreatmentTypeController::class,'restore']);

        Route::get('admin/treatmentType/status/{status}/{id}', [TreatmentTypeController::class,'status']);
        Route::post('admin/treatmentType/manage_treatmentType_process', [TreatmentTypeController::class,'manage_treatmentType_process'])->name('admin.manage_treatmentType_process');
Route::get('/get-treatment-types', [TreatmentTypeController::class, 'getTreatmentTypes']);
////////////////////////////////////
/////////////////////////////////////////////////
//Route::get('/csrf',[AjaxController::class,'csrf'])->name('csrf');

////////////////////////////
    Route::get('admin/logout', function () {
            session()->forget('ADMIN_LOGIN');
            session()->forget('ADMIN_ID');
            session()->flash('error','logout successfully');
            return redirect('/');
    });
//Route::get('admin/category.insert', [CategoryController::class,'insert'])->name('category.insert');
    }
);
Route::get('admin', [AdminController::class,'index']);
Route::post('admin/auth', [AdminController::class,'auth'])->name('admin.auth');
//////////////////////
Route::post('forgetPassword', [AdminController::class,'forgetPassword'])->name('forget.password');
Route::get('forget_password/{type}', function ($type) 
{
        $result['type']=$type;
    return view('admin.forget_password',$result);
});
Route::get('forget_password_success/{id}',[AdminController::class,'forget_password_success']);
Route::get('ResetPassword/{id}', [AdminController::class,'password_reset']);
Route::post('ResetPassword/Set', [AdminController::class,'manage_password_reset'])->name('password_set');
Route::post('password_change', [AdminController::class,'password_change'])->name('password_change');
Route::get('password_change_success/{id}', [AdminController::class,'password_change_success']);
//////////////////
/*
Route::get('admin/changePassword/{id}', [AdminController::class,'reset']);         
*/
////////////////////
Route::get('/clear', function () {
Artisan::call('optimize:clear');
Artisan::call('route:clear');
Artisan::call('cache:clear');
Artisan::call('config:cache');
Artisan::call('config:clear');
Artisan::call('view:clear');
Artisan::call('storage:link', [] );
Artisan::call('storage:link');
Artisan::call('view:clear');
//Artisan::call('clear:compiled');
    echo "clear";
});

Route::post('/getCheckUserName',[AjaxController::class,'getCheckUserName'])->name('getCheckUserName');
Route::post('/getCheckMobileUnique',[AjaxController::class,'getCheckMobileUnique'])->name('getCheckMobileUnique');
Route::get('/search-patients', [AjaxController::class, 'searchPatients']);
Route::get('/search-appointment_dates', [AjaxController::class, 'searchAppointmentDates']);

Route::get('/get-medical-history', [AjaxController::class, 'getMedicalHistory']);
Route::post('/save-treatment-medical-history', [AjaxController::class, 'saveTreatmentMedicalHistory']);
Route::post('/delete-treatment-medical-history', [AjaxController::class, 'deleteTreatmentMedicalHistory']);
Route::get('/get-treatment-medical-histories/{treatmentId}', [AjaxController::class, 'getTreatmentMedicalHistories']);

Route::get('/get-oral-examination', [AjaxController::class, 'getOralExamination']);
Route::get('/get-treatment-oral-examinations/{treatmentId}', [AjaxController::class, 'getTreatmentOralExaminations']);
Route::post('/save-treatment-oral-examination', [AjaxController::class, 'saveTreatmentOralExamination']);
Route::post('/delete-treatment-oral-examination', [AjaxController::class, 'deleteTreatmentOralExamination']);
Route::get('/fetch-treatments/{patient_id}', [TreatmentController::class, 'fetchTreatments']);

/////////////
Route::get('/get-advice', [AjaxController::class, 'getAdvice']);
Route::post('/save-treatment-advice', [AjaxController::class, 'saveTreatmentAdvice']);
Route::post('/delete-treatment-advice', [AjaxController::class, 'deleteTreatmentAdvice']);
Route::get('/get-treatment-advices/{treatmentId}', [AjaxController::class, 'getTreatmentAdvices']);
///////////////////
Route::get('/get-medicines', [AjaxController::class, 'getMedicines']);
Route::post('/save-treatment-medicine', [AjaxController::class, 'saveTreatmentMedicine']);
Route::post('/save-treatment-medicines', [AjaxController::class, 'saveTreatmentMedicines']);


Route::post('/delete-treatment-medicine', [AjaxController::class, 'deleteTreatmentMedicine']);
Route::get('/get-treatment-medicines/{treatmentId}', [AjaxController::class, 'getTreatmentMedicines']);

Route::get('/generate-prescription/{treatmentId}', [PrescriptionController::class, 'generatePrescription']);

Route::group(['middleware'=>'operator_auth'],function()
{
////////////////////////////////////
        Route::get('operator/dashboard', [OperatorController::class,'dashboard']);
         Route::get('operator/profile', [AdminController::class,'profile']);
        Route::post('operator/personalDetailsChange', [AdminController::class,'personalDetailsChange'])->name('operator.personalDetailsChange');
        Route::get('operator/settings', [AdminController::class,'settings']);
        Route::post('operator/userDetailsChange', [AdminController::class,'userDetailsChange'])->name('operator.userDetailsChange');

    Route::get('operator/logout', function () {
            session()->forget('ADMIN_LOGIN');
            session()->forget('ADMIN_ID');
            session()->forget('ADMIN_TYPE');
            session()->forget('ADMIN_NAME');
            session()->forget('ADMIN_IMAGE');
            session()->forget('ADMIN_REFER_ID');
                        
            session()->flash('error','logout successfully');
            return redirect('operator');
    });
//////////////////////////
});
Route::get('operator', [OperatorController::class,'index']);
///////////////////

Route::group(['middleware'=>'counter_auth'],function()
{
/////////////////////////////////////
        Route::get('counter/dashboard', [CounterController::class,'dashboard']);
        Route::get('counter/profile', [AdminController::class,'profile']);
        Route::post('counter/personalDetailsChange', [AdminController::class,'personalDetailsChange'])->name('counter.personalDetailsChange');
        Route::get('counter/settings', [AdminController::class,'settings']);
        Route::post('counter/userDetailsChange', [AdminController::class,'userDetailsChange'])->name('counter.userDetailsChange');
       
////////////////////////////
    Route::get('counter/logout', function () {
            session()->forget('ADMIN_LOGIN');
            session()->forget('ADMIN_ID');
            session()->forget('ADMIN_TYPE');
            session()->forget('ADMIN_NAME');
            session()->forget('ADMIN_IMAGE');
            session()->forget('ADMIN_REFER_ID');
                        
            session()->flash('error','logout successfully');
            return redirect('counter');
    });
});

Route::get('counter', [CounterController::class,'index']);