<?php
use App\Http\Controllers\AdminController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\CounterController;
use App\Http\Controllers\OperatorController;
use App\Http\Controllers\PatientController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\AdviceController;
use App\Http\Controllers\BranchController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\BillController;
use App\Http\Controllers\IndexController;
use App\Http\Controllers\MedicalHistoryController;
use App\Http\Controllers\OralExaminationController;
use App\Http\Controllers\BranchStockController;
use App\Http\Controllers\BranchStockDetailsController;
use App\Http\Controllers\AjaxController;
use App\Http\Controllers\EMICollectionController;
use App\Http\Controllers\UserExportController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {

        if (session()->has('ADMIN_LOGIN')) 
        {
            $typeName=session('typeName');
            if($typeName !='')
                return redirect($typeName.'/dashboard');
            else 
                return view('admin.login');
        }
        else
        {
           $result['type']=1; 
           return view('admin.login',$result);
        }
    
});
/*
Route::get('data', [IndexController::class,'index'])->middleware('gourd');
Route::get('group', [IndexController::class,'group'])->middleware('gourd');
*/
Route::get('data', [IndexController::class,'index']);
Route::get('group', [IndexController::class,'group']);
Route::get('/UserExport', [UserExportController::class,'export']);
Route::get('/BillExport', [BillController::class,'export']);
Route::get('/EMIExport', [EMICollectionController::class,'export']);
Route::get('no-access', function () {
    echo 'no access';
});
Route::get('login', function () 
{
    session()->put('user_id',1);
});
Route::group(['middleware'=>'admin_auth'],function()
    {
        Route::get('admin/dashboard', [AdminController::class,'dashboard']);
        Route::get('admin/profile', [AdminController::class,'profile']);
        Route::post('admin/personalDetailsChange', [AdminController::class,'personalDetailsChange'])->name('admin.personalDetailsChange');
        Route::get('admin/settings', [AdminController::class,'settings']);
        Route::post('admin/userDetailsChange', [AdminController::class,'userDetailsChange'])->name('admin.userDetailsChange');
////////////////////////////////////

        Route::get('admin/operator', [OperatorController::class,'list']);
        Route::get('admin/operator/edit_operator', [OperatorController::class,'edit_operator']);
        Route::get('admin/operator/edit_operator/{id}', [OperatorController::class,'edit_operator']);
        Route::get('admin/operator/delete/{id}', [OperatorController::class,'delete']);
        Route::get('admin/operator/trash', [OperatorController::class,'trash']);
        Route::get('admin/operator/forceDelete/{id}', [OperatorController::class,'forceDelete']);
        Route::get('admin/operator/restore/{id}', [OperatorController::class,'restore']);

        Route::get('admin/operator/status/{status}/{id}', [OperatorController::class,'status']);
        Route::post('admin/operator/manage_operator_process', [OperatorController::class,'manage_operator_process'])->name('admin.manage_operator_process');
////////////////////////////////////

        Route::get('admin/patient', [PatientController::class,'list']);
        Route::get('admin/patient/edit_patient', [PatientController::class,'edit_patient']);
        Route::get('admin/patient/edit_patient/{id}', [PatientController::class,'edit_patient']);
        Route::get('admin/patient/delete/{id}', [PatientController::class,'delete']);
        Route::get('admin/patient/trash', [PatientController::class,'trash']);
        Route::get('admin/patient/forceDelete/{id}', [PatientController::class,'forceDelete']);
        Route::get('admin/patient/restore/{id}', [PatientController::class,'restore']);

        Route::get('admin/patient/status/{status}/{id}', [PatientController::class,'status']);
        Route::post('admin/patient/manage_patient_process', [PatientController::class,'manage_patient_process'])->name('admin.manage_patient_process');
//////////////////////////////////////////////////////////////////

        Route::get('admin/customer', [CustomerController::class,'index']);
        Route::get('admin/customer/edit_customer', [CustomerController::class,'edit_customer']);
        Route::get('admin/customer/edit_customer/{id}', [CustomerController::class,'edit_customer']);
        Route::get('admin/customer/delete/{id}', [CustomerController::class,'delete']);
        Route::get('admin/customer/trash', [CustomerController::class,'trash']);
        Route::get('admin/customer/forceDelete/{id}', [CustomerController::class,'forceDelete']);
        Route::get('admin/customer/restore/{id}', [CustomerController::class,'restore']);

        Route::get('admin/customer/status/{status}/{id}', [CustomerController::class,'status']);
        Route::get('admin/customer/approve/{approve}/{id}', [CustomerController::class,'approve']);
        Route::post('admin/customer/manage_customer_process', [CustomerController::class,'manage_customer_process'])->name('admin.manage_customer_process');
////////////////////////////////////////////////////////////////////////

        Route::get('admin/counter', [CounterController::class,'list']);
        Route::get('admin/counter/edit_counter', [CounterController::class,'edit_counter']);
        Route::get('admin/counter/edit_counter/{id}', [CounterController::class,'edit_counter']);
        Route::get('admin/counter/delete/{id}', [CounterController::class,'delete']);
        Route::get('admin/counter/trash', [CounterController::class,'trash']);
        Route::get('admin/counter/forceDelete/{id}', [CounterController::class,'forceDelete']);
        Route::get('admin/counter/restore/{id}', [CounterController::class,'restore']);

        Route::get('admin/counter/status/{status}/{id}', [CounterController::class,'status']);
        Route::post('admin/counter/manage_counter_process', [CounterController::class,'manage_counter_process'])->name('admin.manage_counter_process');
////////////////////////////////////////////////////////

        Route::get('admin/orders', [OrderController::class,'index']);
        Route::get('admin/order/edit_order', [OrderController::class,'edit_order']);
        Route::get('admin/order/edit_order/{id}', [OrderController::class,'edit_order']);
        Route::get('admin/order/delete/{id}', [OrderController::class,'delete']);
        Route::get('admin/order/trash', [OrderController::class,'trash']);
        Route::get('admin/order/forceDelete/{id}', [OrderController::class,'forceDelete']);
        Route::get('admin/order/restore/{id}', [OrderController::class,'restore']);

        Route::get('admin/order/status/{status}/{id}', [OrderController::class,'status']);
        Route::post('admin/order/manage_order_process', [OrderController::class,'manage_order_process'])->name('admin.manage_order_process');
/////////////////////////////////////////////////////////////////

        Route::get('admin/bills', [BillController::class,'index']);
        Route::get('admin/bill/edit_bill', [BillController::class,'edit_bill']);
        Route::get('admin/bill/edit_bill/{id}', [BillController::class,'edit_bill']);
        Route::get('admin/bill/print_bill/{id}', [BillController::class,'print_bill']);
        Route::get('admin/bill/print_bill_to_pdf/{id}', [BillController::class,'print_bill_to_pdf']);
        Route::get('admin/bill/edit_bill/{id}/{order_id?}', [BillController::class,'edit_bill']);
        Route::get('admin/bill/view_bill/{id}', [BillController::class,'view_bill']);
        Route::get('admin/bill/delete/{id}', [BillController::class,'delete']);
        Route::get('admin/bill/trash', [BillController::class,'trash']);
        Route::get('admin/bill/forceDelete/{id}', [BillController::class,'forceDelete']);
        Route::get('admin/bill/restore/{id}', [BillController::class,'restore']);

        Route::get('admin/bill/status/{status}/{id}', [BillController::class,'status']);
        Route::post('admin/bill/manage_bill_process', [BillController::class,'manage_bill_process'])->name('admin.manage_bill_process');
        Route::get('admin/bill/final_submit/{final_submit}/{id}', [BillController::class,'final_submit']);
        ////////////////////////////////
 Route::get('admin/advice', [AdviceController::class,'index']);
        Route::get('admin/advice/edit_advice', [AdviceController::class,'edit_advice']);
        Route::get('admin/advice/edit_advice/{id}', [AdviceController::class,'edit_advice']);
        Route::get('admin/advice/delete/{id}', [AdviceController::class,'delete']);
        Route::get('admin/advice/trash', [AdviceController::class,'trash']);
        Route::get('admin/advice/forceDelete/{id}', [AdviceController::class,'forceDelete']);
        Route::get('admin/advice/restore/{id}', [AdviceController::class,'restore']);

        Route::get('admin/advice/status/{status}/{id}', [AdviceController::class,'status']);
        Route::post('admin/advice/manage_advice_process', [AdviceController::class,'manage_advice_process'])->name('admin.manage_advice_process');

//////////////////////////////////////////////////////////////////

        Route::get('admin/medicalHistory', [MedicalHistoryController::class,'index']);
        Route::get('admin/medicalHistory/edit_medicalHistory', [MedicalHistoryController::class,'edit_medicalHistory']);
        Route::get('admin/medicalHistory/edit_medicalHistory/{id}', [MedicalHistoryController::class,'edit_medicalHistory']);
        Route::get('admin/medicalHistory/delete/{id}', [MedicalHistoryController::class,'delete']);
        Route::get('admin/medicalHistory/trash', [MedicalHistoryController::class,'trash']);
        Route::get('admin/medicalHistory/forceDelete/{id}', [MedicalHistoryController::class,'forceDelete']);
        Route::get('admin/medicalHistory/restore/{id}', [MedicalHistoryController::class,'restore']);

        Route::get('admin/medicalHistory/status/{status}/{id}', [MedicalHistoryController::class,'status']);
        Route::post('admin/medicalHistory/manage_medicalHistory_process', [MedicalHistoryController::class,'manage_medicalHistory_process'])->name('admin.manage_medicalHistory_process');

////////////////////////////////////

        Route::get('admin/oralExamination', [OralExaminationController::class,'index']);
        Route::get('admin/oralExamination/edit_oralExamination', [OralExaminationController::class,'edit_oralExamination']);
        Route::get('admin/oralExamination/edit_oralExamination/{id}', [OralExaminationController::class,'edit_oralExamination']);
        Route::get('admin/oralExamination/delete/{id}', [OralExaminationController::class,'delete']);
        Route::get('admin/oralExamination/trash', [OralExaminationController::class,'trash']);
        Route::get('admin/oralExamination/forceDelete/{id}', [OralExaminationController::class,'forceDelete']);
        Route::get('admin/oralExamination/restore/{id}', [OralExaminationController::class,'restore']);

        Route::get('admin/oralExamination/status/{status}/{id}', [OralExaminationController::class,'status']);
        Route::post('admin/oralExamination/manage_oralExamination_process', [OralExaminationController::class,'manage_oralExamination_process'])->name('admin.manage_oralExamination_process');
///////////////////////////////////////////////

        Route::get('admin/branchStock', [BranchStockController::class,'index']);
        Route::get('admin/branchStock/purchase', [BranchStockController::class,'purchase']); 
        Route::get('admin/branchStock/stockTransfer', [BranchStockController::class,'stockTransfer']);
        Route::post('admin/branchStock/manage_branchStock_process', [BranchStockController::class,'manage_branchStock_process'])->name('manage_branchStock_process');
        Route::post('admin/branchStock/manage_branchStock_transfer', [BranchStockController::class,'manage_branchStock_transfer'])->name('manage_branchStock_transfer');
////////////////////////////////////////////////

        Route::get('admin/branchStockDetails', [BranchStockDetailsController::class,'index']);
        Route::get('admin/emis/', [EMICollectionController
                ::class,'index']);
        Route::get('admin/emis/emi_collection/{id?}', [EMICollectionController::class,'emi_collection']);
        Route::post('admin/emis/manage_emi_collect', [EMICollectionController::class,'manage_emi_collect'])->name('admin.manage_emi_collect');
        Route::get('admin/emis/print_emi/{id}', [EMICollectionController::class,'print_emi']);
////////////////////////////////////////////////////////////
//Route::get('/csrf',[AjaxController::class,'csrf'])->name('csrf');

////////////////////////////
    Route::get('admin/logout', function () {
            session()->forget('ADMIN_LOGIN');
            session()->forget('ADMIN_ID');
            session()->flash('error','logout successfully');
            return redirect('/');
    });
//Route::get('admin/category.insert', [CategoryController::class,'insert'])->name('category.insert');
    }
);
Route::get('admin', [AdminController::class,'index']);
Route::post('admin/auth', [AdminController::class,'auth'])->name('admin.auth');
//////////////////////
Route::post('forgetPassword', [AdminController::class,'forgetPassword'])->name('forget.password');
Route::get('forget_password/{type}', function ($type) 
{
        $result['type']=$type;
    return view('admin.forget_password',$result);
});
Route::get('forget_password_success/{id}',[AdminController::class,'forget_password_success']);
Route::get('ResetPassword/{id}', [AdminController::class,'password_reset']);
Route::post('ResetPassword/Set', [AdminController::class,'manage_password_reset'])->name('password_set');
Route::post('password_change', [AdminController::class,'password_change'])->name('password_change');
Route::get('password_change_success/{id}', [AdminController::class,'password_change_success']);
//////////////////
/*
Route::get('admin/changePassword/{id}', [AdminController::class,'reset']);         
*/
////////////////////
Route::get('/clear', function () {
Artisan::call('optimize:clear');
Artisan::call('route:clear');
Artisan::call('cache:clear');
Artisan::call('config:cache');
Artisan::call('config:clear');
Artisan::call('view:clear');
Artisan::call('storage:link', [] );
Artisan::call('storage:link');
Artisan::call('view:clear');
//Artisan::call('clear:compiled');
    echo "clear";
});

    
Route::post('/getCustomerDetails',[AjaxController::class,'getCustomerDetails'])->name('getCustomerDetails');
Route::post('/getBookingDetails',[AjaxController::class,'getBookingDetails'])->name('getBookingDetails');
Route::post('/getSaleAgentDetails',[AjaxController::class,'getSaleAgentDetails'])->name('getSaleAgentDetails');
Route::post('/getProductDetails',[AjaxController::class,'getProductDetails'])->name('getProductDetails');

Route::post('/getBranchDetails',[AjaxController::class,'getBranchDetails'])->name('getBranchDetails');

Route::post('/getStockDetails',[AjaxController::class,'getStockDetails'])->name('getStockDetails');
Route::post('/getCheckMobileUnique',[AjaxController::class,'getCheckMobileUnique'])->name('getCheckMobileUnique');
Route::post('/setDefaultPasswordVA',[AjaxController::class,'setDefaultPasswordVA'])->name('setDefaultPasswordVA');
Route::post('/setDefaultPasswordSA',[AjaxController::class,'setDefaultPasswordSA'])->name('setDefaultPasswordSA');
Route::post('/getBillLastEMI',[AjaxController::class,'getBillLastEMI'])->name('getBillLastEMI');
Route::post('/calculate_emi_clear',[AjaxController::class,'calculate_emi_clear'])->name('calculate_emi_clear');
Route::post('/clearAllEMI',[AjaxController::class,'clearAllEMI'])->name('clearAllEMI');

Route::group(['middleware'=>'operator_auth'],function()
{
////////////////////////////////////
        Route::get('operator/dashboard', [OperatorController::class,'dashboard']);
         Route::get('operator/profile', [AdminController::class,'profile']);
        Route::post('operator/personalDetailsChange', [AdminController::class,'personalDetailsChange'])->name('operator.personalDetailsChange');
        Route::get('operator/settings', [AdminController::class,'settings']);
        Route::post('operator/userDetailsChange', [AdminController::class,'userDetailsChange'])->name('operator.userDetailsChange');

        Route::get('operator/customer', [CustomerController::class,'index']);
        Route::get('operator/customer/edit_customer', [CustomerController::class,'edit_customer']);
        Route::get('operator/customer/edit_customer/{id}', [CustomerController::class,'edit_customer']);
        Route::get('operator/customer/delete/{id}', [CustomerController::class,'delete']);
        Route::get('operator/customer/trash', [CustomerController::class,'trash']);
        Route::get('operator/customer/forceDelete/{id}', [CustomerController::class,'forceDelete']);
        Route::get('operator/customer/restore/{id}', [CustomerController::class,'restore']);
        /*
        Route::get('operator/customer/status/{status}/{id}', [CustomerController::class,'status']);
        Route::get('operator/customer/approve/{approve}/{id}', [CustomerController::class,'approve']);
        */
        Route::post('operator/customer/manage_customer_process', [CustomerController::class,'manage_customer_process'])->name('operator.manage_customer_process');
        Route::get('operator/village', [CounterController::class,'list']);
        Route::get('operator/village/edit_village', [CounterController::class,'edit_village']);
        Route::get('operator/village/edit_village/{id}', [CounterController::class,'edit_village']);
        Route::get('operator/village/delete/{id}', [CounterController::class,'delete']);
        Route::get('operator/village/trash', [CounterController::class,'trash']);
        Route::get('operator/village/forceDelete/{id}', [CounterController::class,'forceDelete']);
        Route::get('operator/village/restore/{id}', [CounterController::class,'restore']);

        Route::get('operator/village/status/{status}/{id}', [CounterController::class,'status']);
        Route::post('operator/village/manage_village_process', [CounterController::class,'manage_village_process'])->name('operator.manage_village_process');
        
        Route::post('operator/order/manage_order_process', [OrderController::class,'manage_order_process'])->name('operator.manage_order_process');

        Route::get('operator/Sales_Billing_Details', [OrderController::class,'Sales_Billing_Details']);

        Route::get('operator/order_success/{id}', [OrderController::class,'order_success']);
 
Route::get('operator/product_list', [ProductController::class,'product_list']);
Route::get('operator/order/place_order/{operator_id?}/{product_id?}', [OrderController::class,'place_order']);
Route::get('operator/orders/', [OrderController::class,'index']);
///////

Route::get('operator/order/edit_order', [OrderController::class,'edit_order']);
Route::get('operator/order/edit_order/{id}', [OrderController::class,'edit_order']);
Route::get('operator/order/delete/{id}', [OrderController::class,'delete']);
Route::get('operator/order/trash', [OrderController::class,'trash']);
Route::get('operator/order/forceDelete/{id}', [OrderController::class,'forceDelete']);
Route::get('operator/order/restore/{id}', [OrderController::class,'restore']);
///////////

Route::get('operator/bill/edit_bill', [BillController::class,'edit_bill']);
Route::get('operator/bill/edit_bill/{id}', [BillController::class,'edit_bill']);
Route::get('operator/bill/print_bill/{id}', [BillController::class,'print_bill']);
Route::get('operator/bill/view_bill/{id}', [BillController::class,'view_bill']);
Route::get('operator/bill/edit_bill/{id}/{order_id?}', [BillController::class,'edit_bill']);
Route::get('operator/bill/delete/{id}', [BillController::class,'delete']);
Route::get('operator/bill/trash', [BillController::class,'trash']);
Route::get('operator/bill/forceDelete/{id}', [BillController::class,'forceDelete']);
Route::get('operator/bill/restore/{id}', [BillController::class,'restore']);
Route::get('operator/bills/', [BillController::class,'index']);
 Route::post('operator/bill/manage_bill_process', [BillController::class,'manage_bill_process'])->name('operator.manage_bill_process');
 Route::get('operator/bill/final_submit/{final_submit}/{id}', [BillController::class,'final_submit']);
 Route::get('operator/emis/', [EMICollectionController::class,'index']);
 Route::get('operator/emis/emi_collection/{id?}', [EMICollectionController::class,'emi_collection']);
 Route::post('operator/emis/manage_emi_collect', [EMICollectionController::class,'manage_emi_collect'])->name('operator.manage_emi_collect');
 Route::get('operator/emis/receive', [EMICollectionController::class,'receive']);
 Route::post('operator/emis/manage_emi_receive', [EMICollectionController::class,'manage_emi_receive'])->name('operator.manage_emi_receive');

 Route::get('operator/emis/emi_submitted/{emi_id?}', [EMICollectionController::class,'emi_submitted']);
 Route::get('operator/emis/print_emi/{id}', [EMICollectionController::class,'print_emi']);
/*
Route::get('operator/EMI_calculator',[EMI_Calculation::class,'index'])->name('EMI_calculator');*/
////////////////////////////
    Route::get('operator/logout', function () {
            session()->forget('ADMIN_LOGIN');
            session()->forget('ADMIN_ID');
            session()->forget('ADMIN_TYPE');
            session()->forget('ADMIN_NAME');
            session()->forget('ADMIN_IMAGE');
            session()->forget('ADMIN_REFER_ID');
                        
            session()->flash('error','logout successfully');
            return redirect('operator');
    });
//////////////////////////
});
Route::get('operator', [OperatorController::class,'index']);

/*Route::get('operator/changePassword/{id}', [OperatorController::class,'reset']);

Route::get('operator/ResetPassword/{id}', [OperatorController::class,'operator_password_reset']);
Route::post('operator/ResetPassword/Set', [OperatorController::class,'manage_password_reset'])->name('operator.operator_password_set');
      
Route::get('operator/password_change_success/{id}', [OperatorController::class,'operator_password_change_success']);
*/  
///////////////////

Route::group(['middleware'=>'counter_auth'],function()
{
/////////////////////////////////////
        Route::get('counter/dashboard', [CounterController::class,'dashboard']);
        Route::get('counter/profile', [AdminController::class,'profile']);
        Route::post('counter/personalDetailsChange', [AdminController::class,'personalDetailsChange'])->name('counter.personalDetailsChange');
        Route::get('counter/settings', [AdminController::class,'settings']);
        Route::post('counter/userDetailsChange', [AdminController::class,'userDetailsChange'])->name('counter.userDetailsChange');
       /*
        Route::post('counter/password_change', [CounterController::class,'password_change'])->name('counter.password_change');
         
        Route::get('counter/password_change_success/{id}', [CounterController::class,'password_change_success']);
        */

        Route::get('counter/customer', [CustomerController::class,'index']);
        Route::get('counter/customer/edit_customer', [CustomerController::class,'edit_customer']);
        Route::get('counter/customer/edit_customer/{id}', [CustomerController::class,'edit_customer']);
        Route::get('counter/customer/delete/{id}', [CustomerController::class,'delete']);
        Route::get('counter/customer/trash', [CustomerController::class,'trash']);
        Route::get('counter/customer/forceDelete/{id}', [CustomerController::class,'forceDelete']);
        Route::get('counter/customer/restore/{id}', [CustomerController::class,'restore']);
        Route::post('counter/customer/manage_customer_process', [CustomerController::class,'manage_customer_process'])->name('counter.manage_customer_process');

        Route::post('counter/order/manage_order_process', [OrderController::class,'manage_order_process'])->name('counter.manage_order_process');

        Route::get('counter/Sales_Billing_Details', [OrderController::class,'Sales_Billing_Details']);

        Route::get('counter/order_success/{id}', [OrderController::class,'order_success']);
 
Route::get('counter/product_list', [ProductController::class,'product_list']);
Route::get('counter/order/place_order/{counter_id?}/{product_id?}', [OrderController::class,'place_order']);
Route::get('counter/orders/', [OrderController::class,'index']);
///////

Route::get('counter/order/place_order/{sale_agent_id?}/{product_id?}', [OrderController::class,'place_order']);

Route::get('counter/order/edit_order', [OrderController::class,'edit_order']);
Route::get('counter/order/edit_order/{id}', [OrderController::class,'edit_order']);
Route::get('counter/order/delete/{id}', [OrderController::class,'delete']);
Route::get('counter/order/trash', [OrderController::class,'trash']);
Route::get('counter/order/forceDelete/{id}', [OrderController::class,'forceDelete']);
Route::get('counter/order/restore/{id}', [OrderController::class,'restore']);
///////////

Route::get('counter/bill/edit_bill', [BillController::class,'edit_bill']);
Route::get('counter/bill/edit_bill/{id}', [BillController::class,'edit_bill']);
Route::get('counter/bill/print_bill/{id}', [BillController::class,'print_bill']);
Route::get('counter/bill/edit_bill/{id}/{order_id?}', [BillController::class,'edit_bill']);
Route::get('counter/bill/delete/{id}', [BillController::class,'delete']);
Route::get('counter/bill/trash', [BillController::class,'trash']);
Route::get('counter/bill/forceDelete/{id}', [BillController::class,'forceDelete']);
Route::get('counter/bill/restore/{id}', [BillController::class,'restore']);
Route::get('counter/bills/', [BillController::class,'index']);
 Route::post('counter/bill/manage_bill_process', [BillController::class,'manage_bill_process'])->name('counter.manage_bill_process');
 Route::get('counter/bill/final_submit/{final_submit}/{id}', [BillController::class,'final_submit']);
Route::get('counter/emis/', [EMICollectionController::class,'index']);
Route::get('counter/emis/emi_collection/{id?}', [EMICollectionController::class,'emi_collection']);
Route::post('counter/emis/manage_emi_collect', [EMICollectionController::class,'manage_emi_collect'])->name('counter.manage_emi_collect');
 Route::get('counter/emis/emi_submitted/{emi_id?}', [EMICollectionController::class,'emi_submitted']);
 Route::get('counter/emis/print_emi/{id}', [EMICollectionController::class,'print_emi']);
/*
Route::get('counter/EMI_calculator',[EMI_Calculation::class,'index'])->name('EMI_calculator');
*/
////////////////////////////
    Route::get('counter/logout', function () {
            session()->forget('ADMIN_LOGIN');
            session()->forget('ADMIN_ID');
            session()->forget('ADMIN_TYPE');
            session()->forget('ADMIN_NAME');
            session()->forget('ADMIN_IMAGE');
            session()->forget('ADMIN_REFER_ID');
                        
            session()->flash('error','logout successfully');
            return redirect('counter');
    });
});

Route::get('counter', [CounterController::class,'index']);
/*
Route::post('counter/forgetPassword', [CounterController::class,'forgetPassword'])->name('counter.forget.password');
Route::get('counter/forget_password', function () {
    return view('admin.forget_password');
});

Route::get('counter/changePassword/{id}', [CounterController::class,'reset']);

Route::get('counter/forget_password_success/{id}',[CounterController::class,'forget_password_success']);


Route::get('counter/ResetPassword/{id}', [CounterController::class,'counter_password_reset']);
Route::post('counter/ResetPassword/Set', [CounterController::class,'manage_password_reset'])->name('counter.counter_password_set');
        
Route::get('counter/password_change_success/{id}', [CounterController::class,'counter_password_change_success']);
*/