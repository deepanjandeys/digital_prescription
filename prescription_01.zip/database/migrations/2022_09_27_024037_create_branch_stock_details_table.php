<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBranchStockDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('branch_stock_details', function (Blueprint $table) {
            $table->id();
            $table->Integer('branch_id');
            $table->Integer('product_id');
            $table->smallInteger('qty');
            $table->Integer('current_stock');
            $table->tinyInteger('mode');
            $table->Integer('refer_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('branch_stock_details');
    }
}
