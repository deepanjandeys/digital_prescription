<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Log;
use DateTime; // Add this line to import DateTime
class Admin extends Model
{
    use HasFactory;

    public function setDateOfBirthAttribute($value)
    {
         // Log the incoming value for debugging
        Log::info('Date of Birth input:', ['value' => $value]);

        //$this->attributes['date_of_birth'] = date('Y-m-d',strtotime($value));
        if (!empty($value)) {
        // Convert the date if it's valid


        $date = DateTime::createFromFormat('d/m/Y', $value);
        $this->attributes['date_of_birth'] = $date ? $date->format('Y-m-d') : null;

        } else {
        // Set to null if the value is empty
        $this->attributes['date_of_birth'] = null;
        }

    }

    public function getDateOfBirthAttribute($value)
    {
        return date('d-m-Y',strtotime($value));   
    }
}
