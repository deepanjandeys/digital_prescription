<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Log;
use DateTime; // Add this line to import DateTime
class Appointment extends Model
{
    use HasFactory;
    use SoftDeletes;

    // Relationship to the User model where type is 2
    public function patient()
    {
        return $this->hasOne(Patient::class, 'id', 'patient_id');
    }

    public function treatment()
    {
        return $this->hasOne(Treatment::class, 'app_id', 'id');
    }

    public function setAppDateTimeAttribute($value)
    {
        
        if (!empty($value)) {
        // Convert the date if it's valid

        $date = DateTime::createFromFormat('d/m/Y h:i A', $value);
        $this->attributes['app_date_time'] = $date ? $date->format('Y-m-d H:i') : null;

        } else {
        // Set to null if the value is empty
        $this->attributes['app_date_time'] = null;
        }

    }

    public function getAppDateTimeAttribute($value)
    {
        return date('d-m-Y h:i:s A',strtotime($value));   
    }
/*
    public function getPatientImagePath()
    {
        if ($this->patient) {
            return $this->patient->ImagePath();
        }

        // Return a default image path if no patient is associated
        $siteUrl = config('app.url');
        return $siteUrl.'/storage/media/NoImage.png';
    }
    */
}