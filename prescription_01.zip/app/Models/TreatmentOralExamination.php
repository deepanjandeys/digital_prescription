<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class TreatmentOralExamination extends Model
{
    //public $timestamps = false;
    use HasFactory;
    use SoftDeletes;

    public function oral_examination() 
    {
        return $this->belongsTo(OralExamination::class, 'oral_examination_id', 'id'); 
    }
}
