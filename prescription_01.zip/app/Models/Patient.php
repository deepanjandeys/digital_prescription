<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Log;
use DateTime; // Add this line to import DateTime
class Patient extends Model
{
    use HasFactory;
    use SoftDeletes;

   public function ImagePath()
      { // used in edit Product
         $siteUrl = config('app.url');

        if(is_null($this->image) || $this->image=='')
        {
          return $siteUrl.'/storage/media/NoImage.png';
        }
      else if (file_exists( public_path() . '/storage/media/patients/'.$this->image)) {
         return $siteUrl.'/storage/media/patients/'.$this->image ;
      } 
      else 
      {
          return $siteUrl.'/storage/media/NoImage.png';
      }
    }
    
    /*
    public function getImageAttribute($value)
    { // used in list view
         $siteUrl = config('app.url');
         return $siteUrl;
       if(is_null($value))
        {
          return $siteUrl.'/storage/media/NoImage.png';
        }
      else if (file_exists( public_path() . '/storage/media/' . $value)) {
         return $value;
      } 
      else 
      {
          return $siteUrl.'/storage/media/NoImage.png';
      }
       // return date('d-m-Y',strtotime($value));   
    }
    */
    public function Users()
    {
       return $this->hasOne(User::class,'refer_id','id');
    }
    public function gender()
    {
       return $this->belongsTo(Gender::class,'gender_id','id');
    }
}
