<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class TreatmentAdvice extends Model
{
    //public $timestamps = false;
    use HasFactory;
    use SoftDeletes;
    protected $table="treatment_advices";
    public function advice() 
    {
        return $this->belongsTo(Advice::class, 'adviced_id', 'id'); 
    }
}
