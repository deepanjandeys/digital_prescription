<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use DateTime;

class Treatment extends Model
{
    use HasFactory;
    use SoftDeletes;

    // Relationship to Appointment model
    public function appointment()
    {
        return $this->hasOne(Appointment::class, 'id', 'app_id');
    }

    // Relationship to Patient model
    public function patient()
    {
        return $this->hasOne(Patient::class, 'id', 'patient_id');
    }

    public function nextAppointment()
    {
        return $this->hasOne(Appointment::class, 'id', 'NextAppId');
    }

    // Define other relationships
    public function treatment_medical_histories()
    {
        return $this->hasMany(TreatmentMedicalHistory::class, 'treatment_id', 'id');
    }

    public function treatment_oral_examinations()
    {
        return $this->hasMany(TreatmentOralExamination::class, 'treatment_id', 'id');
    }

    public function treatment_advices()
    {
        return $this->hasMany(TreatmentAdvice::class, 'treatment_id', 'id');
    }

    public function treatment_medicines()
    {
        return $this->hasMany(TreatmentMedicine::class, 'treatment_id', 'id');
    }

    // Relationship to TreatmentType model
    public function treatmentType()
    {
        return $this->belongsTo(TreatmentType::class, 'type', 'id');
    }

    // Mutators and Accessors for start_date_time and end_date_time
    public function setStartDateTimeAttribute($value)
    {
        if (!empty($value)) {
            $date = DateTime::createFromFormat('d/m/Y h:i A', $value);
            $this->attributes['start_date_time'] = $date ? $date->format('Y-m-d H:i') : null;
        } else {
            $this->attributes['start_date_time'] = null;
        }
    }

    public function getStartDateTimeAttribute($value)
    {
        return date('d-m-Y h:i:s A', strtotime($value));
    }

    public function setEndDateTimeAttribute($value)
    {
        if (!empty($value)) {
            $date = DateTime::createFromFormat('d/m/Y h:i A', $value);
            $this->attributes['end_date_time'] = $date ? $date->format('Y-m-d H:i') : null;
        } else {
            $this->attributes['end_date_time'] = null;
        }
    }

    public function getEndDateTimeAttribute($value)
    {
    return $value ? date('d-m-Y h:i:s A', strtotime($value)) : '';
    }
}
?>