<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    use HasFactory;
    protected $table = 'users';

    public function ImagePath()
    {
        $siteUrl = config('app.url');

        // Check if image is empty or null
        if (is_null($this->image) || $this->image == '') {
            return $siteUrl . '/storage/media/NoImage.png';  // Fallback to NoImage.png
        }

        // Debugging: Check what the image column holds
        $imageName = $this->image;
        
        // Build the public path to check if file exists
        $imagePath = public_path('storage/media/users/' . $imageName);

        // Check if the file exists
        if (file_exists($imagePath)) {
            return $siteUrl . '/storage/media/users/' . $imageName;  // Return the valid image path
        }

        // If file doesn't exist, fallback to 'NoImage.png'
        return $siteUrl . '/storage/media/NoImage.png';
    }
    /*
    public function getImageAttribute($value)
    { // used in list view
       if(is_null($value))
        {
          return '/NoImage.png';
        }
      else if (file_exists( public_path() . '/storage/media/' . $value)) {
         return $value;
      } 
      else 
      {
          return 'NoImage.png';
      }
       // return date('d-m-Y',strtotime($value));   
    }
*/
    // Relation to Counter based on refer_id and type 3
    public function counter()
    {
        return $this->hasOne(Counter::class, 'id', 'refer_id')->where('type', 3);
    }

    // Relation to Operator based on refer_id and type 2
    public function operator()
    {
        return $this->hasOne(Operator::class, 'id', 'refer_id')->where('type', 2);
    }
}
