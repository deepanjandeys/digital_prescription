<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Log;
use DateTime; // Add this line to import DateTime
class TreatmentMedicine extends Model
{
    use HasFactory;
    use SoftDeletes;
    protected $table = 'treatment_medicines';

    protected $fillable = [
    'treatment_id', 
    'medicine_id', 
    'Dosage', 
    'frequency', 
    'duration_quantity', 
    'duration_unit',
    'timing'
];


    public function medicine() 
    {
        return $this->belongsTo(Medicine::class, 'medicine_id', 'id'); 
    }

    public function getDosageArrayAttribute()
    {
        return [
            'morning' => $this->dosage[0] == '1',
            'noon' => $this->dosage[1] == '1',
            'night' => $this->dosage[2] == '1',
        ];
    }

    // Mutator to set the dosage as a combined string
    public function setDosageArrayAttribute($value)
    {
        $this->attributes['dosage'] = ($value['morning'] ? '1' : '0') .
                                      ($value['noon'] ? '1' : '0') .
                                      ($value['night'] ? '1' : '0');
    }
}