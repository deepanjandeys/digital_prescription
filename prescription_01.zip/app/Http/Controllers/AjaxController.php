<?php
 
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Admin;
use App\Models\Patient;
use App\Models\Appointment;
use App\Models\TreatmentMedicine;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use DateTime; // Add this line to import DateTime
class AjaxController extends Controller
{
   
public function getCheckUserName(Request $request) 
    {
        $found='0'; $message='';
        $name=$request['name']; 
        $id=$request['id'];

        $query = DB::select( DB::raw("SELECT `type` FROM `users` WHERE `name` ='".$name."' AND `id` !=$id"));

        if($query!=null)  
        {
         $type=$query[0]->type;
         $found='1';

         if($type=='1')
            $message='User created with this User name';
         else if($type=='2')
            $message='already Operator created with this name '.$name;
          else if($type=='3')
            $message='already Counter account created with this '.$name;
        }
      return response()->json(['message' => $message,'found'=>$found]);
   }


public function getCheckMobileUnique(Request $request) 
    {
        $found='0'; $message='';
        $mobile=$request['mobile']; 
        $type=$request['type'];
        $id=$request['id'];
        $idStr='';
        if($id>0)
            $idStr=" and `id`<>$id";
        if($type==1)
        {
            $query = DB::select( DB::raw("SELECT `first_name`, `last_name` FROM `admins` WHERE `mobile` ='".$mobile."' $idStr"));

        }
        else if($type==2)
        {
        $query = DB::select( DB::raw("SELECT `first_name`, `last_name` FROM `operators` WHERE `mobile` ='".$mobile."' $idStr"));

        }
        else if($type==3)
        {
            $query = DB::select( DB::raw("SELECT `first_name`, `last_name` FROM `counters` WHERE `mobile` ='".$mobile."' $idStr"));

        }
        else if($type==4)
        {
            $query = DB::select( DB::raw("SELECT `first_name`, `last_name` FROM `patients` WHERE `mobile` ='".$mobile."' $idStr"));

        }
       // Log::info($_POST,['id'=>$id]);
        if($query!=null)  
        {
         $first_name=$query[0]->first_name;
         $last_name=$query[0]->last_name;
         $found='1';

         if($type=='1')
            $message='Admin created with this name '.$first_name.' '.$last_name;
         else if($type=='2')
            $message='already Operator account created with this name '.$first_name.' '.$last_name;
        else if($type=='3')
            $message='already Counter account created with this name '.$first_name.' '.$last_name;
          else if($type=='4')
            $message='already Patient account created with this name '.$first_name.' '.$last_name;
        }
      return response()->json(['message' => $message,'found'=>$found]);
   }
public function csrf()
{
     return csrf_token(); 
}

public function searchPatients(Request $request)
{
    $search = $request->input('query');
    $city = $request->input('city');
    $state = $request->input('state');

    // Search for patients by first name, last name, address, or mobile, and filter by city/state if provided
    $patients = Patient::where(function ($query) use ($search) {
                            $query->where('first_name', 'LIKE', "%{$search}%")
                                  ->orWhere('last_name', 'LIKE', "%{$search}%")
                                  ->orWhere('address', 'LIKE', "%{$search}%")
                                  ->orWhere('mobile', 'LIKE', "%{$search}%");
                            if (preg_match('/\d+/', $search, $matches)) {
                            $id = $matches[0]; // Get the numeric part
                            $query->orWhere('registration_number', 'LIKE', "DW{$id}") // Match full reg. no.
                                  ->orWhere('id', $id); // Match only the ID
                            }

                        })
                        ->when($city, function ($query, $city) {
                            return $query->where('city', $city);
                        })
                        ->when($state, function ($query, $state) {
                            return $query->where('state', $state);
                        })
                        ->take(5)
                        ->get();
    // Return the search results as JSON
    return response()->json($patients);
}


public function searchAppointmentDates(Request $request)
{
    $date = $request->input('date');
    $date = DateTime::createFromFormat('d/m/Y', $date);
    $date = $date ? $date->format('Y-m-d') : null;

    if ($date) {
        $appointments = Appointment::with('patient')
        ->whereDate('app_date_time', $date)
        ->orderBy('app_date_time','ASC')->get();
    } else {
        $appointments = collect(); // empty collection if date is not provided
    }
//Log::info($appointments,['date'=>$date]);
    // Return the search results as JSON
    return response()->json($appointments);
}

public function getMedicalHistory(Request $request)
{
    $term = $request->get('term', '');
    
    $medicalHistories = DB::table('medical_histories')
        ->where('MedicalHistory', 'LIKE', '%' . $term . '%')
        ->get(['id', 'MedicalHistory']); // Select the matching entries

    return response()->json($medicalHistories); // Return the result as JSON
}

public function saveTreatmentMedicalHistory(Request $request)
{
    // Validate request
    $request->validate([
        'treatment_id' => 'required|integer',
        'medical_history_id' => 'required|integer',
    ]);

    // Create new entry in treatment_medical_histories
    DB::table('treatment_medical_histories')->insert([
        'treatment_id' => $request->input('treatment_id'),
        'medical_history_id' => $request->input('medical_history_id'),
        'created_at' => now(),
        'updated_at' => now()
    ]);

    return response()->json(['success' => true, 'message' => 'Medical history saved successfully']);
}

public function deleteTreatmentMedicalHistory(Request $request)
{
    // Validate request
    $request->validate([
        'treatment_id' => 'required|integer',
        'medical_history_id' => 'required|integer',
    ]);

    // Delete the entry from treatment_medical_histories
    DB::table('treatment_medical_histories')
        ->where('treatment_id', $request->input('treatment_id'))
        ->where('medical_history_id', $request->input('medical_history_id'))
        ->delete();

    return response()->json(['success' => true, 'message' => 'Medical history removed successfully']);
}

public function getTreatmentMedicalHistories($treatmentId)
{
    // Fetch all medical histories related to the treatment from the treatment_medical_histories table
    $medicalHistories = DB::table('treatment_medical_histories')
        ->join('medical_histories', 'treatment_medical_histories.medical_history_id', '=', 'medical_histories.id')
        ->where('treatment_medical_histories.treatment_id', $treatmentId)
        ->select('medical_histories.id', 'medical_histories.MedicalHistory')
        ->get();

    // Return the result as JSON
    return response()->json($medicalHistories);
}

////////////
public function getOralExamination(Request $request)
{
    $term = $request->get('term', '');
    
    $oralExaminations = DB::table('oral_examinations')
        ->where('OralExamination', 'LIKE', '%' . $term . '%')
        ->get(['id', 'OralExamination']); // Select the matching entries

    return response()->json($oralExaminations); // Return the result as JSON
}

public function saveTreatmentOralExamination(Request $request)
{
    // Validate request
    $request->validate([
        'treatment_id' => 'required|integer',
        'oral_examination_id' => 'required|integer',
    ]);

    // Create new entry in treatment_oral_examinations
    DB::table('treatment_oral_examinations')->insert([
        'treatment_id' => $request->input('treatment_id'),
        'oral_examination_id' => $request->input('oral_examination_id'),
        'created_at' => now(),
        'updated_at' => now()
    ]);

    return response()->json(['success' => true, 'message' => 'Oral Examination saved successfully']);
}

public function deleteTreatmentOralExamination(Request $request)
{
    // Validate request
    $request->validate([
        'treatment_id' => 'required|integer',
        'oral_examination_id' => 'required|integer',
    ]);

    // Delete the entry from treatment_oral_examinations
    DB::table('treatment_oral_examinations')
        ->where('treatment_id', $request->input('treatment_id'))
        ->where('oral_examination_id', $request->input('oral_examination_id'))
        ->delete();

    return response()->json(['success' => true, 'message' => 'Oral Examination removed successfully']);
}

public function getTreatmentOralExaminations($treatmentId)
{
    // Fetch all oralExaminations related to the treatment
    $oralExaminations = DB::table('treatment_oral_examinations')
        ->join('oral_examinations', 'treatment_oral_examinations.oral_examination_id', '=', 'oral_examinations.id')
        ->where('treatment_oral_examinations.treatment_id', $treatmentId)
        ->select('oral_examinations.id', 'oral_examinations.OralExamination')
        ->get();

    // Return the result as JSON
    return response()->json($oralExaminations);
}
////////////////////
public function getAdvice(Request $request)
{
    $term = $request->get('term', '');
    
    $advices = DB::table('advice')
        ->where('Advice', 'LIKE', '%' . $term . '%')
        ->get(['id', 'Advice']); // Select the matching entries

    return response()->json($advices); // Return the result as JSON
}

public function saveTreatmentAdvice(Request $request)
{
    // Validate request
    $request->validate([
        'treatment_id' => 'required|integer',
        'adviced_id' => 'required|integer',
    ]);

    // Create new entry in treatment_advices
    DB::table('treatment_advices')->insert([
        'treatment_id' => $request->input('treatment_id'),
        'adviced_id' => $request->input('adviced_id'),
        'created_at' => now(),
        'updated_at' => now()
    ]);

    return response()->json(['success' => true, 'message' => 'Advice saved successfully']);
}

public function deleteTreatmentAdvice(Request $request)
{
    // Validate request
    $request->validate([
        'treatment_id' => 'required|integer',
        'adviced_id' => 'required|integer',
    ]);

    // Delete the entry from treatment_advices
    DB::table('treatment_advices')
        ->where('treatment_id', $request->input('treatment_id'))
        ->where('adviced_id', $request->input('adviced_id'))
        ->delete();

    return response()->json(['success' => true, 'message' => 'Advice removed successfully']);
}

public function getTreatmentAdvices($treatmentId)
{
    // Fetch all advices related to the treatment
    $advices = DB::table('treatment_advices')
        ->join('advice', 'treatment_advices.adviced_id', '=', 'advice.id')
        ->where('treatment_advices.treatment_id', $treatmentId)
        ->select('advice.id', 'advice.Advice')
        ->get();

    // Return the result as JSON
    return response()->json($advices);
}

public function getMedicines(Request $request)
{
    $term = $request->input('term');
    $medicines = DB::table('medicine')
        ->where('Medicine', 'LIKE', '%' . $term . '%')
        ->get(); 
    return response()->json($medicines);
}

public function saveTreatmentMedicines(Request $request) 
{
    $treatment_id = $request->input('treatment_id');
    $medicines = $request->input('medicines');

    // Permanently delete all existing records for this treatment_id
    TreatmentMedicine::where('treatment_id', $treatment_id)->forceDelete();

    foreach ($medicines as $medicine) {
        $dosage = json_encode([
            'morning' => $medicine['dosage']['morning'],
            'noon' => $medicine['dosage']['noon'],
            'night' => $medicine['dosage']['night'],
        ]);

        $frequency = (int)$medicine['frequency'];
        $duration_quantity = isset($medicine['duration_quantity']) ? (int)$medicine['duration_quantity'] : null;
        $duration_unit = isset($medicine['duration_unit']) ? (int)$medicine['duration_unit'] : null;
        $timing = isset($medicine['timing']) ? (int)$medicine['timing'] : null; // 0 for before food by default

        // Create a new record for each medicine
        TreatmentMedicine::create([
            'treatment_id' => $treatment_id,
            'medicine_id' => $medicine['medicine_id'],
            'Dosage' => $dosage,
            'frequency' => $frequency,
            'duration_quantity' => $duration_quantity,
            'duration_unit' => $duration_unit,
            'timing' => $timing,
        ]);
    }

    return response()->json(['success' => 'Medicines saved successfully']);
}

public function deleteTreatmentMedicine(Request $request)
{
    $request->validate([
        'treatment_id' => 'required|integer',
        'medicine_id' => 'required|integer',
    ]);

    DB::table('treatment_medicines')
        ->where('treatment_id', $request->treatment_id)
        ->where('medicine_id', $request->medicine_id)
        ->delete();

    return response()->json(['status' => 'deleted']);
}

public function getTreatmentMedicines($treatmentId)
{
    $medicines = DB::table('treatment_medicines')
        ->join('medicine', 'medicine.id', '=', 'treatment_medicines.medicine_id')
        ->where('treatment_medicines.treatment_id', $treatmentId)
        ->select(
            'treatment_medicines.id as treatment_medicine_id',
            'medicine.Medicine',
            'medicine.id as medicine_id',
            'treatment_medicines.Dosage',
            'treatment_medicines.frequency', 
            'treatment_medicines.duration_quantity',
            'treatment_medicines.duration_unit',
            'treatment_medicines.timing',
        )
        ->orderBy('treatment_medicines.id', 'asc')
        ->get()
        ->map(function ($item) {
            $item->Dosage = json_decode($item->Dosage);
            return $item;
        });

    return response()->json($medicines);
}

}
