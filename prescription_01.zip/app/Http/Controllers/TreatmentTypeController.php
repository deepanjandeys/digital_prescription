<?php

namespace App\Http\Controllers;
use App\Models\TreatmentType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TreatmentTypeController extends Controller
{
     public function index(Request $request)
    {
        $search=$request['search'] ?? "";
        if($search !="")
        {
$TreatmentType = TreatmentType::where(function ($query) use ($search){
                $query->where('TreatmentType', 'like', '%'.$search.'%');
            })
            ->latest()->simplepaginate(10);
        }
        else
        {   
$TreatmentType  = TreatmentType::latest()->simplepaginate(10);
        }
        $result = compact('TreatmentType','search');
        return view('admin.treatmentType',$result); 
    }
    
     public function trash()
    {
        $result['data'] =   TreatmentType::onlyTrashed()->get();
        return view('admin.treatmentType-trash',$result); 
    }

    public function edit_treatmentType(Request $request,$id='')
    {
        if ($id>0) 
        {
            $arr = TreatmentType::where(['id'=>$id])->get();
            $result['id']= $arr[0]->id;
            $result['TreatmentType']= $arr[0]->TreatmentType;
        }
        else
        {
            $result['id']='0';
            $result['TreatmentType']='';
        }
       return view('admin.edit_TreatmentType',$result); 
    }

public function manage_treatmentType_process(Request $request)
    { 
       $request->validate([
        'TreatmentType'=>'required|unique:treatment_types,TreatmentType,'.$request->post('id'),
       ]
       ); 
       if ($request->post('id')>0) 
       {
           $model = TreatmentType::find($request->post('id'));
           $msg = 'TreatmentType updated';
       }
       else
       {
            $model = new TreatmentType();
            $msg = 'TreatmentType Inserted';
       }
       
       $model->TreatmentType = $request->post('TreatmentType');
       $model->save();
       $request->session()->flash('message',$msg);
       return redirect('admin/treatmentType');
    }

   public function delete(Request $request,$id)
    {
       $message='';
/*
       $customers=Customer::where('TreatmentType','=',$id)->get();
       $c=count($customers);
       if($c>0)
       {
            $message = $c.' Customer(s) ';
       }

       $villageAgents =VillageAgent::where('TreatmentType','=',$id)->get();

       $c=count($villageAgents);
       if($c>0)
       {
            $message .=' and '.$c.' Village Agent(s) ';
       }
       

       $salesAgents =SalesAgent::where('TreatmentType','=',$id)->get();

       $c=count($salesAgents);
       if($c>0)
       {
            $message .=' and '.$c.' Sale Agents(s) ';
       }
  */     
       $typeName=session()->get('typeName');
       
       if($message =='')
       {
        $model = TreatmentType::find($id);
        $model->delete();
        return redirect($typeName.'/treatmentType')->with('message','TreatmentType deleted'); 
       }
       else 
       {
        return redirect($typeName.'/treatmentType')->with('error','Unable to delete as '.$message.' linked with this TreatmentType');
       }

    }

    public function forceDelete(Request $request,$id)
    {
       
       $model = TreatmentType::withTrashed()->find($id);
       $model->forceDelete();
       $request->session()->flash('message','TreatmentType permantly deleted');
       return redirect('admin/treatmentType/trash');
    }

    public function restore(Request $request,$id)
    {
       
       $model = TreatmentType::withTrashed()->find($id);
       $model->restore();
       $request->session()->flash('message','TreatmentType Restored');
       return redirect('admin/treatmentType/trash');
    }

    public function status(Request $request,$status,$id)
    {
       
       $model = TreatmentType::find($id);
       $model->status = $status;
       $model->save();
       $request->session()->flash('message','TreatmentType status changed');
       return redirect('admin/TreatmentType');
    }

    public function getTreatmentTypes()
    {
    $treatmentTypes = TreatmentType::select('id','TreatmentType')->get();
    return response()->json($treatmentTypes);
    }
}
