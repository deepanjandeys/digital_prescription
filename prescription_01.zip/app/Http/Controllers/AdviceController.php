<?php

namespace App\Http\Controllers;
use App\Models\Advice;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdviceController extends Controller
{
     public function index(Request $request)
    {
        $search=$request['search'] ?? "";
        if($search !="")
        {
$Advice = Advice::where(function ($query) use ($search){
                $query->where('Advice', 'like', '%'.$search.'%');
            })
            ->latest()->simplepaginate(10);
        }
        else
        {   
$Advice  = Advice::latest()->simplepaginate(10);
        }
        $result = compact('Advice','search');
        return view('admin.advice',$result); 
    }
    
     public function trash()
    {
        $result['data'] =   Advice::onlyTrashed()->get();
        return view('admin.advice-trash',$result); 
    }

    public function edit_advice(Request $request,$id='')
    {
        if ($id>0) 
        {
            $arr = Advice::where(['id'=>$id])->get();
            $result['id']= $arr[0]->id;
            $result['Advice']= $arr[0]->Advice;
        }
        else
        {
            $result['id']='0';
            $result['Advice']='';
        }
       return view('admin.edit_Advice',$result); 
    }

public function manage_advice_process(Request $request)
    { 
       $request->validate([
        'Advice'=>'required|unique:advice,Advice,'.$request->post('id'),
       ]
       ); 
       if ($request->post('id')>0) 
       {
           $model = Advice::find($request->post('id'));
           $msg = 'Advice updated';
       }
       else
       {
            $model = new Advice();
            $msg = 'Advice Inserted';
       }
       
       $model->Advice = $request->post('Advice');
       $model->save();
       $request->session()->flash('message',$msg);
       return redirect('admin/advice');
    }

   public function delete(Request $request,$id)
    {
       $message='';
/*
       $customers=Customer::where('Advice','=',$id)->get();
       $c=count($customers);
       if($c>0)
       {
            $message = $c.' Customer(s) ';
       }

       $villageAgents =VillageAgent::where('Advice','=',$id)->get();

       $c=count($villageAgents);
       if($c>0)
       {
            $message .=' and '.$c.' Village Agent(s) ';
       }
       

       $salesAgents =SalesAgent::where('Advice','=',$id)->get();

       $c=count($salesAgents);
       if($c>0)
       {
            $message .=' and '.$c.' Sale Agents(s) ';
       }
  */     
       $typeName=session()->get('typeName');
       
       if($message =='')
       {
        $model = Advice::find($id);
        $model->delete();
        return redirect($typeName.'/advice')->with('message','Advice deleted'); 
       }
       else 
       {
        return redirect($typeName.'/advice')->with('error','Unable to delete as '.$message.' linked with this Advice');
       }

    }

    public function forceDelete(Request $request,$id)
    {
       
       $model = Advice::withTrashed()->find($id);
       $model->forceDelete();
       $request->session()->flash('message','Advice permantly deleted');
       return redirect('admin/advice/trash');
    }

    public function restore(Request $request,$id)
    {
       
       $model = Advice::withTrashed()->find($id);
       $model->restore();
       $request->session()->flash('message','Advice Restored');
       return redirect('admin/advice/trash');
    }

    public function status(Request $request,$status,$id)
    {
       
       $model = Advice::find($id);
       $model->status = $status;
       $model->save();
       $request->session()->flash('message','Advice status changed');
       return redirect('admin/Advice');
    }
}
