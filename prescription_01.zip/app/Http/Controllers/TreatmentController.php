<?php

namespace App\Http\Controllers;

use App\Models\Treatment;
use App\Models\User; 
use App\Models\Appointment;
use App\Models\Patient;
use App\Models\TreatmentType;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use DateTime; // Add this line to import DateTime
use \PDF;
class TreatmentController extends Controller
{
    public function index(Request $request)
    {
        if ($request->session()->has('ADMIN_LOGIN')) 
        {            
            return redirect('treatment/dashboard');
        }
        else
        {
           $result['type']=4;
           return view('admin.login',$result);
        }

    }
   
public function list(Request $request)
{
    $search = $request->input('search', '');  // Fetch search input, defaulting to an empty string
    $start_date_src = $request->input('start_date_src', ''); // Fetch app_date input, defaulting to an empty string
    $start_date = DateTime::createFromFormat('d/m/Y', $start_date_src);
    $start_date = $start_date ? $start_date->format('Y-m-d') : null;
    // Query the Treatment model
    $treatmentQuery = Treatment::with('patient')  // Eager load related patients
        ->when($start_date, function ($query, $start_date) {
            // Filter by treatment date if the start_date is provided
            // Use `whereDate` to compare only the date portion of `start_date_time`
            return $query->whereDate('start_date_time', '=', date('Y-m-d', strtotime($start_date)));
        })
        ->when($search, function ($query, $search) {
            // Filter by related patient details (first_name, last_name, address, or mobile)
            return $query->whereHas('patient', function ($patientQuery) use ($search) {
                $patientQuery->where('first_name', 'like', '%' . $search . '%')
                    ->orWhere('last_name', 'like', '%' . $search . '%')
                    ->orWhere('address', 'like', '%' . $search . '%')
                    ->orWhere('mobile', 'like', '%' . $search . '%');
            });
        })
        ->latest();

    // Paginate the results
    $treatments = $treatmentQuery->simplePaginate(10);

    // Return results to the view
    return view('admin.treatment', compact('treatments', 'search', 'start_date_src'));
}

     public function trash()
    {
        $result['data'] =   Treatment::onlyTrashed()->get();
        $result['statuses'] = DB::table('status')->get(); 
        return view('admin.treatment-trash',$result); 
    }

    public function edit_treatment(Request $request,$id='')
    {
        if ($id>0) 
        {
            $treatment = Treatment::where(['id'=>$id])->get()->first();
            $patient = Patient::where(['id'=>$treatment->patient_id])->get()->first();

            $result['app_date_time']= $treatment->appointment->app_date_time;
            $result['app_time'] = $treatment->appointment->app_date_time;

            $result['start_date_time']= $treatment->start_date_time;
            $result['start_time'] = $treatment->start_date_time;

            $result['end_date_time']= $treatment->end_date_time;
            $result['end_time'] = $treatment->end_date_time;

            $result['purpose'] = $treatment->purpose;
            //Carbon::parse($treatment->app_date_time)->format('h:i A');
            $result['id']= $treatment->id;
            $result['patient_id']= $patient->id;
            $result['first_name']= $patient->first_name;
            $result['last_name']= $patient->last_name;
            //$result['imagePath']=$patient->ImagePath();
            //$result['image']= $patient->image;
            $result['mobile']= $patient->mobile;
            $result['address']= $patient->address;
            $result['pin']= $patient->pin;
            $result['gender']= $patient->gender;
            $result['city']= $patient->city;
            $result['state']= $patient->state;
            $result['country']= $patient->country;
            $result['age']= $patient->age;
            $result['gender']= $patient->gender['name'];
            $result['Height']= $patient->Height;
            $result['Weight']= $patient->Weight;
            $result['BP']= $patient->BP;
            $result['Pulse']= $patient->Pulse;
            $result['BMI']= $patient->BMI;
            $result['WC']= $patient->WC;
            $result['email']= $patient->email;
            $result['status']= $treatment->status;
            $result['isApproved']= $patient->isApproved;
            $result['type']= $treatment->type;
            $result['teeth_UL']= $treatment->teeth_UL;
            $result['teeth_UR']= $treatment->teeth_UR;
            $result['teeth_LL']= $treatment->teeth_LL;
            $result['teeth_LR']= $treatment->teeth_LR;
            $result['teeth_exam']= $treatment->teeth_exam;
            $result['remarks']= $treatment->remarks;
            $result['NextAppId']= $treatment->NextAppId;
    $result['next_appointment_date']= $treatment->nextAppointment?->app_date_time;
    $result['NextAppointment_time']= $treatment->nextAppointment?->app_date_time;
        }
        else
        {
            /*
            $result['app_date_time']='';
            $result['app_time']='';
            $result['purpose'] ='';
            $result['id']= '0';
            $result['patient_id'] = '0';
            $result['first_name'] = '';
            $result['last_name'] = '';
            $result['mobile']= '';
            $result['email']= '';
            $result['password']= '';
            //$result['imagePath']=asset('storage/media/NoImage.png');
            $result['image']='';
            $result['address']= '';
            $result['pin']= '';
            $result['gender']= '';
            $result['city']= '';
            $result['state']= '';
            $result['country']= '';
            $result['age']= '';
            $result['Height']= '';
            $result['Weight']= '';
            $result['BP']= '';
            $result['Pulse']= '';
            $result['BMI']= '';
            $result['WC']= '';
            $result['isApproved']=1;
            $result['status']= '1';
            $result['type']=0;
            $result['teeth_UL']= "";
            $result['teeth_UR']= "";
            $result['teeth_LL']= "";
            $result['teeth_UR']= "";
            $result['teeth_exam']= "";
            */
        }

        $result['city_search']='';
        $result['state_search']= '';

        $result['statuses'] = DB::table('treatment_status')->get(); 
        $result['types'] = TreatmentType::all(); 
       return view('admin.edit_Treatment',$result); 
    }

public function manage_treatment_process(Request $request)
{
     // Check if we are updating or inserting
    if ($request->post('id') > 0) {
        $treatment = Treatment::find($request->post('id'));
        $msg = 'Treatment updated';
    } else {
        $treatment = new Treatment();
        $msg = 'Treatment inserted';
    }
 
    // Save treatment details
    $treatment->start_date_time = $request->post('start_date').' '.$request->post('start_time');
    $treatment->end_date_time = $request->post('end_date').' '.$request->post('end_time');
    
    $treatment->remarks = $request->post('remarks');
    $treatment->status=$request->post('status');
    $treatment->teeth_UL = $request->post('teeth_UL');
    $treatment->teeth_UR = $request->post('teeth_UR');
    $treatment->teeth_LL = $request->post('teeth_LL');
    $treatment->teeth_LR = $request->post('teeth_LR');
    $treatment->teeth_exam = $request->post('teeth_exam');
   $NextAppId=0;
  
  ///////////
if ($request->post('next_appointment_date') && $request->post('NextAppointment_time')) {
    if ($request->post('NextAppId') > 0) {
        $next_appointment = Appointment::find($request->post('NextAppId'));
    } else {
        $next_appointment = new Appointment();
    }

    // Ensure $treatment->appointment is not null
    if ($treatment->appointment) {
        $next_appointment->app_date_time = $request->post('next_appointment_date') . ' ' . $request->post('NextAppointment_time');
        $next_appointment->purpose = $treatment->appointment->purpose;
        $next_appointment->patient_id = $treatment->appointment->patient_id;
        $next_appointment->status = 1;
        $next_appointment->preTreatment = $treatment->id;
        $next_appointment->treatment_type = $treatment->type;
        $next_appointment->save();
        $NextAppId = $next_appointment->id;
    } else {
        // Handle the case where there is no appointment related to this treatment
        // You could set a default value or return an error if needed
        return response()->json(['message' => 'Error: No related appointment found for this treatment.'], 400);
    }
}

  //////////
    $treatment->NextAppId = $NextAppId;
    $treatment->save();
    if($request->post('callBy')=='1')
    {
         return response()->json(['message' => $msg]);
    }
    else 
    {
        $request->session()->flash('message', $msg);
        return redirect('admin/treatment');
    }
    
}


public function print_prescription(Request $request,$id='')
    {
        if ($id>0) 
        {
         
 //$treatment = Treatment::where(['id'=>$id])->get()->first();
 $treatment = Treatment::with(['treatment_medical_histories.medical_history'])->with(['treatment_oral_examinations.oral_examination'])->with(['treatment_advices.advice'])->with(['treatment_medicines.medicine'])->where('id', $id)->first();

            $patient = Patient::where(['id'=>$treatment->patient_id])->get()->first();
            $result['treatment']=$treatment;

            $result['start_date_time']= $treatment->start_date_time;
            //$result['app_time'] = $treatment->app_date_time;
            $result['purpose'] = $treatment->purpose;
            //Carbon::parse($treatment->app_date_time)->format('h:i A');
            $result['id']= $treatment->id;
            $result['patient_id']= $patient->id;
            $result['first_name']= $patient->first_name;
            $result['last_name']= $patient->last_name;
            $result['imagePath']=$patient->ImagePath();
            $result['image']= $patient->image;
            $result['mobile']= $patient->mobile;
            $result['address']= $patient->address;
            $result['pin']= $patient->pin;
            $result['date_of_birth']= $patient->date_of_birth;
            $result['city']= $patient->city;
            $result['state']= $patient->state;
            $result['country']= $patient->country;
            $result['age']= $patient->age;
            $result['gender']= $patient->gender['name'];
            $result['Height']= $patient->Height;
            $result['Weight']= $patient->Weight;
            $result['BP']= $patient->BP;
            $result['Pulse']= $patient->Pulse;
            $result['BMI']= $patient->BMI;
            $result['WC']= $patient->WC;
            $result['email']= $patient->email;
            $result['status']= $treatment->status;
            $result['isApproved']= $patient->isApproved;
            $result['password']= '';

            $siteUrl = config('app.url');
            $result['header1']=$siteUrl.'/storage/media/header1.png';
            $result['footer1']=$siteUrl.'/storage/media/footer1.png';
            $result['logoImagePath']=$siteUrl.'/storage/media/toothPaste.png';
        return view('admin.print_prescription',$result); 


    //$pdf = PDF::loadView('admin.print_prescription', $result);
        /*$pdf = PDF::loadView('admin.print_prescription', $result)->setPaper('a4', 'portrait');

        //return $pdf->download('prescription_'.$id.'.pdf');
        return $pdf->stream('prescription.pdf'); // For testing in the browser
        */
    }
}
   public function delete(Request $request,$id)
    {
       $message='';
/*
       $orders=Order::where('treatment_id','=',$id)->get();
       $c=count($orders);
       if($c>0)
       {
            $message = $c.' Order(s) ';
       }


       $bills =Bill::where('treatment_id','=',$id)->get();

       $c=count($bills);
       if($c>0)
       {
            $message .=' and '.$c.' Bill(s) ';
       }
*/       
       $typeName=session()->get('typeName');
       
       if($message =='')
       {
        $model = Treatment::find($id);
        $model->delete();
        return redirect($typeName.'/treatment')->with('message','Treatment deleted'); 
       }
       else 
       {
        return redirect($typeName.'/treatment')->with('error','Unable to delete as '.$message.' linked with this Treatment');
       }
       
    }

    public function forceDelete(Request $request,$id)
    {
       
       $model = Treatment::withTrashed()->find($id);
       $model->forceDelete();
       $request->session()->flash('message','Treatment permantly deleted');
       return redirect('admin/treatment/trash');
    }

    public function restore(Request $request,$id)
    {
       
       $model = Treatment::withTrashed()->find($id);
       $model->restore();
       $request->session()->flash('message','Treatment Restored');
       return redirect('admin/treatment/trash');
    }

    public function status(Request $request,$status,$id)
    {
       
       $model = Treatment::find($id);
       $model->status = $status;
       $model->save();
       $request->session()->flash('message','Treatment status changed');
       return redirect('admin/treatment');
    }
 
public function fetchTreatments($patient_id)
{
    $treatments = Treatment::with('treatmentType') // Eager load treatmentType relationship
        ->where('patient_id', $patient_id)
        ->get();

    return response()->json($treatments);
}


}
