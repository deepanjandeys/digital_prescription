<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Admin;
use App\Models\Patient;
use App\Models\Appointment;
use App\Models\TreatmentMedicine;
use App\Models\Treatment;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use DateTime; // Add this line to import DateTime
use Illuminate\Support\Facades\Storage;
use Intervention\Image\Facades\Image;

class PrescriptionController extends Controller
{
public function generatePrescription($treatmentId)
{
    $medicines = DB::table('treatment_medicines')
        ->join('medicine', 'medicine.id', '=', 'treatment_medicines.medicine_id')
        ->where('treatment_medicines.treatment_id', $treatmentId)
        ->select(
            'treatment_medicines.id as treatment_medicine_id',
            'medicine.Medicine',
            'medicine.id as medicine_id',
            'treatment_medicines.Dosage',
            'treatment_medicines.frequency', 
            'treatment_medicines.duration_quantity',
            'treatment_medicines.duration_unit',
            'treatment_medicines.timing'
        )
        ->orderBy('treatment_medicines.id', 'asc')
        ->get();

    $treatment = Treatment::find($treatmentId);    
    $patientData = Patient::find($treatment->patient_id);

    // Load the prescription template
    $imagePath = public_path('images/prescription_template.jpg');
    $img = Image::make($imagePath);

    // Add text for patient details
    $img->text('Name: ' . $patientData->name, 150, 200, function($font) {
        $font->file(public_path('fonts/Arial.ttf'));
        $font->size(24);
        $font->color('#000');
    });

    $img->text('Age: ' . $patientData->age, 150, 240, function($font) {
        $font->file(public_path('fonts/Arial.ttf'));
        $font->size(24);
        $font->color('#000');
    });

    $img->text('Gender: ' . $patientData->gender, 150, 280, function($font) {
        $font->file(public_path('fonts/Arial.ttf'));
        $font->size(24);
        $font->color('#000');
    });

    // Add medicines list
    $yPosition = 320;
    foreach ($medicines as $medicine) {
        $img->text($medicine->Medicine . ' - ' . $medicine->Dosage, 150, $yPosition, function($font) {
            $font->file(public_path('fonts/Arial.ttf'));
            $font->size(20);
            $font->color('#000');
        });
        $yPosition += 40;
    }

    // Save or output image
    $outputPath = public_path('images/generated_prescription.jpg');
    $img->save($outputPath);

    return response()->download($outputPath);
}

}