<?php

namespace App\Http\Controllers;

use App\Models\User; 
use App\Models\Operator;
use App\Models\Admin;
use Illuminate\Support\Facades\Hash;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OperatorController extends Controller
{
    protected $functionsController;
    public function __construct(FunctionsController $functionsController)
    {
        $this->functionsController = $functionsController;
    }
    public function index(Request $request)
    {
        if ($request->session()->has('ADMIN_LOGIN')) 
        {            
            return redirect('operator/dashboard');
        }
        else
        {
           $result['type']=2;
           return view('admin.login',$result);
        }

    }
     public function dashboard()
    {
       return view('admin.dashboard_op');
    }

    public function list(Request $request)
    {
        $search=$request['search'] ?? "";
        if($search !="")
        {
$operator = Operator::where(function ($query) use ($search){
                $query->where('first_name', 'like', '%'.$search.'%')->orwhere('address','like',"%$search%");
            })
            ->with('users')
            ->latest()->simplepaginate(10);

        }
        else
        {   
     $operator  = Operator::latest()->simplepaginate(10);
        }
         
        $result = compact('operator','search');
        return view('admin.operator',$result); 
    }    
     public function trash()
    {
        $result['data'] =   Operator::onlyTrashed()->get();
        $result['statuses'] = DB::table('status')->get(); 
        return view('admin.operator-trash',$result); 
    }

    public function edit_operator(Request $request,$id='')
    {
        if ($id>0) 
        {
            $arr = Operator::where(['id'=>$id])->get();
            $user = User::where(['refer_id'=>$id])->get();

            $result['id']= $arr[0]->id;
            $result['user_id']= $user[0]->id;
            $result['first_name']= $arr[0]->first_name;
            $result['last_name']= $arr[0]->last_name;
            $result['mobile']= $arr[0]->mobile;
            $result['address']= $arr[0]->address;
            $result['pin']= $arr[0]->pin;
            $result['date_of_birth']= $arr[0]->date_of_birth;
            $result['city']= $arr[0]->city;
            $result['state']= $arr[0]->state;
            $result['country']= $arr[0]->country;
            $result['email']= $arr[0]->Users->email;
            $result['status']= $arr[0]->Users->status;
            $result['isApproved']= $arr[0]->Users->isApproved;
            $result['password']= '';
        }
        else
        {
            $result['id']= '0';
            $result['user_id']= '0';
            $result['first_name']= '';
            $result['last_name']= '';
            $result['mobile']= '';
            $result['email']= '';
            $result['password']= '';
            $result['address']= '';
            $result['pin']= '';
            $result['date_of_birth']= '';
            $result['city']= '';
            $result['state']= '';
            $result['country']= '';
            $result['isApproved']=1;
            $result['status']= '1';
        }
        //print_r($result);
        $result['statuses'] = DB::table('status')->get(); 
       return view('admin.edit_Operator',$result); 
    }

public function manage_operator_process(Request $request)
{
    // Validate input data
    $request->validate([
        'first_name' => 'required',
        'mobile' => 'required|unique:operators,mobile,' . $request->post('id'),
        'address' => 'required',
        'pin' => 'required',
        'email' => 'required|email',
        'password' => $request->post('id') == 0 ? 'required|min:6' : 'nullable',
    ]);

    // Determine if updating an existing operator or creating a new one
    if ($request->post('id') > 0) {
        $model = Operator::find($request->post('id'));
        $msg = 'Operator updated';
    } else {
        $model = new Operator();
        $msg = 'Operator Inserted';
    }

    // Update or create operator details
    $model->first_name = $request->post('first_name');
    $model->last_name = $request->post('last_name');
    $model->mobile = $request->post('mobile');
    $model->address = $request->post('address');
    $model->pin = $request->post('pin');
    $model->date_of_birth = $request->post('date_of_birth');
    $model->city = $request->post('city');
    $model->state = $request->post('state');
    $model->country = $request->post('country');
    $model->status = $request->post('status');

    $model->save();

    // If this is a new operator, create a user record
    if ($request->post('id') == 0) {
        $password = $request->post('password');
        $firstName = $request->post('first_name');
        $lastName = $request->post('last_name');
        $mobile = $request->post('mobile');

        // Generate a unique username
        $username = $this->functionsController->generateUniqueUsername($firstName, $lastName, $mobile);

        // Create the corresponding user record
        $user = new User();
        $user->name = $username; // Set the unique username
        $user->email = $request->post('email');
        $user->address = $request->post('address');
        $user->description = ''; 
        $user->password = Hash::make($password);
        $user->type = 2; // Assuming type 2 is for operators
        $user->refer_id = $model->id; // Reference to the operator's ID
        $user->image = ''; // If you have an image upload, handle it here
        $user->isApproved = 1;
        $user->status = 1;
        $user->save();
    }

    // Flash message and redirect
    $request->session()->flash('message', $msg);
    return redirect('admin/operator');
}

public function delete(Request $request,$id)
    {
       $message='';
/*
       $orders=Order::where('operator_id','=',$id)->get();
       $c=count($orders);
       if($c>0)
       {
            $message = $c.' Order(s) ';
       }


       $bills =Bill::where('operator_id','=',$id)->get();

       $c=count($bills);
       if($c>0)
       {
            $message .=' and '.$c.' Bill(s) ';
       }
*/       
       $typeName=session()->get('typeName');
       
       if($message =='')
       {
        $model = Operator::find($id);
        $model->delete();
        return redirect($typeName.'/operator')->with('message','Operator deleted'); 
       }
       else 
       {
        return redirect($typeName.'/operator')->with('error','Unable to delete as '.$message.' linked with this Operator');
       }
       
    }

    public function forceDelete(Request $request,$id)
    {
       
       $model = Operator::withTrashed()->find($id);
       $model->forceDelete();
       $request->session()->flash('message','Operator permantly deleted');
       return redirect('admin/operator/trash');
    }

    public function restore(Request $request,$id)
    {
       
       $model = Operator::withTrashed()->find($id);
       $model->restore();
       $request->session()->flash('message','Operator Restored');
       return redirect('admin/operator/trash');
    }

    public function status(Request $request,$status,$id)
    {
       
       $model = Operator::find($id);
       $model->status = $status;
       $model->save();
       $request->session()->flash('message','Operator status changed');
       return redirect('admin/operator');
    }


    public function forgetPassword(Request $request)
    {
        $mobile = ltrim($request->post('mobile'), "0");
        $id=0;

        $result = Operator::where(['mobile'=>$mobile])->first();
        if (isset($result))
        {
           $admin=Admin::where('refer_id','=',$result->id)->get();
           $email =  $admin[0]->email; 
           $id    =  $result->id;
           if($email=='')
            {
            $request->session()->flash('error','Your email id is not set,we unable to send password reset link to your email, ask Admin to create a password reset link to you');
            return redirect('operator/forget_password');   
            }

           $subject = urlencode("Forget password");
           $fun = new FunctionsController();
           $enId = $fun->encrypt($id);
           $t_url= $fun->get_tiny_url("http://127.0.0.1:8000/operator/ResetPassword/".$enId);


$bodyText = urlencode("<a href='".$t_url."'>Click here to reset password </a>");
$url="https://safego.co.in/gmailApi/index.php?email=$email&subject=$subject&body=$bodyText&formHeader=XCL";
//echo '<a href="'.$url.'" target="_blank">mail link</a>';
//die();
$ch = curl_init($url);
$timeout=20;
curl_setopt ($ch, CURLOPT_URL, $url);
curl_setopt ($ch, CURLOPT_HEADER, 0);
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, false);    
curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, false);  
$fetchdata = curl_exec($ch);        
curl_close($ch);
       return redirect('operator/forget_password_success/'.$id);
     
        }
        else
        {
            $request->session()->flash('error','Mobile number not exist');
            return redirect('operator/forget_password');
        }
        
    }
    
    public function forget_password_success(Request $request,$id='')
    {
        if ($id>0) 
        {
            $arr = Operator::where(['id'=>$id])->get();
            $admin=Admin::where('refer_id','=',$arr[0]->id)->get();

            if($arr->count() >0)
            {
            $fun = new FunctionsController();
            $email = $fun->maskEmail($admin[0]->email);
            $result['email']= $email;
            }
        }
        else
        {
            $result['email']= '';
        }
       return view('admin.operator_forget_password_success',$result); 
    }

public function password_change_success(Request $request,$id='')
    {
        if ($id>0) 
        {
            $arr = Admin::where(['id'=>$id])->get();
            $result['id']= $arr[0]->id;
            $result['name']= $arr[0]->name;
            
        }
     
        
       return view('admin.admin_password_change_success',$result); 
    }
    public function manage_password_reset(Request $request)
    {
       $request->validate([
        'newPassword'=>'required'
       ]
       ); 
       $id=$request->post('id');
       
       if ($id>0) 
       {
            //$password = $request->post('password');
            $newPassword = $request->post('newPassword');
            $model = Admin::where('refer_id',$id)->where('type','=',3)->first(); 

        if (isset($model))
        {
            
            //if (Hash::check($password,$model->password)) 
            {       
           $model->password = Hash::make($newPassword);
           $msg = 'User password reset';
            $model->save();
            $request->session()->flash('message',$msg);
            return redirect('operator/password_change_success/'.$id);
            }
           /* else
            {
            $msg = 'User current password Not matched';   
            //$request->session()->flash('message',$msg);
            return redirect('operator/password_change_success/'.$id)->with('error',$msg);

            }
            */
        }
        else 
        {
            $msg = 'User Not found';   
            $request->session()->flash('message',$msg);
            return redirect('operator/changePassword/'.$id);
        }
       }
       
        
    }

public function operator_password_reset(Request $request,$id='')
    {
            
        if ($id!='') 
        {
           
           $fun = new FunctionsController();
            $id = (int)$fun->decrypt($id);
            

            $arr = Operator::where(['id'=>$id])->get();
            //echo "Count ".$arr->count();
            if($arr->count()==0)
            {
                return redirect('no-access');       
            }
            $result['id']= $arr[0]->id;
            $result['name']= $arr[0]->name;
        }
     
        
       return view('admin.operator_reset_password',$result); 
    }
    public function operator_password_change_success(Request $request,$id='')
    {
        if ($id>0) 
        {
            $arr = Operator::where(['id'=>$id])->get();
            $result['id']= $arr[0]->id;
            $result['name']= $arr[0]->name;
            
        }
       return view('admin.operator_password_change_success',$result); 
    }
    public function manage_operator_password_reset(Request $request)
    {
        $s=" 'password'=>'required',";

       $request->validate([
        'newPassword'=>'required'
       ]
       ); 
       $id=$request->post('id');
       if ($id>0) 
       {
            //$password = $request->post('password');
            $newPassword = $request->post('newPassword');
            $model = Operator::find($id); 

        if (isset($model))
        {
            $model->password = Hash::make($newPassword);
            $msg = 'User password reset';
            $model->save();
            $request->session()->flash('message',$msg);
            return redirect('operator/password_change_success/'.$id);
            
        }
        else 
        {
            $msg = 'User Not found';   
            $request->session()->flash('message',$msg);
            return redirect('operator/ResetPassword/'.$id);
        }
       }
       
        
    }
   public function operator_password_change(Request $request)
    {
       $request->validate([
        'password'=>'required',
        'newPassword'=>'required'
       ]
       ); 
       $id=$request->post('id');
       if ($id>0) 
       {
            $password = $request->post('password');
            $newPassword = $request->post('newPassword');
            $model = Operator::find($id); 

        if (isset($model))
        {
            if (Hash::check($password,$model->password)) 
            {       
           $model->password = Hash::make($newPassword);
           $msg = 'User password reset';
            $model->save();
            $request->session()->flash('message',$msg);
            return redirect('operator/password_change_success/'.$id);
            }
            else
            {
            $msg = 'User current password Not matched';   
            //$request->session()->flash('message',$msg);
            return redirect('operator/password_change/'.$id)->with('error',$msg);

            }
        }
        else 
        {
            $msg = 'User Not found';   
            $request->session()->flash('message',$msg);
            //return redirect('operator/changePassword/'.$id);
        }
       }   
    }


public function reset(Request $request,$id='')
    {
        if ($id>0) 
        {
            $arr = Admin::find($id);
            $result['id']= $arr->refer_id;
            $result['name']= $arr->name;
            
        }
     
        
       return view('admin.operator_reset_password',$result); 
    }
}
