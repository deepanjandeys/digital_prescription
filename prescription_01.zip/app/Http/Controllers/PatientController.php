<?php

namespace App\Http\Controllers;

use App\Models\User; 
use App\Models\Patient;
use App\Models\Admin;
use App\Models\Gender;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PatientController extends Controller
{
    public function index(Request $request)
    {
        if ($request->session()->has('ADMIN_LOGIN')) 
        {            
            return redirect('patient/dashboard');
        }
        else
        {
           $result['type']=4;
           return view('admin.login',$result);
        }

    }
     public function dashboard()
    {
       return view('admin.dashboard_pt');
    }

    public function list(Request $request)
    {
  
    $search = $request['search'] ?? "";
    
    if ($search != "") {
        $patients = Patient::with('gender')  // Ensure we're eager loading gender relationship
            ->where(function ($query) use ($search) {
                $query->where('first_name', 'like', '%'.$search.'%')
                      ->orWhere('address', 'like', '%'.$search.'%');
            })
            ->latest()
            ->simplePaginate(10);
    } else {
        $patients = Patient::with('gender')  // Eager loading even without search
            ->latest()
            ->simplePaginate(10);
    }
//dd($patients->toArray());
            $result = compact('patients','search');
        return view('admin.patient',$result); 
    }    
     public function trash()
    {
        $result['data'] =   Patient::onlyTrashed()->get();
        $result['statuses'] = DB::table('status')->get(); 
        return view('admin.patient-trash',$result); 
    }

    public function edit_patient(Request $request,$id='')
    {
        if ($id>0) 
        {
            $arr = Patient::where(['id'=>$id])->get();
            //$user = User::where(['refer_id'=>$id])->get();

            $result['id']= $arr[0]->id;
            //$result['user_id']= $user[0]->id;
            $result['first_name']= $arr[0]->first_name;
            $result['last_name']= $arr[0]->last_name;
            $result['imagePath']=$arr[0]->ImagePath();
            $result['image']= $arr[0]->image;
            $result['mobile']= $arr[0]->mobile;
            $result['address']= $arr[0]->address;
            $result['pin']= $arr[0]->pin;
            $result['gender_id']= $arr[0]->gender_id;
            $result['city']= $arr[0]->city;
            $result['state']= $arr[0]->state;
            $result['country']= $arr[0]->country;
            $result['age']= $arr[0]->age;
            $result['Height']= $arr[0]->Height;
            $result['Weight']= $arr[0]->Weight;
            $result['BP']= $arr[0]->BP;
            $result['Pulse']= $arr[0]->Pulse;
            $result['BMI']= $arr[0]->BMI;
            $result['WC']= $arr[0]->WC;
            $result['email']= $arr[0]->email;
            $result['status']= $arr[0]->status;
            $result['isApproved']= $arr[0]->isApproved;
            $result['password']= '';
        }
        else
        {
            $result['id']= '0';
            //$result['user_id']= '0';
            $result['first_name']= '';
            $result['last_name']= '';
            $result['mobile']= '';
            $result['email']= '';
            $result['password']= '';
            $result['address']= '';
            $result['pin']= '';
            $result['gender_id']= ''; 
            $result['city']= 'Silchar';
            $result['state']= 'Assam';
            $result['country']= 'India';
            $result['age']= '';
            $result['Height']= '';
            $result['Weight']= '';
            $result['BP']= '';
            $result['Pulse']= '';
            $result['BMI']= '';
            $result['WC']= '';
            $result['isApproved']=1;
            $result['status']= '1';
        }
        //print_r($result);
        $result['statuses'] = DB::table('status')->get(); 
        $result['genderes'] = Gender::all(); 
       return view('admin.edit_Patient',$result); 
    }

    public function manage_patient_process(Request $request)
{

    $request->validate([
    'first_name' => 'required',
    'mobile' => 'required|digits:10',
    'address' => 'required',
    'pin' => 'required',
]);
//'mobile' => 'required|unique:patients,mobile,'.$request->post('id'),

//'image' => 'nullable|image|mimes:jpg,jpeg,png,gif|max:2048', // Validate the image

    // Check if we are updating or inserting
    if ($request->post('id') > 0) {
        $model = Patient::find($request->post('id'));
        $msg = 'Patient updated';
    } else {
        $model = new Patient();
        $msg = 'Patient inserted';
    }

    // Save patient details
    $model->first_name = $request->post('first_name');
    $model->last_name = $request->post('last_name');
    $model->mobile = $request->post('mobile');
    $model->address = $request->post('address');
    $model->pin = $request->post('pin');
    $model->gender_id = $request->post('gender_id');
    $model->city = $request->post('city');
    $model->state = $request->post('state');
    $model->country = $request->post('country');
    $model->status = $request->post('status');
    $model->age = $request->post('age');
    $model->Height = $request->post('Height');
    $model->Weight = $request->post('Weight');
    $model->BP = $request->post('BP');
    $model->Pulse = $request->post('Pulse');
    $model->BMI = $request->post('BMI');
    $model->WC = $request->post('WC');
    

    $model->save();

        if ($request->post('id') == 0) {
            $model->registration_number = 'DW' . str_pad($model->id, 5, '0', STR_PAD_LEFT);
            $model->save();
            }

    // Set flash message and redirect
    $request->session()->flash('message', $msg);
    return redirect('admin/patient');
}


   public function delete(Request $request,$id)
    {
       $message='';
/*
       $orders=Order::where('patient_id','=',$id)->get();
       $c=count($orders);
       if($c>0)
       {
            $message = $c.' Order(s) ';
       }


       $bills =Bill::where('patient_id','=',$id)->get();

       $c=count($bills);
       if($c>0)
       {
            $message .=' and '.$c.' Bill(s) ';
       }
*/       
       $typeName=session()->get('typeName');
       
       if($message =='')
       {
        $model = Patient::find($id);
        $model->delete();
        return redirect($typeName.'/patient')->with('message','Patient deleted'); 
       }
       else 
       {
        return redirect($typeName.'/patient')->with('error','Unable to delete as '.$message.' linked with this Patient');
       }
       
    }

    public function forceDelete(Request $request,$id)
    {
       
       $model = Patient::withTrashed()->find($id);
       $model->forceDelete();
       $request->session()->flash('message','Patient permantly deleted');
       return redirect('admin/patient/trash');
    }

    public function restore(Request $request,$id)
    {
       
       $model = Patient::withTrashed()->find($id);
       $model->restore();
       $request->session()->flash('message','Patient Restored');
       return redirect('admin/patient/trash');
    }

    public function status(Request $request,$status,$id)
    {
       
       $model = Patient::find($id);
       $model->status = $status;
       $model->save();
       $request->session()->flash('message','Patient status changed');
       return redirect('admin/patient');
    }


}
