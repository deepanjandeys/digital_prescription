<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Admin;
use App\Models\Operator;
use App\Models\Counter;
use App\Models\Patient;
use App\Models\Appointment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
      if ($request->session()->has('ADMIN_LOGIN')) 
        {
            return redirect('admin/dashboard');
        }
        else
        {
           $result['type']=1; 
           return view('admin.login',$result);
        }
    }
    public function aa()
    {
      return view('admin.aa');   
    }
    public function auth(Request $request)
    {
        $validatedData = $request->validate([
        'name' => 'required|string|max:255',
        'password' => 'required|min:3',
        'type' => 'required|numeric',
        ]);

        $name = $request->post('name');
        $type = $request->post('type');
        $password = $request->post('password');
        $result = User::where(['name'=>$name])->where(['type'=>$type])->first();
        if (isset($result)) 
        {
            if (Hash::check($request->post('password'),$result->password)) 
            {
                
                if($result->isApproved=='0')
                {
                    $request->session()->flash('error','your User id is not approved ');
                    return redirect('admin');
                }

                if($result->status=='0')
                {
                    $request->session()->flash('error','your User id is inactive');
                    return redirect('admin');
                }

                $request->session()->put('ADMIN_LOGIN','true');
                $request->session()->put('ADMIN_ID',$result->id);
                $request->session()->put('ADMIN_TYPE',$result->type);
                $request->session()->put('ADMIN_NAME',$result->name);
                $request->session()->put('ADMIN_IMAGE',$result->image);
                $request->session()->put('ADMIN_REFER_ID',$result->refer_id);
                $request->session()->put('ADMIN_EMAIL',$result->email);


                $typeName='';
                if($result->type=='1')
                {
                $typeName='admin';
                $request->session()->put('ADMIN_REFER_NAME','admin');
                $request->session()->put('ADMIN_LOGIN','true');
                }
                elseif ($result->type=='2')
                {
                $request->session()->put('OPERATOR_LOGIN','true');
                $typeName='operator';

                $operator=Operator::find($result->refer_id);
                $request->session()->put('ADMIN_REFER_NAME',$operator->name);
                
                } 
                elseif ($result->type=='3')
                {
                $request->session()->put('COUNTER_LOGIN','true');
                $typeName='counter';

                $counter=Counter::find($result->refer_id);
                $request->session()->put('ADMIN_REFER_NAME',$counter->name);
                
                } 
                $request->session()->put('typeName',$typeName);
                $request->session()->put('ADMIN_ID',$result->id);
                return redirect($typeName.'/dashboard');

                //return redirect('admin/dashboard');
            }
            else
            {
                //$request->session()->flash('error','Please enter correct password');
                /*
                $typeName='';
                if($type=='1')
                {
                $typeName='admin';
                }
                elseif ($result->type=='2')
                {
                $typeName='operator';
                }
                elseif ($result->type=='3')
                {
                $typeName='counter';
                }  
                */
               
                 return back()->withInput()->withErrors(['password' => 'Password not matched.']);
                //return redirect($typeName);
            }
           
        }
        else
        {
            /*
            $request->session()->flash('error','Please enter valid login details');
            if($type=='1')
                return redirect('admin');
            else if($type=='2')
                return redirect('operator');
            else if($type=='3')
                return redirect('counter');
            */

            return back()->withInput()->withErrors(['type' => 'user id or passowrd or type not matched.']);    
        }
        
    }
    public function dashboard()
    {
        $result['counters_count']=Counter::count();
        $result['patients_count']=Patient::count();
        $result['patients']=Patient::all();
        $result['appointments_count']=Appointment::whereDate('app_date_time', '=', date('Y-m-d'))->count();
        $result['appointments_complete_count']=Appointment::whereDate('app_date_time', '=', date('Y-m-d'))->where('status','=',4)->count();
        $result['appointments']=Appointment::all();
        return view('admin.dashboard',$result); 
    }
    
    public function profile()
    {
        $id=session()->get('ADMIN_ID'); // user id
        $user=User::find($id);
        $admin_id=$user->refer_id;
        $result['id']=$id;
        $result['user_name']=$user->name;
        $result['user_address']=$user->address;
        $result['user_description']=$user->description;
        $result['email']=$user->email;
        $result['imagePath']=$user->ImagePath();
        $result['image']= $user->image;
        if($user->type=='1')
        {
            $admin=Admin::find($admin_id) ;
        }
        else if($user->type=='2')
        {
            $admin=Operator::find($admin_id) ;
        }
        else if($user->type=='3')
        {
            $admin=Counter::find($admin_id) ;
        }
        
        $result['first_name']=$admin->first_name;
        $result['last_name']=$admin->last_name;
        $result['mobile']=$admin->mobile;
        $result['date_of_birth']=$admin->date_of_birth;
        $result['address']=$admin->address;
        $result['pin']=$admin->pin;
        $result['city']=$admin->city;
        $result['state']=$admin->state;
        $result['country']=$admin->country;
        
       return view('admin.profile',$result); 
    }

    public function personalDetailsChange(Request $request)
    {
        $request->validate([
        'first_name'=>'required',
        'last_name'=>'required',
        'date_of_birth'=>'required',
        'email'=>'required',
        'mobile'=>'required',
        'address'=>'required',
        'city'=>'required',
        'state'=>'required',
        'pin'=>'required',
        'country'=>'required'
       ]
       ); 

        $id=session()->get('ADMIN_ID'); // user id
        if ($id>0) 
        {
            $user=User::find($id);
            
            $user->email=$request->post('email'); 
            $user->save();

            $admin_id=$user->refer_id;
             
            if($user->type=='1')
            {
            $admin=Admin::find($admin_id) ;
            }
            else if($user->type=='2')
            {
            $admin=Operator::find($admin_id) ;
            }
            else if($user->type=='3')
            {
            $admin=Counter::find($admin_id) ;
            }
             
            $admin->first_name=$request->post('first_name'); 
            $admin->last_name=$request->post('last_name'); 
            $admin->mobile=$request->post('mobile'); 
            $admin->date_of_birth=$request->post('date_of_birth');
            //echo $request->post('date_of_birth');
            //die();
            $admin->address=$request->post('address'); 
            $admin->pin=$request->post('pin'); 
            $admin->city=$request->post('city'); 
            $admin->state=$request->post('state'); 
            $admin->country=$request->post('country'); 
            $admin->save();

            $typeName=session('typeName');
            return redirect($typeName.'/profile');
        }
        else 
        {
            return redirect('/');
        } 
    }

public function userDetailsChange(Request $request)
{
    // Fetch the logged-in user's ID from session
    $id = session()->get('ADMIN_ID');
    
    // Validate the incoming request
    $image_validation = "mimes:jpeg,jpg,png,gif";
    $request->validate([
        'user_name' => 'required|unique:users,name,' . $id,
        'user_address' => 'required',
        'image' => $image_validation,
        'user_description' => 'required',
    ]);

    // Handle image upload if a new image is provided
    if ($request->hasFile('image')) {
        $ext = $request->file('image')->getClientOriginalExtension();
        $image_name = 'a_' . $request->post('user_name') . '_' . time() . '.' . $ext;
        $request->file('image')->storeAs('/media/users/', $image_name);
    } else { 
        $image_name = $request->post('hdImage'); // Use the old image
    }

    // Update the user details
    if ($id > 0) {
        $user = User::find($id);
        $user->name = $request->post('user_name');
        $user->image = $image_name;
        $user->address = $request->post('user_address');
        $user->description = $request->post('user_description');
        $user->save();

        // Update the session image
        session()->put('ADMIN_IMAGE', $image_name);
    }

    // Redirect based on user type
    $typeName = session('typeName');
    return redirect($typeName . '/profile')->with('success', 'Profile updated successfully!');
}

    public function settings()
    {
        return view('admin.settings'); 
    }

    public function forgetPassword(Request $request)
    {
        $id=0;
        $name=$request->post('name');
        $type=$request->post('type');
        $result = User::where(function ($query) use ($name) {
    $query->where('name', $name)
          ->orWhere('email', $name);
})->where('type', $type)->first();

        if (isset($result))
        {
           $email =  $result->email; 
           $id    =  $result->id;
           if($email=='')
            {
            $request->session()->flash('error','Your email id is not set,we unable to send password reset link to your email, ask Admin to create a password reset link to you');
            return redirect('forget_password');   
            }

           $subject = urlencode("Forget password");
           $fun = new FunctionsController();
           $enId = $fun->encrypt($id);
           $url = config('app.url');
           $t_url= $fun->get_tiny_url($url."/ResetPassword/".$enId);


$bodyText = urlencode("<a href='".$t_url."'>Click here to reset password </a>");
$url="https://safego.co.in/gmailApi/index.php?email=$email&subject=$subject&body=$bodyText&formHeader=XCL";
$request->session()->put('t_url',$t_url); //temporary
//echo '<a href="'.$url.'" target="_blank">mail link</a>';
//die();
$ch = curl_init($url);
$timeout=20;
curl_setopt ($ch, CURLOPT_URL, $url);
curl_setopt ($ch, CURLOPT_HEADER, 0);
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, false);    
curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, false);  
$fetchdata = curl_exec($ch);        
curl_close($ch);
       return redirect('forget_password_success/'.$id);
     
        }
        else
        {
            $request->session()->flash('error','name or email  not exist or you may try with different type');
            return redirect('forget_password/'.$type);
        }
        
    }
    
public function forget_password_success(Request $request,$id='')
    {
        if ($id>0)  
        {
            $arr = User::find($id);
         //print_r($arr);

            if($arr->count() >0)
            {
            $fun = new FunctionsController();
            $email = $fun->maskEmail($arr->email);
            $result['email']= $email;
            }
        }
        else
        {
            $result['email']= '';
        }

        $result['home'] = config('app.url');

       return view('admin.forget_password_success',$result); 
    }

    public function manage_password_reset(Request $request)
    {
       $request->validate([
        'newPassword'=>'required'
       ]
       ); 
       $id=$request->post('id');
       if ($id>0) 
       {
            //$password = $request->post('password');
            $newPassword = $request->post('newPassword');
            $model = User::find($id); 
        if (isset($model))
        {
            
            //if (Hash::check($password,$model->password)) 
            {       
           $model->password = Hash::make($newPassword);
           $msg = 'User password reset';
            $model->save();
            $request->session()->flash('message',$msg);
            return redirect('password_change_success/'.$id);
            }
           /* else
            {
            $msg = 'User current password Not matched';   
            //$request->session()->flash('message',$msg);
            return redirect('admin/password_change_success/'.$id)->with('error',$msg);

            }
            */
        }
        else 
        {
            $msg = 'User Not found';   
            $request->session()->flash('message',$msg);
            return redirect('changePassword/'.$id);
        }
       }
       
        
    }

public function password_reset(Request $request,$id='')//
    {
            
        if ($id!='') 
        {
           
           $fun = new FunctionsController();
            $id = (int)$fun->decrypt($id);
            

            $arr = User::find($id);
            //echo "Count ".$arr->count();
            if($arr->count()==0)
            {
                return redirect('no-access');       
            }
            $result['id']= $arr->id;
            $result['name']= $arr->name;
        }
     
        
       return view('admin.reset_password',$result); 
    }
    public function password_change_success(Request $request,$id='')
    {
        if ($id>0) 
        {
            $arr = User::find($id);
            $result['id']= $arr->id;
            $result['name']= $arr->name;
            
        }
        $result['home'] = config('app.url');
       return view('admin.password_change_success',$result); 
    }
    public function manage_admin_password_reset(Request $request)
    {
        $s=" 'password'=>'required',";

       $request->validate([
        'newPassword'=>'required'
       ]
       ); 
       $id=$request->post('id');
       if ($id>0) 
       {
            //$password = $request->post('password');
            $newPassword = $request->post('newPassword');
            $model = User::find($id); 

        if (isset($model))
        {
            $model->password = Hash::make($newPassword);
            $msg = 'User password reset';
            $model->save();
            $request->session()->flash('message',$msg);
    return redirect('admin/password_change_success/'.$id);
            
        }
        else 
        {
            $msg = 'User Not found';   
            $request->session()->flash('message',$msg);
            return redirect('admin/ResetPassword/'.$id);
        }
       }
       
        
    }
   public function password_change(Request $request)
    {
        // Validate the request
    $request->validate([
        'old_password' => ['required'],
        'new_password' => ['required', 'string', 'min:3', 'confirmed'],
    ]);

$id=session()->get('ADMIN_ID'); // user id
        if ($id>0) 
        {
            $user=User::find($id);
            // Check if the old password matches
    if (!Hash::check($request->old_password, $user->password)) {
        return back()->withErrors(['old_password' => 'The provided old password does not match our records.']);
            }
            else 
            {
            // Update the user's password
            $user->password = Hash::make($request->new_password);
            $user->save();
              // Return success response
return back()->with('status', 'Password updated successfully!');

            }
        }
        else 
        {
           return redirect('/'); 
        } 
    }
public function reset(Request $request,$id='')
    {
        if ($id>0) 
        {
            $arr = User::where(['id'=>$id])->get();
            $result['id']= $arr[0]->id;
            $result['name']= $arr[0]->name;
            
        }
     
        
       return view('admin.admin_reset_password',$result); 
    }
}
