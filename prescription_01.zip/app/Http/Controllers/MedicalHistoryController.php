<?php

namespace App\Http\Controllers;
use App\Models\MedicalHistory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MedicalHistoryController extends Controller
{
     public function index(Request $request)
    {
        $search=$request['search'] ?? "";
        if($search !="")
        {
$MedicalHistory = MedicalHistory::where(function ($query) use ($search){
                $query->where('MedicalHistory', 'like', '%'.$search.'%');
            })
            ->latest()->simplepaginate(10);
        }
        else
        {   
$MedicalHistory  = MedicalHistory::latest()->simplepaginate(10);
        }
        $result = compact('MedicalHistory','search');
        return view('admin.medicalHistory',$result); 
    }
    
     public function trash()
    {
        $result['data'] =   MedicalHistory::onlyTrashed()->get();
        return view('admin.medicalHistory-trash',$result); 
    }

    public function edit_medicalHistory(Request $request,$id='')
    {
        if ($id>0) 
        {
            $arr = MedicalHistory::where(['id'=>$id])->get();
            $result['id']= $arr[0]->id;
            $result['MedicalHistory']= $arr[0]->MedicalHistory;
        }
        else
        {
            $result['id']='0';
            $result['MedicalHistory']='';
        }
       return view('admin.edit_MedicalHistory',$result); 
    }

public function manage_medicalHistory_process(Request $request)
    { 
       $request->validate([
        'MedicalHistory'=>'required|unique:medical_histories,MedicalHistory,'.$request->post('id'),
       ]
       ); 
       if ($request->post('id')>0) 
       {
           $model = MedicalHistory::find($request->post('id'));
           $msg = 'MedicalHistory updated';
       }
       else
       {
            $model = new MedicalHistory();
            $msg = 'MedicalHistory Inserted';
       }
       
       $model->MedicalHistory = $request->post('MedicalHistory');
       $model->save();
       $request->session()->flash('message',$msg);
       return redirect('admin/medicalHistory');
    }

   public function delete(Request $request,$id)
    {
       $message='';
/*
       $customers=Customer::where('MedicalHistory','=',$id)->get();
       $c=count($customers);
       if($c>0)
       {
            $message = $c.' Customer(s) ';
       }

       $villageAgents =VillageAgent::where('MedicalHistory','=',$id)->get();

       $c=count($villageAgents);
       if($c>0)
       {
            $message .=' and '.$c.' Village Agent(s) ';
       }
       

       $salesAgents =SalesAgent::where('MedicalHistory','=',$id)->get();

       $c=count($salesAgents);
       if($c>0)
       {
            $message .=' and '.$c.' Sale Agents(s) ';
       }
  */     
       $typeName=session()->get('typeName');
       
       if($message =='')
       {
        $model = MedicalHistory::find($id);
        $model->delete();
        return redirect($typeName.'/medicalHistory')->with('message','MedicalHistory deleted'); 
       }
       else 
       {
        return redirect($typeName.'/medicalHistory')->with('error','Unable to delete as '.$message.' linked with this MedicalHistory');
       }

    }

    public function forceDelete(Request $request,$id)
    {
       
       $model = MedicalHistory::withTrashed()->find($id);
       $model->forceDelete();
       $request->session()->flash('message','MedicalHistory permantly deleted');
       return redirect('admin/medicalHistory/trash');
    }

    public function restore(Request $request,$id)
    {
       
       $model = MedicalHistory::withTrashed()->find($id);
       $model->restore();
       $request->session()->flash('message','MedicalHistory Restored');
       return redirect('admin/medicalHistory/trash');
    }

    public function status(Request $request,$status,$id)
    {
       
       $model = MedicalHistory::find($id);
       $model->status = $status;
       $model->save();
       $request->session()->flash('message','MedicalHistory status changed');
       return redirect('admin/MedicalHistory');
    }
}
