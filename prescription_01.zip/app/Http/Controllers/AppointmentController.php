<?php

namespace App\Http\Controllers;
 
use App\Models\Order;
use App\Models\User; 
use App\Models\Appointment;
use App\Models\Treatment;
use App\Models\Patient;
use App\Models\Gender;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use DateTime; // Add this line to import DateTime
class AppointmentController extends Controller
{
    public function index(Request $request)
    {
        if ($request->session()->has('ADMIN_LOGIN')) 
        {            
            return redirect('appointment/dashboard');
        }
        else
        {
           $result['type']=4;
           return view('admin.login',$result);
        }

    }
   
    public function list(Request $request)
{
    $search = $request->input('search', '');  // Fetch search input, defaulting to an empty string
    $app_date_src = $request->input('app_date_src', ''); // Fetch app_date input, defaulting to an empty string
    $app_date = DateTime::createFromFormat('d/m/Y', $app_date_src);
    $app_date = $app_date ? $app_date->format('Y-m-d') : null;
    // Query the Appointment model
    $appointmentQuery = Appointment::with('patient')  // Eager load related patients
        ->when($app_date, function ($query, $app_date) {
            // Filter by appointment date if the app_date is provided
            // Use `whereDate` to compare only the date portion of `app_date_time`
            return $query->whereDate('app_date_time', '=', date('Y-m-d', strtotime($app_date)));
        })
        ->when($search, function ($query, $search) {
            // Filter by related patient details (first_name, last_name, address, or mobile)
            return $query->whereHas('patient', function ($patientQuery) use ($search) {
                $patientQuery->where('first_name', 'like', '%' . $search . '%')
                    ->orWhere('last_name', 'like', '%' . $search . '%')
                    ->orWhere('address', 'like', '%' . $search . '%')
                    ->orWhere('mobile', 'like', '%' . $search . '%');
            });
        })
        ->latest();

    // Paginate the results
    $appointments = $appointmentQuery->simplePaginate(10);

    // Return results to the view
    return view('admin.appointment', compact('appointments', 'search', 'app_date_src'));
}

     public function trash()
    { 
        $result['data'] =   Appointment::onlyTrashed()->get();
        $result['statuses'] = DB::table('status')->get(); 
        return view('admin.appointment-trash',$result); 
    }

    public function edit_appointment(Request $request,$id='')
    {
        if ($id>0) 
        {
            $appointment = Appointment::where(['id'=>$id])->get()->first();
            $patient = Patient::where(['id'=>$appointment->patient_id])->get()->first();

            $result['app_date_time']= $appointment->app_date_time;
            $result['app_time'] = $appointment->app_date_time;
            $result['purpose'] = $appointment->purpose;
    $result['preTreatment'] = $appointment->preTreatment ; 
    $result['treatment_type'] = $appointment->treatment_type ; 
            
            //Carbon::parse($appointment->app_date_time)->format('h:i A');
            $result['id']= $appointment->id;
            $result['patient_id']= $patient->id;
            $result['first_name']= $patient->first_name;
            $result['last_name']= $patient->last_name;
            $result['imagePath']=$patient->ImagePath();
            $result['image']= $patient->image;
            $result['mobile']= $patient->mobile;
            $result['address']= $patient->address;
            $result['pin']= $patient->pin;
            //$result['preTreatment']= $patient->preTreatment;
            $result['gender_id']= $patient->gender_id;
            $result['city']= $patient->city;
            $result['state']= $patient->state;
            $result['country']= $patient->country;
            $result['age']= $patient->age;
            $result['Height']= $patient->Height;
            $result['Weight']= $patient->Weight;
            $result['BP']= $patient->BP;
            $result['Pulse']= $patient->Pulse;
            $result['BMI']= $patient->BMI;
            $result['WC']= $patient->WC;
            $result['email']= $patient->email;
            $result['status']= $appointment->status;
            $result['isApproved']= $patient->isApproved;
            
        }
        else
        {
            $result['app_date_time']='';
            $result['app_time']='';
            $result['purpose'] ='';
            $result['treatment_type'] =0;
            $result['preTreatment'] =0;
            $result['id']= '0';
            $result['patient_id'] = '0';
            $result['first_name'] = '';
            $result['last_name'] = '';
            $result['mobile']= '';
            $result['email']= '';
            $result['preTreatment']= 0;
            $result['imagePath']=asset('storage/media/NoImage.png');
            $result['image']='';
            $result['address']= '';
            $result['pin']= '';
            //$result['date_of_birth']= '';
            $result['gender_id']=0;
            $result['city']= 'Silchar';
            $result['state']= 'Assam';
            $result['country']= 'India';
            $result['age']= '';
            $result['Height']= '';
            $result['Weight']= '';
            $result['BP']= '';
            $result['Pulse']= '';
            $result['BMI']= '';
            $result['WC']= '';
            $result['isApproved']=1;
            $result['status']= '1';
        }

        $result['city_search']='';
        $result['state_search']= '';

        $result['statuses'] = DB::table('appointment_status')->get(); 
        $result['genderes'] = Gender::all(); 
       return view('admin.edit_Appointment',$result); 
    }

public function manage_appointment_process(Request $request)
{
    $request->validate([
        'app_date' => 'required',
        'app_time' => 'required',
        'purpose' => 'required',
    ]);

    // Check if we are updating or inserting
    if ($request->post('id') > 0) {
        $appointment = Appointment::find($request->post('id'));
        $msg = 'Appointment updated';
    } else {
        $appointment = new Appointment();
        $msg = 'Appointment inserted';
    }

    // Save appointment details
    $appointment->app_date_time = $request->post('app_date').' '.$request->post('app_time');
    
    $appointment->purpose = $request->post('purpose');
    $appointment->status=$request->post('status');
    $appointment->preTreatment=$request->post('preTreatment');
$appointment->treatment_type=$request->post('treatment_type'); 
    $patient_id=$request->post('patient_id');
    $rdbUpdatePatient=$request->post('rdbUpdatePatient');

    if($rdbUpdatePatient=='0' && $patient_id>0) 
    {
        $appointment->patient_id=$patient_id;
    }
    else 
    {
   
    $request->validate([
        'first_name' => 'required',
        'mobile' => 'required|digits:10',
        'address' => 'required',
        'pin' => 'required',
    ]);

/*
'mobile' => 'required|unique:patients,mobile,'.$request->post('patient_id'),
'image' => 'nullable|image|mimes:jpg,jpeg,png,gif|max:2048', // Validate the image
*/
        if($patient_id==0 || $rdbUpdatePatient=='2')
        {
            $patient = new Patient();
            $msg = 'Patient inserted';
        } 
        else
         {
            $patient = Patient::find($patient_id);
            $msg = 'Patient updated';
         } 

        $patient->first_name = $request->post('first_name');
        $patient->last_name = $request->post('last_name');
        $patient->mobile = $request->post('mobile');
        $patient->address = $request->post('address');
        $patient->pin = $request->post('pin');
        $patient->gender_id = $request->post('gender_id');
        //$patient->date_of_birth = $request->post('date_of_birth');
        $patient->city = $request->post('city');
        $patient->state = $request->post('state');
        $patient->country = $request->post('country');
        $patient->status = $request->post('status');
        $patient->age = $request->post('age');
        $patient->Height = $request->post('Height');
        $patient->Weight = $request->post('Weight');
        $patient->BP = $request->post('BP');
        $patient->Pulse = $request->post('Pulse');
        $patient->BMI = $request->post('BMI');
        $patient->WC = $request->post('WC');

        //$patient->image = $image_name;
        $patient->save();

        if ($patient_id == 0) {
            $patient->registration_number = 'DW' . str_pad($patient->id, 5, '0', STR_PAD_LEFT);
            $patient->save();
            }

        $appointment->patient_id=$patient->id;

    }

   $appointment->save();
    // Set flash message and redirect
    $request->session()->flash('message', $msg);
    return redirect('admin/appointment');
}
   public function delete(Request $request,$id)
    {
       $message='';
/*
       $orders=Order::where('appointment_id','=',$id)->get();
       $c=count($orders);
       if($c>0)
       {
            $message = $c.' Order(s) ';
       }


       $bills =Bill::where('appointment_id','=',$id)->get();

       $c=count($bills);
       if($c>0)
       {
            $message .=' and '.$c.' Bill(s) ';
       }
*/       
       $typeName=session()->get('typeName');
       
       if($message =='')
       {
        $model = Appointment::find($id);
        $model->delete();
        return redirect($typeName.'/appointment')->with('message','Appointment deleted'); 
       }
       else 
       {
        return redirect($typeName.'/appointment')->with('error','Unable to delete as '.$message.' linked with this Appointment');
       }
       
    }

    public function forceDelete(Request $request,$id)
    {
       
       $model = Appointment::withTrashed()->find($id);
       $model->forceDelete();
       $request->session()->flash('message','Appointment permantly deleted');
       return redirect('admin/appointment/trash');
    }

    public function restore(Request $request,$id)
    {
       
       $model = Appointment::withTrashed()->find($id);
       $model->restore();
       $request->session()->flash('message','Appointment Restored');
       return redirect('admin/appointment/trash');
    }

    public function status(Request $request,$status,$id)
    {
       
       $appointment = Appointment::find($id);
       $appointment->status = $status;
       $appointment->save();
       $msg='Appointment status changed ';
       if ($status==3) 
       {
        $treatment = new Treatment();
        $msg = $msg .' also Treatment inserted';
        $treatment->start_date_time = date('d/m/Y h:i A');
    $treatment->app_id = $id;
    $treatment->patient_id = $appointment->patient_id;
    $treatment->status=1;
    $treatment->type=$appointment->treatment_type;
    $treatment->remarks="start";
    $treatment->save();
        }


    $request->session()->flash('message',$msg);

    return redirect('admin/appointment');
    }

    public function updateStatus(Request $request)
    {
    $appointment = Appointment::find($request->appointment_id);

    if ($appointment) {
        $appointment->status = $request->status;
        $appointment->save();
 
        if ($request->status==3) 
       {
        $treatment = new Treatment();
        //$msg = $msg .' also Treatment inserted';
        $treatment->start_date_time = date('d/m/Y h:i A');
    $treatment->app_id = $appointment->id; 
    $treatment->patient_id = $appointment->patient_id;
    $treatment->status=1;
    $treatment->type=$appointment->treatment_type;
    $treatment->remarks="start";
    $treatment->save();
        }


        return response()->json([
            'success' => true,
            'date' => date('d/m/Y',strtotime($appointment->app_date_time)),
        ]);
    } else {
        return response()->json(['success' => false]);
    }
}

}
