<?php
namespace App\Http\Controllers;

use App\Models\OralExamination;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OralExaminationController extends Controller
{
   public function index(Request $request)
    {
        $search=$request['search'] ?? "";
        if($search !="")
        {
$oralExamination = OralExamination::where(function ($query) use ($search){
                $query->where('OralExamination', 'like', '%'.$search.'%');
            })
            ->latest()->simplepaginate(10);
        }
        else
        {   
    $oralExamination  = OralExamination::latest()->simplepaginate(10);
        }
        //$statuses = DB::table('status')->get();
        $result = compact('oralExamination','search');
        return view('admin.oralExamination',$result); 
    }
    
     public function trash()
    {
        $result['data'] =   OralExamination::onlyTrashed()->get();
        return view('admin.oralExamination-trash',$result); 
    }

    public function edit_oralExamination(Request $request,$id='')
    {
        if ($id>0) 
        {
            $arr = OralExamination::where(['id'=>$id])->get();
            $result['id']= $arr[0]->id;
            $result['OralExamination']= $arr[0]->OralExamination;
        }
        else
        {
            $result['id']='0';
            $result['OralExamination']='';
        }
        $result['statuses'] = DB::table('status')->get(); 
        return view('admin.edit_OralExamination',$result); 
    }

    public function manage_oralExamination_process(Request $request)
    {
        
       $request->validate([
        'OralExamination'=>'required|unique:oral_examinations,OralExamination,'.$request->post('id'),
       ]
       ); 

       if ($request->post('id')>0) 
       {
           $model = OralExamination::find($request->post('id'));
           $msg = 'OralExamination updated';
       }
       else
       {
            $model = new OralExamination();
            $msg = 'OralExamination Inserted';
       }
       
       $model->OralExamination = $request->post('OralExamination');
       $model->save();
       $request->session()->flash('message',$msg);
       return redirect('admin/oralExamination');
    }

   public function delete(Request $request,$id)
    {
             $message='';
/*
       $customers=Customer::where('OralExamination','=',$id)->get();
       $c=count($customers);
       if($c>0)
       {
            $message = $c.' Customer(s) ';
       }

       $villageAgents =VillageAgent::where('OralExamination','=',$id)->get();

       $c=count($villageAgents);
       if($c>0)
       {
            $message .=' and '.$c.' Village Agent(s) ';
       }
       

       $salesAgents =SalesAgent::where('OralExamination','=',$id)->get();

       $c=count($salesAgents);
       if($c>0)
       {
            $message .=' and '.$c.' Sale Agents(s) ';
       }
  */     
       $typeName=session()->get('typeName');
       
       if($message =='')
       {
        $model = OralExamination::find($id);
        $model->delete();
        return redirect($typeName.'/oralExamination')->with('message','OralExamination deleted'); 
       }
       else 
       {
        return redirect($typeName.'/oralExamination')->with('error','Unable to delete as '.$message.' linked with this OralExamination');
       }

       
       $model = OralExamination::find($id);
       $model->delete();
       $request->session()->flash('message','OralExamination deleted');
       return redirect('admin/oralExamination');
    }

    public function forceDelete(Request $request,$id)
    {
       
       $model = OralExamination::withTrashed()->find($id);
       $model->forceDelete();
       $request->session()->flash('message','OralExamination permantly deleted');
       return redirect('admin/oralExamination/trash');
    }

    public function restore(Request $request,$id)
    {
       
       $model = OralExamination::withTrashed()->find($id);
       $model->restore();
       $request->session()->flash('message','OralExamination Restored');
       return redirect('admin/oralExamination/trash');
    }

    public function status(Request $request,$status,$id)
    {
       
       $model = OralExamination::find($id);
       $model->status = $status;
       $model->save();
       $request->session()->flash('message','OralExamination status changed');
       return redirect('admin/OralExamination');
    }
}
