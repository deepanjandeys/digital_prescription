;
<?php $__env->startSection('page_title','Appointment'); ?>
<?php $__env->startSection('appointment_select','active'); ?>
<?php $__env->startSection('master_tran','master'); ?>
<?php $__env->startSection('container'); ?>

<?php if(session()->has('message')): ?>
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  <?php echo e(session('message')); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
 <span class="badge badge-pill badge-danger">Error Message</span>
  <?php echo e(session('error')); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
<?php endif; ?>
<style type="text/css">
    th  
    {
        background: #faebd7;
    }
</style>
<h2 class="title-1 m-b-10">Appointment</h2>
<div class="row">
    <div class="col-1">
<a href="<?php echo e(url('admin/appointment/edit_appointment')); ?>" >
<button type="button" class="btn btn-success"> <i class="fe fe-plus"></i> Add </button>
</a>
</div>
<div class="col-1">
<a href="<?php echo e(url('admin/appointment/trash')); ?>" >
<button type="button" class="btn btn-danger">Trash <i class="fe fe-folder"></i></button>
</a>
        
    </div>
    <div class="col-10">
<form action="" method="get" >
    <div class="row">
        <div class="col-2">
            <label for="app_date_src" class="control-label mb-1">Appointment Date <a href="javascript:void(0)" onclick="clear_app_date()">Clear</a></label> 
        </div>
        <div class="col-2">
            <input id="app_date_src" name="app_date_src" type="text" value="<?php echo e(old('app_date_src', $app_date_src)); ?>" class="form-control datetimepicker" >
        </div>
        <div class="col-4">
            <input type="search" name="search" class="form-control" placeholder="type to search" value="<?php echo e($search); ?>">        
        </div>
        <div class="col-4">
        <button class="btn btn-primary">Search <i class="fe fe-search"></i></button>   
        <a href="<?php echo e(url('admin/appointment')); ?>" >
            <button type="button" class="btn btn-primary">Reset <i class="fas fa-sync-alt"></i></button>
        </a>     
        </div>
    </div>
</form>
        
    </div>
</div>
         <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE -->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                        <th colspan="3" style="text-align:center;background: #faebd7;">Appointment </th>
                                        <th colspan="6" style="text-align:center;background: #ff9999;">Patients Details</th>
                                            </tr>
                                            <tr>
                                            <th>Action</th>
                                            <th>Date Time</th>
                                            <th>Purpose</th>
                                               <th>Reg. No.</th>
                                                <th>Name</th>
                                                <th>Mobile</th>
                                                <th>Address</th>
                                                <th>Gender/Age</th>
                                                
                                                <th>status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <a href="<?php echo e(url('admin/appointment/edit_appointment/')); ?>/<?php echo e($list->id); ?>" title="Edit">
                                                    <button type="button" class="btn btn-success"><i class="fe fe-edit"></i></button>
                                                    </a>
                                                    
                                                    <a href="<?php echo e(url('admin/appointment/delete/')); ?>/<?php echo e($list->id); ?>" title="Trash">
                                                    <button type="button" class="btn btn-danger"><i class="fe fe-trash"></i></button>
                                                    </a>
                                                </td>
<td><?php echo e($list->app_date_time); ?> </td>
<td><?php echo e($list->purpose); ?> 
<?php if($list->treatment): ?><a href="<?php echo e(url('admin/treatment/edit_treatment/')); ?>/<?php echo e($list->treatment->id); ?>">Treatment</a>
<?php endif; ?>
</td>
<td>
<?php echo e($list->patient->registration_number); ?>

</td>
<td><?php echo e($list->patient->first_name); ?> <?php echo e($list->patient->last_name); ?></td>
<td><?php echo e($list->patient->mobile); ?></td>
<td><?php echo e($list->patient->address); ?> / <?php echo e($list->patient->pin); ?> <br>/ <?php echo e($list->patient->city); ?> , <?php echo e($list->patient->state); ?>, <?php echo e($list->patient->country); ?></td>
<td class="text-end">
    <?php echo e($list->patient->gender['name']); ?>/
    <?php echo e($list->patient->age); ?>

</td>
<td>
     <?php
        $sc = ''; 
        $st = '';
    ?>
<?php if($list->status == 1): ?>
        <?php
            $sc = 'btn-primary'; 
            $st = 'Active';
        ?>
    <?php elseif($list->status == 2): ?>
        <?php
            $sc = 'btn-info'; 
            $st = 'Appeared';
        ?>
    <?php elseif($list->status == 3): ?>
        <?php
            $sc = 'btn-warning'; 
            $st = 'Start';
        ?>
    <?php elseif($list->status == 4): ?>
        <?php
            $sc = 'btn-success'; 
            $st = 'Complete';
        ?>
    <?php elseif($list->status == 5): ?>
        <?php
            $sc = 'btn-danger'; 
            $st = 'Cancel';
        ?>
    <?php else: ?> 
        <?php
            $sc = 'btn-secondary'; 
            $st = 'No status';
        ?>
    <?php endif; ?>
    <div class="btn-group">
<button type="button" class="btn <?php echo e($sc); ?> dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo e($st); ?></button>
<div class="dropdown-menu">
<a class="dropdown-item" href="<?php echo e(url('admin/appointment/status/1/')); ?>/<?php echo e($list->id); ?>">Make Active</a>
<a class="dropdown-item" href="<?php echo e(url('admin/appointment/status/2/')); ?>/<?php echo e($list->id); ?>">Make Appeared</a>
<a class="dropdown-item" href="<?php echo e(url('admin/appointment/status/3/')); ?>/<?php echo e($list->id); ?>">Make Start Treatment</a>
<a class="dropdown-item" href="<?php echo e(url('admin/appointment/status/4/')); ?>/<?php echo e($list->id); ?>">Make Complete</a>
<div class="dropdown-divider"></div>
<a class="dropdown-item" href="<?php echo e(url('admin/appointment/status/5/')); ?>/<?php echo e($list->id); ?>">Make Cancel</a>
</div>
</div>
</td>
 </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>
                                </div>
                                <?php echo e($appointments->links()); ?>

                                <!-- END DATA TABLE-->
                            </div>
                        </div>
<script type="text/javascript">
    function clear_app_date()
    {
        $('#app_date_src').val('');
    }
</script>                        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\prescription\resources\views/admin/appointment.blade.php ENDPATH**/ ?>