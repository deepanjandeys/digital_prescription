;
<?php $__env->startSection('page_title','Edit Treatment'); ?>
<?php $__env->startSection('treatment_select','active'); ?>
<?php $__env->startSection('master_tran','master'); ?>
<?php $__env->startSection('container'); ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>    

<!-- Optional CSS for added tags -->
<style>
    .tag {
        display: inline-block;
        background-color: #007bff;
        color: white;
        padding: 5px;
        margin: 5px;
        border-radius: 5px;
    }
    .tag .close {
        margin-left: 10px;
        cursor: pointer;
    }
</style>

<!-- Add this in your Blade file before your custom script -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<h2 class="title-1 m-b-10">Edit Treatment</h2>
<a href="<?php echo e(url('admin/treatment')); ?>" >
<button type="button" class="btn btn-success"> <i class="fe fe-arrow-left"></i> Back</button>
</a>
<div class="row m-t-30">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(route('admin.manage_treatment_process')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <!-- Other input fields ... -->

                    <div class="row">
                        <div class="col-md-4 form-group" style="background-color:#ffe5b4;padding-top: 10px;">
                           <h3 class="text-primary">Medical History</h3>
                            <div class="row">
                          
                    <div class="col-md-3 form-group">
                        <label for="Height" class="control-label mb-1">Height</label>
                    </div>
                    <div class="col-md-3 form-group">
                        <input id="Height" name="Height" type="text" class="form-control" value="">  
                    </div>

                    <div class="col-md-3 form-group">
                        <label for="Weight" class="control-label mb-1">Weight</label>
                    </div>
                    <div class="col-md-3 form-group">
                        <input id="Weight" name="Weight" type="text" class="form-control" value="1">
                    </div>
                    <div class="col-md-3 form-group">
                    <label for="BP" class="control-label mb-1">BP</label>
                    </div>
                    <div class="col-md-3 form-group">
                        <input id="BP" name="BP" type="text" class="form-control" value="">    
                    </div>
                    <div class="col-md-3 form-group">
                        <label for="Pulse" class="control-label mb-1">Pulse</label>
                    </div>
                    <div class="col-md-3 form-group">
                        <input id="Pulse" name="Pulse" type="text" class="form-control" value="1">
                    </div>
                    <div class="col-md-3 form-group">
                        <label for="BMI" class="control-label mb-1">BMI</label>
                    </div>
                    <div class="col-md-3 form-group">
                        <input id="BMI" name="BMI" type="text" class="form-control" value="">
                    </div>

                    <div class="col-md-3 form-group">
                    <label for="WC" class="control-label mb-1">WC</label>
                    </div>
                    <div class="col-md-3 form-group">
                    <input id="WC" name="WC" type="text" class="form-control" value="1">
                   </div>
                        <hr/>
                       
<div class="col-md-12 form-group">

<label for="medical-history-input" class="control-label mb-1">Medical Histories</label>
        <!-- Input for autocomplete -->
<input type="text" id="medical-history-input" class="form-control" placeholder="Type medical history...">

<!-- Area where selected medical history will be displayed -->
<div id="selected-medical-histories"></div>
                            
</div>
<div class="col-md-12 form-group">

<label for="oral-examination-input" class="control-label mb-1">Oral Examinations</label>
        <!-- Input for autocomplete -->
<input type="text" id="oral-examination-input" class="form-control" placeholder="Type Oral Examinations...">

<!-- Area where selected Oral examinations will be displayed -->
<div id="selected-oral-examinations"></div>
                            
</div>
      
<div class="col-md-12 form-group">

<label for="advice-input" class="control-label mb-1">Advices</label>
        <!-- Input for autocomplete -->
<input type="text" id="advice-input" class="form-control" placeholder="Type Advices...">

<!-- Area where selected Oral examinations will be displayed -->
<div id="selected-advices"></div>
                            
</div>     
<div class="col-md-12 form-group">
      
<label for="type" class="control-label mb-1">Treatment Type</label>
                            <select id="type" name="type" class="form-control">
                                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($list->id); ?>" 
                                        <?php echo e(old('type', $type) == $list->id ? 'selected' : ''); ?>>
                                        <?php echo e($list->TreatmentType); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
</div>                      
<div class="col-md-12 form-group">


<label class="control-label mb-1">Appointment Time <?php echo e($app_date_time); ?></label>
<label for="start_date" class="control-label mb-1">Start Time</label>
<div class="row">
    <div class="col-6">
                <input id="start_date" name="start_date" type="text" value="<?php echo e(old('start_date', $start_date_time)); ?>" placeholder="Start time" class="form-control datetimepicker" >
            <?php $__errorArgs = ['start_date_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <span id="spnStartDateErrMsg" class="text-danger font-weight-bold"></span>
    </div>
    <div class="col-6">
        <input id="start_time" name="start_time" placeholder="Start Time" type="text"  
        value="<?php echo e(old('start_time', $start_time ? \Carbon\Carbon::parse($start_time)->format('h:i A') : '')); ?>" 
        class="form-control time" step="600">
    <?php $__errorArgs = ['start_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <span id="spnStartTimeErrMsg" class="text-danger font-weight-bold"></span>
    </div>
</div>                 
</div>  
<div class="col-md-12 form-group">

<label for="end_date" class="control-label mb-1">End Time</label>
<div class="row">
    <div class="col-6">
        <input id="end_date" name="end_date" type="text" value="<?php echo e(old('end_date', $end_date_time)); ?>" placeholder="End Date" class="form-control datetimepicker" >
            <?php $__errorArgs = ['end_date_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <span id="spnEndDateErrMsg" class="text-danger font-weight-bold"></span>
    </div>
    <div class="col-6">
        <input id="end_time" name="end_time" placeholder="End Time" type="text"  
        value="<?php echo e(old('end_time', $end_time ? \Carbon\Carbon::parse($end_time)->format('h:i A') : '')); ?>" 
        class="form-control time" step="600">
    <?php $__errorArgs = ['end_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <span id="spnEndTimeErrMsg" class="text-danger font-weight-bold"></span>
    </div>
</div>          
</div>   
<div class="col-md-12 form-group">

<label for="remarks" class="control-label mb-1">Remarks</label>
<input id="remarks" name="remarks" type="text" value="<?php echo e(old('remarks', $remarks)); ?>" class="form-control" placeholder="Remarks" >
            <?php $__errorArgs = ['remarks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <span id="spnRemarksErrMsg" class="text-danger font-weight-bold"></span>                       
</div>
<div class="col-md-12 form-group">

<label for="next_appointment_date" class="control-label mb-1">Next Appointment</label>
<div class="row">
    <div class="col-6">
        <input type="hidden" name="NextAppId" id="NextAppId" value="<?php echo e($NextAppId); ?>">
        <input id="next_appointment_date" name="next_appointment_date" type="text" value="<?php echo e(old('next_appointment_date', $next_appointment_date)); ?>" placeholder="next App Date" class="form-control datetimepicker" >
            <?php $__errorArgs = ['next_appointment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <span id="spnNextAppointmentDateErrMsg" class="text-danger font-weight-bold"></span>
    </div>
    <div class="col-6">
        <input id="NextAppointment_time" name="NextAppointment_time" placeholder="Time" type="text"  
        value="<?php echo e(old('NextAppointment_time', $NextAppointment_time ? \Carbon\Carbon::parse($NextAppointment_time)->format('h:i A') : '')); ?>" 
        class="form-control time" step="600">
    <?php $__errorArgs = ['NextAppointment_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <span id="spnEndTimeErrMsg" class="text-danger font-weight-bold"></span>
    </div>
</div>                   
</div>   
<div class="col-md-12 form-group">
                            <label for="status" class="control-label mb-1">Status</label>
                            <select id="status" name="status" class="form-control">
                                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($list->id); ?>" 
                                        <?php echo e(old('status', $status) == $list->id ? 'selected' : ''); ?>>
                                        <?php echo e($list->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
<input type="hidden" name="callBy" value="0">
<input type="submit" id="save" class="btn btn-primary" value="Save">
</div>
</div>
<div class="col-md-8 form-group">
                            
<p class="bg-info text-light p-2">Patient Details</p>   
      <div class="row">
          <div class="col-12">
              <label>Patient name</label>
              <span class="text-primary"><?php echo e($first_name); ?> <?php echo e($last_name); ?></span>
          </div>
          <div class="col-4">
              <label>Age</label>
              <span class="text-primary"><?php echo e($age); ?> / <?php echo e($gender); ?></span>
          </div>
          <div class="col-8">
              <label>Contact</label>
              <span class="text-primary"><?php echo e($mobile); ?> </span>
          </div>
      </div>    

<hr>    

<div class="row mb-1">
          <div class="col-6">
              <label>Teeth</label>
              <div class="row">
                  <div class="col-6">
                      <input type="text" class="form-control" name="teeth_UL" id="teeth_UL" placeholder="Teeth Upper Left" value="<?php echo e(old('teeth_UL', $teeth_UL)); ?>">
                  </div>
                  <div class="col-6">
                      <input type="text" placeholder="Teeth Upper Right" class="form-control" name="teeth_UR" id="teeth_UR" value="<?php echo e(old('teeth_UR', $teeth_UR)); ?>">
                  </div>
                  <div class="col-12"><hr></div>
                  <div class="col-6">
                      <input type="text" class="form-control" name="teeth_LL" id="teeth_LL" placeholder="Teeth Lower Left" value="<?php echo e(old('teeth_LL', $teeth_LL)); ?>">
                  </div>
                  <div class="col-6">
                      <input type="text" class="form-control" name="teeth_LR" id="teeth_LR" placeholder="Teeth Lower Right" value="<?php echo e(old('teeth_LR', $teeth_LR)); ?>">
                  </div>
              </div>
          </div>
          <div class="col-6">
              <label>Examination</label>
              <input type="text" class="form-control" name="teeth_exam" id="teeth_exam" placeholder="Teet Exam" value="<?php echo e(old('teeth_exam', $teeth_exam)); ?>">
          </div>
      </div>                           

    <table id="medicine-grid" class="table table-bordered">
    <thead>
        <tr>
            <th>Medicine</th>
            <th>Dosage</th>
            <th>Frequency</th>
            <th colspan="2">Duration</th>
            <th>Timing</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <!-- Existing rows will be loaded dynamically via Ajax, or pre-filled if needed -->
        <tr class="medicine-row d-none">
            <td>
                <input type="hidden" class="medicine_id" name="medicine_id[]" value="">
            </td>
            <td>
                <input type="text" class="form-control medicine-autocomplete" name="Medicine[]" placeholder="Type medicine...">
            </td>
            <td>
                <input type="text" class="form-control" name="Dosage[]" placeholder="Dosage">
            </td>
            <td>
                <input type="text" class="form-control" name="frequency[]" placeholder="frequency">
            </td>
            <td>
                <button type="button" class="remove-medicine btn btn-danger remove-row"><i class="fe fe-trash"></i></button>
            </td>
        </tr>
    </tbody>
    
</table>

<div style="text-align:right;">
    <span class="text-danger font-weight-bold" id="spnSaveMessage"></span>
    <input type="radio" name="print_with_head" value="0">&nbsp;Without Head
    <input type="radio" name="print_with_head" value="1">&nbsp;With Head
    <a href='<?php echo e(url("admin/treatment/print_prescription")); ?>/<?php echo e($id); ?>' class="btn btn-info" target="_blank">Print</a>
    <!-- Save All Button -->
<button type="button" id="save-all" class="btn btn-primary">Save All Medicine</button>
</div>
</div>
</div>
 
<input type="hidden" name="id" id="id" value="<?php echo e($id); ?>">
<input type="hidden" id="treatment_id" value="<?php echo e($id); ?>"/>
</form>
</div>
</div>
</div>
</div>
<script type="text/javascript">
$(document).ready(function() {
    var treatmentId = $("#treatment_id").val(); // Get the treatment_id value
    var addedMedicalHistories = []; // Array to hold IDs of already added medical histories

    // Fetch existing medical histories on page load
    loadExistingMedicalHistories(treatmentId);

    $("#medical-history-input").autocomplete({
        source: function(request, response) {
            $.ajax({
                url: '<?php echo e(url("/get-medical-history")); ?>',
                type: 'GET',
                data: {
                    term: request.term
                },
                success: function(data) {
                    // Filter out medical histories that are already added
                    var filteredData = $.map(data, function(item) {
                        if (addedMedicalHistories.indexOf(item.id) === -1) { // Check if item is not already added
                            return {
                                label: item.MedicalHistory,
                                value: item.id, // Pass the medical history id as the value
                                medicalHistory: item.MedicalHistory
                            };
                        }
                    });
                    response(filteredData);
                }
            });
        },
        minLength: 2,
        select: function(event, ui) {
            var treatmentId = $("#treatment_id").val(); // Get the treatment_id value
            
            addMedicalHistoryTag(ui.item.medicalHistory, ui.item.value);
            saveMedicalHistory(treatmentId, ui.item.value); // Save selected medical history id

            // Add the selected medical history to the list of added histories
            addedMedicalHistories.push(ui.item.value);

            $(this).val(''); // Clear input
            return false;
        }
    });

    function loadExistingMedicalHistories(treatmentId) {
        $.ajax({
            url: '<?php echo e(url("/get-treatment-medical-histories")); ?>/' + treatmentId,
            type: 'GET',
            success: function(data) {
                // Loop through the returned medical histories and append them as tags
                $.each(data, function(index, item) {
                    addMedicalHistoryTag(item.MedicalHistory, item.id);
                    addedMedicalHistories.push(item.id); // Add to the array of added histories
                });
            },
            error: function(error) {
                console.error("Error fetching existing medical histories:", error);
            }
        });
    }

    function addMedicalHistoryTag(medicalHistory, medicalHistoryId) {
        var tagHtml = '<span class="tag" data-id="' + medicalHistoryId + '">' + medicalHistory + 
                      '<span class="close">&times;</span></span>';
        $("#selected-medical-histories").append(tagHtml);
    }

    function saveMedicalHistory(treatmentId, medicalHistoryId) {
        $.ajax({
            url: '<?php echo e(url("/save-treatment-medical-history")); ?>',
            type: 'POST',
            data: {
                _token: '<?php echo e(csrf_token()); ?>', // Include CSRF token for security
                treatment_id: treatmentId,
                medical_history_id: medicalHistoryId
            },
            success: function(response) {
                console.log("Medical history saved successfully.");
            },
            error: function(error) {
                console.error("Error saving medical history:", error);
            }
        });
    }

    // Function to remove medical history from the database
    function removeMedicalHistory(treatmentId, medicalHistoryId) {
        $.ajax({
            url: '<?php echo e(url("/delete-treatment-medical-history")); ?>', // Backend route for deletion
            type: 'POST',
            data: {
                _token: '<?php echo e(csrf_token()); ?>', // Include CSRF token for security
                treatment_id: treatmentId,
                medical_history_id: medicalHistoryId
            },
            success: function(response) {
                console.log("Medical history removed successfully.");
                // Remove the medical history from the added list
                var index = addedMedicalHistories.indexOf(medicalHistoryId);
                if (index > -1) {
                    addedMedicalHistories.splice(index, 1);
                }
            },
            error: function(error) {
                console.error("Error removing medical history:", error);
            }
        });
    }

    // Remove tag and delete from table on close click
    $(document).on('click', '.tag .close', function() {
        var medicalHistoryId = $(this).parent().data('id'); // Get medical history ID from tag
        var treatmentId = $("#treatment_id").val(); // Get treatment ID from hidden input

        // Remove the tag from the UI
        $(this).parent().remove();

        // Call function to remove the medical history from the database
        removeMedicalHistory(treatmentId, medicalHistoryId);
    });
});


$(document).ready(function() {
    var treatmentId = $("#treatment_id").val(); // Get the treatment_id value
    var addedOralExaminations = []; // Array to hold IDs of already added oral examinations

    // Fetch existing oral examinations on page load
    loadExistingOralExaminations(treatmentId);

    $("#oral-examination-input").autocomplete({
        source: function(request, response) {
            $.ajax({
                url: '<?php echo e(url("/get-oral-examination")); ?>', // Assuming you have a route to get the oral examinations
                type: 'GET',
                data: {
                    term: request.term
                },
                success: function(data) {
                    // Filter out oral examinations that are already added
                    var filteredData = $.map(data, function(item) {
                        if (addedOralExaminations.indexOf(item.id) === -1) { // Check if item is not already added
                            return {
                                label: item.OralExamination,
                                value: item.id, // Pass the oral examination id as the value
                                oralExamination: item.OralExamination
                            };
                        }
                    });
                    response(filteredData);
                }
            });
        },
        minLength: 2,
        select: function(event, ui) {
            var treatmentId = $("#treatment_id").val(); // Get the treatment_id value
            
            addOralExaminationTag(ui.item.oralExamination, ui.item.value);
            saveOralExamination(treatmentId, ui.item.value); // Save selected oral examination id

            // Add the selected oral examination to the list of added examinations
            addedOralExaminations.push(ui.item.value);

            $(this).val(''); // Clear input
            return false;
        }
    });

    function loadExistingOralExaminations(treatmentId) {
        $.ajax({
            url: '<?php echo e(url("/get-treatment-oral-examinations")); ?>/' + treatmentId,
            type: 'GET',
            success: function(data) {
                // Loop through the returned oral examinations and append them as tags
                $.each(data, function(index, item) {
                    addOralExaminationTag(item.OralExamination, item.id);
                    addedOralExaminations.push(item.id); // Add to the array of added examinations
                });
            },
            error: function(error) {
                console.error("Error fetching existing oral examinations:", error);
            }
        });
    }

    function addOralExaminationTag(oralExamination, oralExaminationId) {
        var tagHtml = '<span class="tag" data-id="' + oralExaminationId + '">' + oralExamination + 
                      '<span class="close">&times;</span></span>';
        $("#selected-oral-examinations").append(tagHtml);
    }

    function saveOralExamination(treatmentId, oralExaminationId) {
        $.ajax({
            url: '<?php echo e(url("/save-treatment-oral-examination")); ?>', // Your route to save treatment oral examination
            type: 'POST',
            data: {
                _token: '<?php echo e(csrf_token()); ?>', // Include CSRF token for security
                treatment_id: treatmentId,
                oral_examination_id: oralExaminationId
            },
            success: function(response) {
                console.log("Oral examination saved successfully.");
            },
            error: function(error) {
                console.error("Error saving oral examination:", error);
            }
        });
    }

    // Function to remove oral examination from the database
    function removeOralExamination(treatmentId, oralExaminationId) {
        $.ajax({
            url: '<?php echo e(url("/delete-treatment-oral-examination")); ?>', // Backend route for deletion
            type: 'POST',
            data: {
                _token: '<?php echo e(csrf_token()); ?>', // Include CSRF token for security
                treatment_id: treatmentId,
                oral_examination_id: oralExaminationId
            },
            success: function(response) {
                console.log("Oral examination removed successfully.");
                // Remove the oral examination from the added list
                var index = addedOralExaminations.indexOf(oralExaminationId);
                if (index > -1) {
                    addedOralExaminations.splice(index, 1);
                }
            },
            error: function(error) {
                console.error("Error removing oral examination:", error);
            }
        });
    }

    // Remove tag and delete from table on close click
    $(document).on('click', '.tag .close', function() {
        var oralExaminationId = $(this).parent().data('id'); // Get oral examination ID from tag
        var treatmentId = $("#treatment_id").val(); // Get treatment ID from hidden input

        // Remove the tag from the UI
        $(this).parent().remove();

        // Call function to remove the oral examination from the database
        removeOralExamination(treatmentId, oralExaminationId);
    });

//////////////////////////
    $(document).ready(function() {
    var treatmentId = $("#treatment_id").val(); // Get the treatment_id value
    var addedAdvices = []; // Array to hold IDs of already added advices

    // Fetch existing advices on page load
    loadExistingAdvices(treatmentId);

    $("#advice-input").autocomplete({
        source: function(request, response) {
            $.ajax({
                url: '<?php echo e(url("/get-advice")); ?>', // Assuming you have a route to get the advices
                type: 'GET',
                data: {
                    term: request.term
                },
                success: function(data) {
                    // Filter out advices that are already added
                    var filteredData = $.map(data, function(item) {
                        if (addedAdvices.indexOf(item.id) === -1) { // Check if item is not already added
                            return {
                                label: item.Advice,
                                value: item.id, // Pass the advice id as the value
                                advice: item.Advice
                            };
                        }
                    });
                    response(filteredData);
                }
            });
        },
        minLength: 2,
        select: function(event, ui) {
            var treatmentId = $("#treatment_id").val(); // Get the treatment_id value
            
            addAdviceTag(ui.item.advice, ui.item.value);
            saveAdvice(treatmentId, ui.item.value); // Save selected advice id

            // Add the selected advice to the list of added advices
            addedAdvices.push(ui.item.value);

            $(this).val(''); // Clear input
            return false;
        }
    });

    function loadExistingAdvices(treatmentId) {
        $.ajax({
            url: '<?php echo e(url("/get-treatment-advices/")); ?>/' + treatmentId,
            type: 'GET',
            success: function(data) {
                // Loop through the returned advices and append them as tags
                $.each(data, function(index, item) {
                    addAdviceTag(item.Advice, item.id);
                    addedAdvices.push(item.id); // Add to the array of added advices
                });
            },
            error: function(error) {
                console.error("Error fetching existing advices:", error);
            }
        });
    }

    function addAdviceTag(advice, adviceId) {
        var tagHtml = '<span class="tag" data-id="' + adviceId + '">' + advice + 
                      '<span class="close">&times;</span></span>';
        $("#selected-advices").append(tagHtml);
    }

    function saveAdvice(treatmentId, adviceId) {
        $.ajax({
            url: '<?php echo e(url("/save-treatment-advice")); ?>', // Your route to save treatment advice
            type: 'POST',
            data: {
                _token: '<?php echo e(csrf_token()); ?>', // Include CSRF token for security
                treatment_id: treatmentId,
                adviced_id: adviceId
            },
            success: function(response) {
                console.log("Advice saved successfully.");
            },
            error: function(error) {
                console.error("Error saving advice:", error);
            }
        });
    }

    // Function to remove advice from the database
    function removeAdvice(treatmentId, adviceId) {
        $.ajax({
            url: '<?php echo e(url("/delete-treatment-advice")); ?>', // Backend route for deletion
            type: 'POST',
            data: {
                _token: '<?php echo e(csrf_token()); ?>', // Include CSRF token for security
                treatment_id: treatmentId,
                adviced_id: adviceId
            },
            success: function(response) {
                console.log("Advice removed successfully.");
                // Remove the advice from the added list
                var index = addedAdvices.indexOf(adviceId);
                if (index > -1) {
                    addedAdvices.splice(index, 1);
                }
            },
            error: function(error) {
                console.error("Error removing advice:", error);
            }
        });
    }

    // Remove tag and delete from table on close click
    $(document).on('click', '.tag .close', function() {
        var adviceId = $(this).parent().data('id'); // Get advice ID from tag
        var treatmentId = $("#treatment_id").val(); // Get treatment ID from hidden input

        // Remove the tag from the UI
        $(this).parent().remove();

        // Call function to remove the advice from the database
        removeAdvice(treatmentId, adviceId);
    });
});


});

$(document).ready(function () {
    var treatmentId = $("#treatment_id").val();
    
    // Load existing medicines for the treatment
    // Load existing medicines for the treatment
    function loadExistingMedicines(treatmentId) {
        $.ajax({
            url: '<?php echo e(url("/get-treatment-medicines")); ?>/' + treatmentId,
            type: 'GET',
            success: function (data) {
                //console.log(data);
                $.each(data, function (index, item) {
                    addMedicineRow(item.Medicine, item.Dosage, item.frequency, item.duration_quantity, item.duration_unit,item.timing, item.medicine_id);
                });
                addMedicineRow('', {morning: false, noon: false, night: false},0,0, 0, null,0);  // Add empty row for new input
            },
            error: function (error) {
                console.error("Error loading existing medicines:", error);
            }
        });
    }


  // Add a medicine row to the table
  function addMedicineRow(medicineName, dosage, frequency, durationQuantity, durationUnit,timing, medicineId) {
    //console.log(medicineName+' '+ dosage+' '+ frequency+' '+ durationQuantity+' '+ durationUnit+ ' '+ medicineId);
    //console.log(dosage);

    var ds = medicineId == 0 ? "d-none" : "";  // Hide button for new rows

    // Set default values for dosage and duration to avoid null errors
    dosage = dosage || { morning: false, noon: false, night: false };
    durationQuantity = durationQuantity || '';  // Set default to empty if not provided
    durationUnit = durationUnit || 'days';  // Default to "days" if not provided

    var newRow = `
        <tr class="medicine-row">
            <td>
                <input type="hidden" class="medicine_id" name="medicine_id[]" value="${medicineId}">
                <input type="text" class="form-control medicine-autocomplete" name="Medicine[]" placeholder="Type medicine..." value="${medicineName}">
            </td>
            <td>
                <label><input type="checkbox" name="dosage[morning][]" value="1" ${dosage.morning==1 ? 'checked' : ''}></label>
                <label><input type="checkbox" name="dosage[noon][]" value="1" ${dosage.noon==1 ? 'checked' : ''}></label>
                <label><input type="checkbox" name="dosage[night][]" value="1" ${dosage.night==1 ? 'checked' : ''}></label>
            </td>
            <td>
                <select class="form-control" name="frequency[]">
                    <option value="0" ${frequency == 0 ? 'selected' : ''}></option>
                    <option value="1" ${frequency == 1 ? 'selected' : ''}>Daily</option>
                    <option value="2" ${frequency == 2 ? 'selected' : ''}>Weekly</option>
                    <option value="3" ${frequency == 3 ? 'selected' : ''}>Monthly</option>
                    <option value="4" ${frequency == 4 ? 'selected' : ''}>Yearly</option>
                </select>
            </td>
            <td>
                <input type="number" class="form-control duration-quantity" name="duration_quantity[]" min="1" placeholder="Enter number" value="${durationQuantity}" style="width:100px;">
            </td>
            <td>
                <select class="form-control duration-unit" name="duration_unit[]">
    <option value="0" ${durationUnit == 0 ? 'selected' : ''}></option>
    <option value="1" ${durationUnit == 1 ? 'selected' : ''}>Days</option>
    <option value="2" ${durationUnit == 2 ? 'selected' : ''}>Weeks</option>
    <option value="3" ${durationUnit == 3 ? 'selected' : ''}>Months</option>
    <option value="4" ${durationUnit == 4 ? 'selected' : ''}>Years</option>
</select>

            </td>
            <td>
                <label><input type="radio" name="timing[${medicineId}]" value="0" ${timing === 0 ? 'checked' : ''}> BF</label>
                <label><input type="radio" name="timing[${medicineId}]" value="1" ${timing === 1 ? 'checked' : ''}> AF</label>
            </td>
            <td>
                <button type="button" class="remove-medicine btn btn-danger ${ds}"><i class="fe fe-trash"></i></button>
            </td>
        </tr>
    `;
    $('#medicine-grid tbody').append(newRow);
    initializeAutocomplete(); // If you need to initialize the autocomplete again
}


// Add new row when user types in the last row
$(document).on('input', '.medicine-autocomplete', function () {
    var rows = $('#medicine-grid tbody tr:visible');
    var lastRow = rows.last();

    // Check if user is typing and the row is not autofilled
    var isTyping = $(this).data('isTyping') || false;

    // Make the remove button in the last row visible only if the user is typing (not autocomplete)
    if (isTyping) {
        lastRow.find('.remove-medicine').removeClass('d-none');
    }

    // If the user is typing in the current last row, add a new row
    if ($(this).closest('tr').is(lastRow)) {
        addMedicineRow('', '', '', 0);  // Add a new row with remove button hidden (d-none)
        
        // Keep the remove button hidden for the newly added row
        var newLastRow = $('#medicine-grid tbody tr:visible').last();
        newLastRow.find('.remove-medicine').addClass('d-none');
    }
});

// Detect when the user is typing manually (not autofill)
$(document).on('keydown', '.medicine-autocomplete', function () {
    $(this).data('isTyping', true);  // Set the flag that user is typing
});

// Detect when the user uses autocomplete or selects an option
$(document).on('autocompletechange', '.medicine-autocomplete', function () {
    $(this).data('isTyping', false);  // Reset the flag when autocomplete is used
});


    // Initialize autocomplete for all medicine rows
    function initializeAutocomplete() {
        $('.medicine-autocomplete').each(function () {
            $(this).autocomplete({
                source: function (request, response) {
                    var addedMedicines = [];
                    // Collect all added medicine names to exclude them from the autocomplete results
                    $('#medicine-grid tbody tr:visible').each(function () {
                        var existingMedicine = $(this).find('input[name="Medicine[]"]').val();
                        if (existingMedicine) {
                            addedMedicines.push(existingMedicine);
                        }
                    });

                    // AJAX request for medicine autocomplete
                    $.ajax({
                        url: '<?php echo e(url("/get-medicines")); ?>',
                        type: 'GET',
                        data: { term: request.term },
                        success: function (data) {
                            // Filter out already added medicines
                            response($.map(data, function (item) {
                                if (addedMedicines.indexOf(item.Medicine) === -1) {
                                    return {
                                        label: item.Medicine,
                                        value: item.id
                                    };
                                }
                            }));
                        }
                    });
                },
                minLength: 2,
                select: function (event, ui) {
                    $(this).closest('tr').find('.medicine_id').val(ui.item.value);
                    $(this).val(ui.item.label);
                    $(this).data('isTyping', false);  // Reset typing flag
                    return false;  // Prevent the autocomplete input from appending extra text
                }

            });
        });
    }

  // Save all rows with updated fields
$('#save-all').on('click', function () {
   // debugger;
    var rows = [];
    $('#medicine-grid tbody tr:visible').each(function () {
        var medicine_id = $(this).find('input.medicine_id').val();
        var medicine_name = $(this).find('input[name="Medicine[]"]').val();

        // Dosage checkboxes
        var dosage = {
            morning: $(this).find('input[name="dosage[morning][]"]').is(':checked') ? 1 : 0,
            noon: $(this).find('input[name="dosage[noon][]"]').is(':checked') ? 1 : 0,
            night: $(this).find('input[name="dosage[night][]"]').is(':checked') ? 1 : 0
        };

        // Frequency dropdown
        var frequency = $(this).find('select[name="frequency[]"]').val();

        // Duration fields
        var duration_quantity = $(this).find('input[name="duration_quantity[]"]').val();
        var duration_unit = $(this).find('select[name="duration_unit[]"]').val();
//console.log('  '+duration_quantity+' '+duration_unit);
        // Only add rows with valid medicine IDs and medicine names

         var timing = $(this).find(`input[name="timing[${medicine_id}]"]:checked`).val();
        timing = (timing === undefined) ? null : parseInt(timing); 

        if (medicine_id && medicine_name) {
            rows.push({
                medicine_id: medicine_id,
                medicine_name: medicine_name,
                dosage: dosage,
                frequency: frequency,
                duration_quantity: duration_quantity,
                duration_unit: duration_unit,
                timing: timing
            });
        }
    });

    // Send data to server
    $.ajax({
        url: '<?php echo e(url("/save-treatment-medicines")); ?>',
        type: 'POST',
        data: {
            treatment_id: treatmentId,
            medicines: rows,
            _token: '<?php echo e(csrf_token()); ?>'
        },
        success: function (response) {
            //console.log(rows);
            $('#spnSaveMessage').html('Medicine saved successfully');
            saveTreatment() ;
        },
        error: function (xhr) {
            //console.log(xhr.responseText);
            alert('Error saving data: ' + xhr.responseText);
        }
    });

    //loadExistingMedicines(treatmentId);
});

    // Remove medicine row and delete from the database if the medicine exists
    $(document).on('click', '.remove-medicine', function () {
        var row = $(this).closest('tr');
        var medicineId = row.find('.medicine_id').val();

        if (medicineId) {
            $.ajax({
                url: '<?php echo e(url("/delete-treatment-medicine")); ?>',
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    treatment_id: treatmentId,
                    medicine_id: medicineId
                },
                success: function () {
                    alert('Medicine removed successfully.');
                    row.remove();
                },
                error: function (error) {
                    console.error(error);
                    alert('Error removing medicine.');
                }
            });
        } else {
            row.remove();
        }
    });

    // Load existing medicines when the page loads
    loadExistingMedicines(treatmentId);
});
/*
function start_date_change (v)
{

}
 $('#save').on('click', function () {
        this.closest('form').submit();
    });
 function app_date_change()
 {

 }*/

    function saveTreatment() 
    {
        // Gather form data
        //debugger;
        var formData = {
            _token: $('input[name=_token]').val(),
            id: $('#id').val(),
            start_date: $('#start_date').val(),
            start_time: $('#start_time').val(),
            end_date: $('#end_date').val(),
            end_time: $('#end_time').val(),
            remarks: $('#remarks').val(),
            status: $('#status').val(),
            teeth_UL: $('#teeth_UL').val(),
            teeth_UR: $('#teeth_UR').val(),
            teeth_LL: $('#teeth_LL').val(),
            teeth_LR: $('#teeth_LR').val(),
            teeth_exam: $('#teeth_exam').val(),
            next_appointment_date: $('#next_appointment_date').val(),
            NextAppointment_time: $('#NextAppointment_time').val(),
            NextAppId: $('#NextAppId').val(),
            callBy:1
        };

        // Send AJAX request to the manage_treatment_process route
        $.ajax({
            url: "<?php echo e(route('admin.manage_treatment_process')); ?>",
            type: "POST",
            data: formData,
            success: function(response) {
                $('#spnSaveMessage').html(response.message); // Show success message
                //window.location.href = "<?php echo e(url('admin/treatment')); ?>"; // Redirect to treatment list
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText); // Log error response
                alert('Error: Could not save treatment.');
            }
        });
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\prescription\resources\views/admin/edit_Treatment.blade.php ENDPATH**/ ?>