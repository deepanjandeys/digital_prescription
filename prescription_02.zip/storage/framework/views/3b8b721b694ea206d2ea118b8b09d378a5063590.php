;
<?php $__env->startSection('page_title','OralExamination'); ?>
<?php $__env->startSection('OralExamination_select','active'); ?>
<?php $__env->startSection('master_tran','master'); ?>
<?php $__env->startSection('container'); ?>

<?php if(session()->has('message')): ?>
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  <?php echo e(session('message')); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
<?php endif; ?>
<h2 class="title-1 m-b-10">Oral Examination Trash</h2>
<a href="<?php echo e(url('admin/oralExamination')); ?>" > <button type="button" class="btn btn-success"><i class="fe fe-arrow-left"></i> Go to Oral Examination</button>
</a>
         <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Name</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($list->id); ?></td>
                                                <td><?php echo e($list->OralExamination); ?></td>
                                                
                                                <td>
                                                    <a href="<?php echo e(url('admin/oralExamination/restore/')); ?>/<?php echo e($list->id); ?>" title="Restore">
                                                    <button type="button" class="btn btn-success"><i class="fe fe-upload"></i></button>
                                                    </a>
                                                    
                                                    <a href="<?php echo e(url('admin/oralExamination/forceDelete/')); ?>/<?php echo e($list->id); ?>" onclick="javascript:return confirm('Are you sure you want to permanently delete this item?');" title="permanently Delete">
                                                    <button type="button" class="btn btn-danger"><i class="fe fe-trash"></i></button>
                                                    
                                                    </a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\prescription\resources\views/admin/oralExamination-trash.blade.php ENDPATH**/ ?>