;
<?php $__env->startSection('page_title','Edit Patient'); ?>
<?php $__env->startSection('patient_select','active'); ?>
<?php $__env->startSection('master_tran','master'); ?>
<?php $__env->startSection('container'); ?>
<span class="d-none"> 
<?php if($id>0): ?>
    <?php echo e($password_required=""); ?>

    <?php echo e($password_class="d-none"); ?>

<?php else: ?>
    <?php echo e($password_required="required"); ?>

    <?php echo e($password_class=""); ?>

<?php endif; ?>
</span>
<script type="text/javascript">
function getCheckMobileUnique(value) {
    debugger;
   var id=$('#id').val(); 
   $.ajax({
    type: "POST",
    url: '<?php echo e(url("/getCheckMobileUnique")); ?>',
    data: { mobile: value,id:id,type:4, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        //console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#spnIsMobileNoUsedEarlier').html('Warning:'+obj.message);
            $('#spnIsMobileNoUsedEarlier').show();
        }
        else 
        {
            $('#spnIsMobileNoUsedEarlier').html('');
            $('#spnIsMobileNoUsedEarlier').hide();
        }
   },   
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}

</script>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>     
<h2 class="title-1 m-b-10">Edit Patient</h2>
<a href="<?php echo e(url('admin/patient')); ?>" >
<button type="button" class="btn btn-success"> <i class="fe fe-arrow-left"></i> Back</button>
</a>

<div class="row m-t-30">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(route('admin.manage_patient_process')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <!-- Other input fields ... -->
                    <div class="row">
                        <!-- First Name -->
                        <div class="col-md-6 form-group">
                            <label for="first_name" class="control-label mb-1">First Name</label>
                            <input id="first_name" name="first_name" type="text" value="<?php echo e(old('first_name', $first_name)); ?>" class="form-control" required>
                            <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Last Name -->
                        <div class="col-md-6 form-group">
                            <label for="last_name" class="control-label mb-1">Last Name</label>
                            <input id="last_name" name="last_name" type="text" value="<?php echo e(old('last_name', $last_name)); ?>" class="form-control" required>
                            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Address -->
                        <div class="col-md-6 form-group">
                            <label for="address" class="control-label mb-1">Address</label>
                            <input id="address" name="address" type="text" value="<?php echo e(old('address', $address)); ?>" class="form-control" required>
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- PIN -->
                        <div class="col-md-6 form-group">
                            <label for="pin" class="control-label mb-1">PIN</label>
                            <input id="pin" name="pin" type="text" value="<?php echo e(old('pin', $pin)); ?>" class="form-control" required>
                            <?php $__errorArgs = ['pin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Mobile -->
                        <div class="col-md-6 form-group">
                            <label for="mobile" class="control-label mb-1">Mobile</label>
                            <input id="mobile" name="mobile" type="text" value="<?php echo e(old('mobile', $mobile)); ?>" class="form-control" onchange="getCheckMobileUnique(this.value)" required>
                            <span id="spnIsMobileNoUsedEarlier" class="text-success font-weight-bold" style="display:none;"></span>
                            <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Email -->
                        <div class="col-md-6 form-group">
                            <label for="email" class="control-label mb-1">Email</label>
                            <input id="email" name="email" type="text" value="<?php echo e(old('email', $email)); ?>" class="form-control">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Gender -->
                        <div class="col-md-6 form-group">
                            <label for="gender_id" class="control-label mb-1">Gender</label>
                            <select id="gender_id" name="gender_id" class="form-control">
                                <?php $__currentLoopData = $genderes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($list->id); ?>" 
                                        <?php echo e(old('gender_id', $gender_id) == $list->id ? 'selected' : ''); ?>>
                                        <?php echo e($list->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['gender_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Age -->
                        <div class="col-md-6 form-group">
                            <label for="age" class="control-label mb-1">Age</label>
                            <input id="age" name="age" type="text" value="<?php echo e(old('age', $age)); ?>" class="form-control" >
                            <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row">
    <!-- City -->
    <div class="col-md-6 form-group">
        <label for="city" class="control-label mb-1">City</label>
        <input id="city" name="city" type="text" 
               value="<?php echo e(old('city', $city ?? 'Silchar')); ?>" 
               class="form-control">
        <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- State -->
    <div class="col-md-6 form-group">
        <label for="state" class="control-label mb-1">State</label>
        <input id="state" name="state" type="text" 
               value="<?php echo e(old('state', $state ?? 'Assam')); ?>" 
               class="form-control">
        <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="row">
    <!-- Country -->
    <div class="col-md-6 form-group">
        <label for="country" class="control-label mb-1">Country</label>
        <input id="country" name="country" type="text" 
               value="<?php echo e(old('country', $country ?? 'India')); ?>" 
               class="form-control">
        <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

                        <!-- Height -->
                        <div class="col-md-6 form-group">
                            <label for="Height" class="control-label mb-1">Height</label>
                            <input id="Height" name="Height" type="text" value="<?php echo e(old('Height', $Height)); ?>" class="form-control" >
                            <?php $__errorArgs = ['Height'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Weight -->
                        <div class="col-md-6 form-group">
                            <label for="Weight" class="control-label mb-1">Weight</label>
                            <input id="Weight" name="Weight" type="text" value="<?php echo e(old('Weight', $Weight)); ?>" class="form-control" >
                            <?php $__errorArgs = ['Weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- BP -->
                        <div class="col-md-6 form-group">
                            <label for="BP" class="control-label mb-1">BP</label>
                            <input id="BP" name="BP" type="text" value="<?php echo e(old('BP', $BP)); ?>" class="form-control" >
                            <?php $__errorArgs = ['BP'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Pulse -->
                        <div class="col-md-6 form-group">
                            <label for="Pulse" class="control-label mb-1">Pulse</label>
                            <input id="Pulse" name="Pulse" type="text" value="<?php echo e(old('Pulse', $Pulse)); ?>" class="form-control" >
                            <?php $__errorArgs = ['Pulse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- BMI -->
                        <div class="col-md-6 form-group">
                            <label for="BMI" class="control-label mb-1">BMI</label>
                            <input id="BMI" name="BMI" type="text" value="<?php echo e(old('BMI', $BMI)); ?>" class="form-control" >
                            <?php $__errorArgs = ['BMI'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row">
                        <!-- WC -->
                        <div class="col-md-6 form-group">
                            <label for="WC" class="control-label mb-1">WC</label>
                            <input id="WC" name="WC" type="text" value="<?php echo e(old('WC', $WC)); ?>" class="form-control" >
                            <?php $__errorArgs = ['WC'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Status -->
                        <div class="col-md-6 form-group">
                            <label for="status" class="control-label mb-1">Status</label>
                            <select id="status" name="status" class="form-control" >
                                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($status == $list->id): ?>
                                <option selected value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                                <?php else: ?>
                                <option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger" role="alert">
                    <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
<div>
<button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
Submit <i class="fe fe-paper-plane"></i>
</button>
</div>
<input type="hidden" name="id" id="id" value="<?php echo e($id); ?>">

</form>
</div>
</div>
</div>
</div>


<script>
    /*
    // Add click event listener to imagePreview
    document.getElementById('imagePreview').addEventListener('click', function() {
        // Simulate click on the hidden file input
        document.getElementById('image').click();
    });

    // Function to show image preview after file is selected
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function(e) {
                // Update the image preview
                document.getElementById('imagePreview').src = e.target.result;
            }
            
            reader.readAsDataURL(input.files[0]); // Read the file as a data URL
        }
    }
    */
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\prescription\resources\views/admin/edit_Patient.blade.php ENDPATH**/ ?>