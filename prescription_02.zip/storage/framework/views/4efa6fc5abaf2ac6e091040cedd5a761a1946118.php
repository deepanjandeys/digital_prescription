<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from doccure-html.dreamguystech.com/template/admin/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 09 Jan 2022 16:37:11 GMT -->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<title><?php echo e(Config::get('constants.SITE_NAME')); ?>  - Login </title>

<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/img/favicon.png')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
<!--[if lt IE 9]>
      <script src="assets/js/html5shiv.min.js"></script>
      <script src="assets/js/respond.min.js"></script>
    <![endif]-->
<script type="text/javascript">
  function validation()
  {
    var name=$('#name').val();
    var password=$('#password').val();
    var type=$('#type').val();
    var msg='';
    $('.alert-danger').html('');
    
    if(name =='')
    {
      msg ="<li>Enter User ID</li>";
    }

    if(password =='')
    {
      msg +="<li>password must not be blank</li>";
    }

    if(type=='')
    {
      msg +="<li>Type must be choose</li>";
    }

    if(msg !='')
    {
      $('#spnErrMsg').html('<div class="alert alert-danger"><ul>'+msg+'</ul></div>');
      return false;
    }
    else 
    {
      return true;
    }
  }
function forget_password()
  {
debugger;
    var type=$('#type').val();
if(type=='')
{
    $('#spnErrMsg').html('<div class="alert alert-danger"><ul><li>choose a type</li></ul></div>');
    return false;
}
else
{
     window.location='./forget_password/'+type;
}
    
    /*
    if(type=='1')
        window.location='./forget_password/1';
    else if(type=='2')    
        window.location='./forget_password/2';
    else if(type=='3')
        window.location='./forget_password/3';
      */  
  }
</script>      
</head>
<body>

<div class="slideshow-container">
  <!-- Background images slideshow -->
  <div class="background-slideshow">
    <img src="<?php echo e(asset('admin_assets/images/0.jpg')); ?>" class="slide-image">
    <img src="<?php echo e(asset('admin_assets/images/1.jpg')); ?>" class="slide-image">
    <img src="<?php echo e(asset('admin_assets/images/2.jpg')); ?>" class="slide-image">
    <img src="<?php echo e(asset('admin_assets/images/3.jpg')); ?>" class="slide-image">
    <img src="<?php echo e(asset('admin_assets/images/4.jpg')); ?>" class="slide-image">
    <img src="<?php echo e(asset('admin_assets/images/5.jpg')); ?>" class="slide-image">
    <img src="<?php echo e(asset('admin_assets/images/6.jpg')); ?>" class="slide-image">
  </div>

  <!-- Login form content -->
  <div class="main-wrapper login-body">
    <div class="login-wrapper">
      <div class="container">
        <div class="loginbox">
          <div class="login-left">
            <img class="img-fluid" src="<?php echo e(asset('assets/img/logo-white.png')); ?>" alt="Logo">
          </div>
          <div class="login-right">
            <div class="login-right-wrap">
              <h1>Login</h1>
              <p class="account-subtitle">Access to our dashboard</p>
              <!-- Login form starts here -->
              <form action="<?php echo e(route('admin.auth')); ?>" method="post" onsubmit="return validation();">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <input class="form-control" type="text" name="name" id="name" placeholder="User ID" value="<?php echo e(old('name')); ?>">
                </div>
                <div class="form-group">
                  <input class="form-control" type="password" name="password" id="password" placeholder="Password" value="<?php echo e(old('password')); ?>">
                </div>
                <div class="form-group">
                  <select class="form-control" name="type" id="type">
                    <option value="">Login Type</option>
                    <option value="3" <?php echo e(old('type') == '3' ? 'selected' : ''); ?>>Counter</option>
                    <option value="2" <?php echo e(old('type') == '2' ? 'selected' : ''); ?>>Operator</option>
                    <option value="1" <?php echo e(old('type') == '1' ? 'selected' : ''); ?>>Admin</option>
                  </select>
                </div>
                <div class="form-group">
                  <button class="btn btn-primary w-100" type="submit">Login</button>
                  <span id="spnErrMsg"></span>
                  <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                      <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                    </div>
                  <?php endif; ?>
                </div>
              </form>
              <div class="text-center forgotpass">
                <a href="javascript:void(0)" onclick="forget_password()">Forgot Password?</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
</body>

<!-- Mirrored from doccure-html.dreamguystech.com/template/admin/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 09 Jan 2022 16:37:12 GMT -->
</html><?php /**PATH E:\wamp64\www\prescription\resources\views/admin/login.blade.php ENDPATH**/ ?>