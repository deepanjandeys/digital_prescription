<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo e(Config::get('constants.SITE_NAME')); ?></title>
 </head>
<body>
  <div class="container">
    <?php echo $__env->yieldContent('content'); ?>
  </div>
  
</body>
</html><?php /**PATH E:\wamp64\www\prescription\resources\views/admin/pdf_layout.blade.php ENDPATH**/ ?>