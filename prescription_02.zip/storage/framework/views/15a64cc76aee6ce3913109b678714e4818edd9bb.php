;
<?php $__env->startSection('page_title','Edit Appointment'); ?>
<?php $__env->startSection('appointment_select','active'); ?>
<?php $__env->startSection('master_tran','master'); ?>
<?php $__env->startSection('container'); ?>
<span class="d-none"> 
<?php if($id>0): ?>
    <?php echo e($password_required=""); ?>

    <?php echo e($password_class="d-none"); ?>

<?php else: ?>
    <?php echo e($password_required="required"); ?>

    <?php echo e($password_class=""); ?>

<?php endif; ?>
</span>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>    
<style type="text/css">
   #patient_list {
    border: 1px solid #ddd;
    background-color: white;
    max-height: 150px;
    overflow-y: auto;
    width: 100%; /* Make sure it fits within the parent */
}

.patient-item {
    padding: 10px;
    cursor: pointer;
}

.patient-item:hover {
    background-color: #f0f0f0;
}
</style> 
<!-- Add this in your Blade file before your custom script -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<h2 class="title-1 m-b-10">Edit Appointment</h2>
<a href="<?php echo e(url('admin/appointment')); ?>" >
<button type="button" class="btn btn-success"> <i class="fe fe-arrow-left"></i> Back</button>
</a>
<!-- Add custom styles for the timeline -->
<style>
    .timeline {
        position: relative;
        padding: 20px 0;
        margin-top: 20px;
    }

    .timeline ul {
        padding: 0;
        list-style: none;
        position: relative;
    }

    .timeline ul li {
        display: inline-block;
        padding: 10px;
        margin-bottom: 10px;
        background: #fff;
        border: 1px solid #ddd;
        border-radius: 5px;
        position: relative;
        width: 180px;
        margin-right: 10px;
        box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1);
    }

    .timeline ul li:before {
        content: '';
        position: absolute;
        left: 50%;
        width: 2px;
        height: 100%;
        background: #ddd;
        top: 0;
        transform: translateX(-50%);
    }

    .timeline ul li span {
        display: block;
        font-size: 14px;
        margin-bottom: 5px;
        font-weight: bold;
        color: #333;
    }
</style>

<div class="row m-t-30">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(route('admin.manage_appointment_process')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <!-- Other input fields ... -->

                    <div class="row">
                        <div class="col-md-6 form-group" style="background-color:#ffe5b4;padding-top: 10px;">
                            <div class="row">
                          
                        <div class="col-md-6 form-group">
                            <label for="new_patient" class="control-label mb-1">New Patient</label>
                            <input id="new_patient" name="new_old_patient" type="radio" <?php if($id==0): ?><?php echo e('checked'); ?> <?php endif; ?> value="0">
                            
                        </div>

                        <div class="col-md-6 form-group">
                            <label for="old_patient" class="control-label mb-1">Existing Patient</label>
                            <input id="old_patient" name="new_old_patient" type="radio" <?php if($id>0): ?><?php echo e('checked'); ?> <?php endif; ?> value="1">
                        </div>
                        <hr/>
                        
                        <div class="col-md-6 form-group">
                            
                            <input id="city_search" name="city_search" type="text" value="<?php echo e(old('city_search', $city_search)); ?>" class="form-control" placeholder="search by city">
                            <?php $__errorArgs = ['city_search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="col-md-6 form-group">
                            
                            <input id="state_search" name="state_search" type="text" value="<?php echo e(old('state_search', $state_search)); ?>" class="form-control" placeholder="Search by State">
                            <?php $__errorArgs = ['state_search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <label for="patient_search" class="control-label mb-1">Search by Patient name</label>
                        <div class="col-md-12 form-group" style="position: relative;">
                            <input type="text" id="patient_search" placeholder="Type patient reg. no./name/mobile/address" autocomplete="off" class="control-label mb-1 w-100">

<!-- Container to show the search results -->
<div id="patient_list" style="position: absolute; z-index: 1000;width:100%;"></div>
                        </div>
                        </div>
                        </div>
                      
                        <div class="col-md-6 form-group">
                            <div class="row">
                                
                                <div class="col-12">
<p>Others Appointments</p>   
<div id="appointment_dates"></div>                                 
                                    
                                </div>
                            </div>
 </div>
 <div class="col-12">
    <div class="timeline">
    <ul id="appointment-timeline">
        <!-- Appointment items will be appended here dynamically -->
    </ul>
</div>
</div> 
</div>
<h6>Appointment Details</h6><hr/>
            <div class="row">
                        <div class="col-md-6 form-group">
                            <label for="app_date" class="control-label mb-1">app Date</label>
                            <input id="app_date" name="app_date" type="text" value="<?php echo e(old('app_date', $app_date_time)); ?>" class="form-control datetimepicker" required >
                            <?php $__errorArgs = ['app_date_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <span id="spnAppDateErrMsg" class="text-danger font-weight-bold"></span>
                        </div>

                        <div class="col-md-6 form-group">
                            <label for="app_time" class="control-label mb-1">App Time</label>
                            <input id="app_time" name="app_time" type="text"  
                                   value="<?php echo e(old('app_time', $app_time ? \Carbon\Carbon::parse($app_time)->format('h:i A') : '')); ?>" 
                                   class="form-control" required step="600">
                            <?php $__errorArgs = ['app_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <span id="spnAppTimeErrMsg" class="text-danger font-weight-bold"></span>
                        </div>

            </div>
            <div class="row">
                        <div class="col-md-6 form-group">
                            <label for="purpose" class="control-label mb-1">Purpose</label>
                            <input id="purpose" name="purpose" type="text" value="<?php echo e(old('purpose', $purpose)); ?>" class="form-control" required>
                            <input type="hidden" name="treatment_type" id="treatment_type" value="<?php echo e(old('treatment_type', $treatment_type)); ?>" >
                            <?php $__errorArgs = ['purpose'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <span id="spnPurposeErrMsg" class="text-danger font-weight-bold"></span>
                            <!-- Autocomplete dropdown -->
    <div id="autocomplete-results" class="autocomplete-items"></div>
<style>
    /* Style for autocomplete dropdown */
    .autocomplete-items {
        position: absolute;
        background-color: #fcf3cf;
        border: 1px solid #ddd;
        z-index: 99;
        max-height: 150px;
        overflow-y: auto;
        width: 50%;
    }
    .autocomplete-item {
        padding: 8px;
        cursor: pointer;
    }
    .autocomplete-item:hover {
        background-color: #e9e9e9;
    }
</style>

                        </div>
                        <div class="col-md-6 form-group">
                            <label for="preTreatment" class="control-label mb-1">Previous Treatment (if Any)</label>
                            <input id="preTreatment" name="preTreatment" type="text" value="<?php echo e(old('preTreatment', $preTreatment)); ?>" class="form-control" required>
                            <?php $__errorArgs = ['preTreatment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <span id="spnPreTreatmentErrMsg" class="text-danger font-weight-bold"></span>
                        </div>
            </div>
<h6>Patient Details  <span class="text-primary" id="spnRegNo"></span></h6><hr/>

                    <div class="row">
                        <!-- First Name -->
                        <div class="col-md-6 form-group">
                            <label for="first_name" class="control-label mb-1">First Name</label>
                            <input type="hidden" name="patient_id" id="patient_id" value="<?php echo e($patient_id); ?>">
                            <input id="first_name" name="first_name" type="text" value="<?php echo e(old('first_name', $first_name)); ?>" class="form-control pd" required tabindex="1">
                            <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Last Name -->
                        <div class="col-md-6 form-group">
                            <label for="last_name" class="control-label mb-1">Last Name</label>
                            <input id="last_name" name="last_name" type="text" value="<?php echo e(old('last_name', $last_name)); ?>" class="form-control pd" tabindex="2">
                            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Address -->
                        <div class="col-md-6 form-group">
                            <label for="address" class="control-label mb-1">Address</label>
                            <input id="address" name="address" type="text" value="<?php echo e(old('address', $address)); ?>" class="form-control pd" tabindex="3">
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- PIN -->
                        <div class="col-md-6 form-group">
                            <label for="pin" class="control-label mb-1">PIN</label>
                            <input id="pin" name="pin" type="text" value="<?php echo e(old('pin', $pin)); ?>" class="form-control pd" tabindex="4">
                            <?php $__errorArgs = ['pin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Mobile -->
                        <div class="col-md-6 form-group">
                            <label for="mobile" class="control-label mb-1">Mobile</label>
                            <input id="mobile" name="mobile" type="text" value="<?php echo e(old('mobile', $mobile)); ?>" class="form-control pd" onchange="getCheckMobileUnique(this.value)" required tabindex="5">
                            <span id="spnIsMobileNoUsedEarlier" class="text-success font-weight-bold" style="display:none;"></span>
                            <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Email -->
                        <div class="col-md-6 form-group">
                            <label for="email" class="control-label mb-1">Email</label>
                            <input id="email" name="email" type="text" value="<?php echo e(old('email', $email)); ?>" class="form-control pd">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Gender -->
                        <div class="col-md-6 form-group">
                            <label for="gender_id" class="control-label mb-1">Gender</label>
                            <select id="gender_id" name="gender_id" class="form-control">
                                <?php $__currentLoopData = $genderes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($list->id); ?>" 
                                        <?php echo e(old('gender_id', $gender_id) == $list->id ? 'selected' : ''); ?>>
                                        <?php echo e($list->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['gender_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Age -->
                        <div class="col-md-6 form-group">
                            <label for="age" class="control-label mb-1">Age</label>
                            <input id="age" name="age" type="text" value="<?php echo e(old('age', $age)); ?>" class="form-control pd" tabindex="6">
                            <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row">
                        <!-- City -->
                        <div class="col-md-6 form-group">
                            <label for="city" class="control-label mb-1">City</label>
                            <input id="city" name="city" type="text" value="<?php echo e(old('city', $city)); ?>" class="form-control pd" tabindex="7">
                            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- State -->
                        <div class="col-md-6 form-group">
                            <label for="state" class="control-label mb-1">State</label>
                            <input id="state" name="state" type="text" value="<?php echo e(old('state', $state)); ?>" class="form-control pd" tabindex="8">
                            <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Country -->
                        <div class="col-md-6 form-group">
                            <label for="country" class="control-label mb-1">Country</label>
                            <input id="country" name="country" type="text" value="<?php echo e(old('country', $country)); ?>" class="form-control pd" tabindex="9">
                            <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Height -->
                        <div class="col-md-6 form-group">
                            <label for="Height" class="control-label mb-1">Height</label>
                            <input id="Height" name="Height" type="text" value="<?php echo e(old('Height', $Height)); ?>" class="form-control pd">
                            <?php $__errorArgs = ['Height'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Weight -->
                        <div class="col-md-6 form-group">
                            <label for="Weight" class="control-label mb-1">Weight</label>
                            <input id="Weight" name="Weight" type="text" value="<?php echo e(old('Weight', $Weight)); ?>" class="form-control pd">
                            <?php $__errorArgs = ['Weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- BP -->
                        <div class="col-md-6 form-group">
                            <label for="BP" class="control-label mb-1">BP</label>
                            <input id="BP" name="BP" type="text" value="<?php echo e(old('BP', $BP)); ?>" class="form-control pd">
                            <?php $__errorArgs = ['BP'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Pulse -->
                        <div class="col-md-6 form-group">
                            <label for="Pulse" class="control-label mb-1">Pulse</label>
                            <input id="Pulse" name="Pulse" type="text" value="<?php echo e(old('Pulse', $Pulse)); ?>" class="form-control pd">
                            <?php $__errorArgs = ['Pulse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- BMI -->
                        <div class="col-md-6 form-group">
                            <label for="BMI" class="control-label mb-1">BMI</label>
                            <input id="BMI" name="BMI" type="text" value="<?php echo e(old('BMI', $BMI)); ?>" class="form-control pd">
                            <?php $__errorArgs = ['BMI'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row">
                        <!-- WC -->
                        <div class="col-md-6 form-group">
                            <label for="WC" class="control-label mb-1">WC</label>
                            <input id="WC" name="WC" type="text" value="<?php echo e(old('WC', $WC)); ?>" class="form-control pd">
                            <?php $__errorArgs = ['WC'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger" role="alert"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Status -->
                        <div class="col-md-6 form-group">
                            <label for="status" class="control-label mb-1">Status</label>
                            <select id="status" name="status" class="form-control pd" >
                                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($status == $list->id): ?>
                                <option selected value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                                <?php else: ?>
                                <option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger" role="alert">
                    <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
<div>
<div id="divUpdatePatient" style="display: none;background-color: #ffe5b4;padding: 10px;">
    <h6>You have make changes on patient details</h6>
    <input type="radio" name="rdbUpdatePatient" id="rdbCreateNew" value="2">
<label for="rdbCreateNew">Want to create New patient details from existing</label>
    <br/>
    <input type="radio" name="rdbUpdatePatient" id="rdbUpdatePatient" value="1">
    <label for="rdbUpdatePatient">Want to changes made on existing patient</label>
<br/>
    <input type="radio" name="rdbUpdatePatient" id="rdbDontUpdate" value="0" checked>
    <label for="rdbDontUpdate">Do not need to  Update Patient Details</label>
</div>
<button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block" tabindex="10">
Submit <i class="fe fe-paper-plane"></i>
</button>
</div>
<input type="hidden" name="id" value="<?php echo e($id); ?>">

</form>
</div>
</div>
</div>
</div>
<script type="text/javascript">
    var patientDetChange=0;
$(document).ready(function() {
    $('#patient_search').on('keyup', function() {
        let query = $(this).val();
        let city = $('#city_search').val();
        let state = $('#state_search').val();
        if (query.length > 1) {
            $.ajax({
                url: '<?php echo e(url("/search-patients")); ?>',
                type: "GET",
                data: { query: query,city:city,state:state },
                success: function(data) {
                    let patientList = $('#patient_list');
                    patientList.empty(); // Clear previous results

                    if (data.length > 0) {
                        data.forEach(function(patient) {
                            patientList.append(`<div class="patient-item" 
                                data-registration_number="${patient.registration_number}" 
                                data-id="${patient.id}" 
                                data-first_name="${patient.first_name}" 
                                data-last_name="${patient.last_name}" 
                                data-address="${patient.address}" 
                                data-pin="${patient.pin}" 
                                data-gender_id="${patient.gender_id}" 
                                data-age="${patient.age}" 
                                data-mobile="${patient.mobile}"
                                data-image="${patient.image}" 
                                data-height="${patient.Height}" 
                                data-weight="${patient.Weight}" 
                                data-bp="${patient.BP}" 
                                data-pulse="${patient.Pulse}" 
                                data-bmi="${patient.BMI}" 
                                data-wc="${patient.WC}"
                                data-city="${patient.city}" 
                                data-state="${patient.state}" 
                                data-country="${patient.country}" 
                                data-status="${patient.status}">
                               ${patient.registration_number} ${patient.first_name} ${patient.last_name} <b>(m)${patient.mobile}</b> ${patient.address}
                            </div>`);
                        });
                    } else {
                        patientList.append('<div>No results found</div>');
                    }
                }
            });
        } else {
            $('#patient_list').empty(); // Clear if query is less than 2 characters
        }
    });

    // Function to create and display the preTreatment select box
    function loadPreTreatmentSelectBox(patient_id, selectedPreTreatment = "") {
        $.ajax({
            url: `<?php echo e(url('/fetch-treatments')); ?>/${patient_id}`,
            type: "GET",
            success: function(data) {
                let treatmentSelect = '<select id="preTreatment" name="preTreatment" class="form-control">';
                treatmentSelect += '<option value="">Select Treatment Date</option>';

                data.forEach(function(treatment) {
                    const startDate = new Date(treatment.start_date_time).toLocaleDateString();
                    const endDate = new Date(treatment.end_date_time).toLocaleDateString();
                    const treatmentType = treatment.treatment_type ? treatment.treatment_type.TreatmentType : 'N/A';

                    // Check if this treatment is the saved preTreatment, and set it as selected
                    const isSelected = treatment.id == selectedPreTreatment ? 'selected' : '';

                    treatmentSelect += `<option value="${treatment.id}" ${isSelected}>
                        ${startDate} (${treatmentType}): ${treatment.remarks}
                    </option>`;
                });

                treatmentSelect += '</select>';

                // Replace the existing input box or select box with the new select box
                $('#preTreatment').replaceWith(treatmentSelect);
            },
            error: function() {
                console.log("Error fetching treatment data.");
            }
        });
    }

    // Call this function initially to load preTreatment for edit mode
    $(document).ready(function() {
        debugger;
        let selectedPreTreatment = "<?php echo e($preTreatment); ?>"; // Get the saved preTreatment from PHP
        let patient_id = "<?php echo e($patient_id); ?>"; // Get the patient ID if it's already set
        if (patient_id) {
            loadPreTreatmentSelectBox(patient_id, selectedPreTreatment);
        }
    });

    // Event listener for selecting a patient
    $(document).on('click', '.patient-item', function() {
        let patient_id = $(this).data('id');
        let registration_number = $(this).data('registration_number');
        let firstName = $(this).data('first_name');
        let lastName = $(this).data('last_name');
        let mobile = $(this).data('mobile');
        let address = $(this).data('address');
        let gender_id = $(this).data('gender_id');
        let pin = $(this).data('pin');
        // Set the selected patient's details into the respective fields
        $('#spnRegNo').html(registration_number);
        $('#patient_id').val(patient_id);
        $('#first_name').val(firstName);
        $('#last_name').val(lastName);
        $('#mobile').val(mobile);
        $('#address').val(address);
        $('#gender_id').val(gender_id);
        $('#pin').val(pin);
        // Clear the search box and results
        $('#patient_search').val('');
        $('#patient_list').empty();

        // Load preTreatment select box for the selected patient
        loadPreTreatmentSelectBox(patient_id);
    });
});

function app_date_change(date) {
    if (date.length > 1) {
        $.ajax({
            url: '<?php echo e(url("/search-appointment_dates")); ?>',
            type: "GET",
            data: { date: date },
            success: function(data) {
                let timeline = $('#appointment-timeline');
                timeline.empty(); // Clear previous results
                 let appointment_dates = $('#appointment_dates');
                        appointment_dates.empty(); 
                if (data.length > 0) {
                    //console.log(data);

                    data.forEach(function(appointment) {
                        // Extract the time part from app_date_time
                        let time = moment(appointment.app_date_time).format('HH:mm');

                        // Append appointment details to the timeline
                        timeline.append(`
                            <li>
                                <span>${time}</span> <!-- Time displayed -->
                                <strong>${appointment.purpose}</strong> <!-- Purpose of appointment -->
                                <p>Patient: ${appointment.patient.first_name} ${appointment.patient.last_name}</p>
                            </li>
                        `);

                        ////////////////
                       
                        appointment_dates.append(`<div class="appointment_date-item" 
                            data-id="${appointment.id}">
                           ${time} ${appointment.purpose}
                        </div>`);

                    });
                } else {
                    timeline.append('<li>No appointments found for this date</li>');
                }
            }
        });
    } else {
        $('#appointment-timeline').empty();
    }
}

///////////////
function isValidDate(dateStr) {
    // Regular expression to match the date format d/m/Y
    const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
    const matchArray = dateStr.match(datePattern);

    if (matchArray === null) {
        return false; // Date is not in the correct format
    }

    // Extract date parts
    const day = parseInt(matchArray[1], 10);
    const month = parseInt(matchArray[2], 10) - 1; // Months are 0-based in JavaScript
    const year = parseInt(matchArray[3], 10);

    // Create a date object and check if the date is valid
    const date = new Date(year, month, day);
    return date.getFullYear() === year && date.getMonth() === month && date.getDate() === day;
}

function isValidTime(timeStr) {
    // Regular expression to match the time format h:i A
    const timePattern = /^(0?[1-9]|1[0-2]):([0-5][0-9]) ([AP]M)$/;
    return timePattern.test(timeStr);
}


function validateDateTime(dateStr, timeStr) {
    return isValidDate(dateStr) && isValidTime(timeStr);
}

// Example usage
//console.log(validateDateTime('29/09/2024', '3:51 AM')); // true
//console.log(validateDateTime('31/02/2024', '3:51 AM')); // false

$(document).ready(function() {
    $("#app_time").on("change", function() {
        //alert("Time validation");
       if(isValidTime(this.value) ==false) 
            $('#spnAppTimeErrMsg').html('Type time in proper format <span class="text-success">Hour:Minute AM/PM</span>');
        else 
            $('#spnAppTimeErrMsg').html('');
    });

    $("#app_date").on("change", function() {
        //alert("Time validation");
       if(isValidDate(this.value) ==false) 
            $('#spnAppDateErrMsg').html('Type Date in proper format <span class="text-success">Day/Month/Year</span>');
        else 
            $('#spnAppDateErrMsg').html('');
    });

    $(".pd").on("change", function() 
    {
        var patient_id=$('#patient_id').val();
        if(patient_id>0)
            $('#divUpdatePatient').show();
    });
});


function getCheckMobileUnique(value) {
   var id=$('#id').val();
   $.ajax({
    type: "POST",
    url: '<?php echo e(url("/getCheckMobileUnique")); ?>',
    data: { mobile: value,id:id,type:4, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        //console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#spnIsMobileNoUsedEarlier').html('Warning:'+obj.message);
            $('#spnIsMobileNoUsedEarlier').show();
        }
        else 
        {
            $('#spnIsMobileNoUsedEarlier').html('');
            $('#spnIsMobileNoUsedEarlier').hide();
        }
   },   
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}
</script>

<script>
$(document).ready(function() {
    // Trigger autocomplete when the user clicks or types in the textbox
    $('#purpose').on('input click', function() {
        const query = $(this).val();
        //console.log('User query:', query); // Log the user's input

        // Check if query is not empty
        if (query.length > 0) {
            $.ajax({
                url: '<?php echo e(url("/get-treatment-types")); ?>',
                type: 'GET',
                dataType: 'json',
                success: function(data) {
                    console.log('Fetched Treatment Types:', data); // Log fetched data
                    let resultsContainer = $('#autocomplete-results');
                    resultsContainer.empty(); // Clear previous results

                    // Filter treatment types based on user input
                    const filteredData = data.filter(item =>
                        item.TreatmentType.toLowerCase().includes(query.toLowerCase())
                    );

                    if (filteredData.length > 0) {
                        // Display the autocomplete suggestions
                        filteredData.forEach(item => {
                            resultsContainer.append(`<div class="autocomplete-item" data-id="${item.id}">${item.TreatmentType}</div>`);
                        });
                        resultsContainer.show(); // Show the dropdown if there are results
                    } else {
                        resultsContainer.hide(); // Hide if no matches found
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', error); // Log any AJAX errors
                }
            });
        } else {
            $('#autocomplete-results').hide(); // Hide dropdown if input is empty
        }
    });

    // Hide dropdown on click outside
    $(document).on('click', function(event) {
        if (!$(event.target).closest('#purpose').length) {
            $('#autocomplete-results').hide();
        }
    });

    // Handle click event on an autocomplete item
    $(document).on('click', '.autocomplete-item', function() {
        const selectedValue = $(this).text();
        $('#purpose').val(selectedValue); 
        $('#treatment_type').val($(this).data('id'));
        $('#autocomplete-results').hide(); 
    });
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\prescription\resources\views/admin/edit_Appointment.blade.php ENDPATH**/ ?>