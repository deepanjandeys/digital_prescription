;
<?php $__env->startSection('page_title','Dashboard'); ?>
<?php $__env->startSection('dashboard_select','active'); ?>
<?php $__env->startSection('container'); ?>

	<div class="row">
			<h2 class="title-1 m-b-10"><?php echo e(Config::get('constants.SITE_NAME')); ?> Dashboard</h2>

        <div class="col-lg-6 d-none">
            <div class="au-card--no-shadow au-card--no-pad m-b-40">
     		</div>
         </div>

     </div>
     <div class="row">
<div class="col-xl-3 col-sm-6 col-12">
<div class="card">
<div class="card-body">
<div class="dash-widget-header">
<span class="dash-widget-icon text-primary border-primary">
<i class="fe fe-users"></i>
</span>
<div class="dash-count">
<h3><?php echo e($counters_count); ?></h3>
</div>
</div>
<div class="dash-widget-info">
<h6 class="text-muted">Counters</h6>
<div class="progress progress-sm">
<div class="progress-bar bg-primary w-50"></div>
</div>
</div>
</div>
</div>
</div>
<div class="col-xl-3 col-sm-6 col-12">
<div class="card">
<div class="card-body">
<div class="dash-widget-header">
<span class="dash-widget-icon text-success">
<i class="fe fe-credit-card"></i>
</span>
<div class="dash-count">
<h3><?php echo e($patients_count); ?></h3>
</div>
</div>
<div class="dash-widget-info">
<h6 class="text-muted">Patients</h6>
<div class="progress progress-sm">
<div class="progress-bar bg-success w-50"></div>
</div>
</div>
</div>
</div>
</div>
<div class="col-xl-3 col-sm-6 col-12">
<div class="card">
<div class="card-body">
<div class="dash-widget-header">
<span class="dash-widget-icon text-danger border-danger">
<i class="fe fe-money"></i>
</span>
<div class="dash-count">
<h3><?php if($appointments_count>0): ?> <?php echo e($appointments_complete_count); ?>/<?php echo e($appointments_count); ?>

    <?php endif; ?>
</h3>
</div>
</div>
<div class="dash-widget-info">
<h6 class="text-muted">Appointment</h6>
<?php 
if($appointments_count>0)
{
$ratio=($appointments_complete_count/$appointments_count)*100;
}
else 
{
    $ratio=0;
}
?>
<div class="progress progress-sm">
<div class="progress-bar bg-success" role="progressbar" style="width: <?php echo e($ratio); ?>%" aria-valuenow="<?php echo e($ratio); ?>" aria-valuemin="0" aria-valuemax="100"></div>
</div>
</div>
</div>
</div>
</div>
<div class="col-xl-3 col-sm-6 col-12">
<div class="card">
<div class="card-body">
<div class="dash-widget-header">
<span class="dash-widget-icon text-warning border-warning">
<i class="fe fe-folder"></i>
</span>
<div class="dash-count">
<h3>Rs 62523</h3>
</div>
</div>
<div class="dash-widget-info">
<h6 class="text-muted">Revenue</h6>
<div class="progress progress-sm">
<div class="progress-bar bg-warning w-50"></div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="row">
<div class="col-md-6 d-flex d-none">

<div class="card card-table flex-fill">
<div class="card-header">
<h4 class="card-title">Doctors List</h4>
</div>
<div class="card-body">
<div class="table-responsive">
<table class="table table-hover table-center mb-0">
<thead>
<tr>
<th>Doctor Name</th>
<th>Speciality</th>
<th>Earned</th>
<th>Reviews</th>
</tr>
</thead>
<tbody>
<tr>
<td>
<h2 class="table-avatar">
<a href="profile.html" class="avatar avatar-sm me-2"><img class="avatar-img rounded-circle" src="<?php echo e(asset('assets/img/doctors/doctor-thumb-01.jpg')); ?>" alt="User Image"></a>
<a href="profile.html">Dr. Ruby Perrin</a>
</h2>
</td>
<td>Dental</td>
<td>$3200.00</td>
<td>
<i class="fe fe-star text-warning"></i>
<i class="fe fe-star text-warning"></i>
<i class="fe fe-star text-warning"></i>
<i class="fe fe-star text-warning"></i>
<i class="fe fe-star-o text-secondary"></i>
</td>
</tr>
<tr>
<td>
<h2 class="table-avatar">
<a href="profile.html" class="avatar avatar-sm me-2"><img class="avatar-img rounded-circle" src="<?php echo e(asset('assets/img/doctors/doctor-thumb-02.jpg')); ?>" alt="User Image"></a>
<a href="profile.html">Dr. Darren Elder</a>
</h2>
</td>
<td>Dental</td>
<td>$3100.00</td>
<td>
<i class="fe fe-star text-warning"></i>
<i class="fe fe-star text-warning"></i>
<i class="fe fe-star text-warning"></i>
<i class="fe fe-star text-warning"></i>
<i class="fe fe-star-o text-secondary"></i>
</td>
</tr>
<tr>
<td>
<h2 class="table-avatar">
<a href="profile.html" class="avatar avatar-sm me-2"><img class="avatar-img rounded-circle" src="<?php echo e(asset('assets/img/doctors/doctor-thumb-03.jpg')); ?>" alt="User Image"></a>
<a href="profile.html">Dr. Deborah Angel</a>
</h2>
</td>
<td>Cardiology</td>
<td>$4000.00</td>
<td>
<i class="fe fe-star text-warning"></i>
<i class="fe fe-star text-warning"></i>
<i class="fe fe-star text-warning"></i>
<i class="fe fe-star text-warning"></i>
<i class="fe fe-star-o text-secondary"></i>
</td>
</tr>
<tr>
<td>
<h2 class="table-avatar">
<a href="profile.html" class="avatar avatar-sm me-2"><img class="avatar-img rounded-circle" src="<?php echo e(asset('assets/img/doctors/doctor-thumb-04.jpg')); ?>" alt="User Image"></a>
<a href="profile.html">Dr. Sofia Brient</a>
</h2>
</td>
<td>Urology</td>
<td>$3200.00</td>
<td>
<i class="fe fe-star text-warning"></i>
<i class="fe fe-star text-warning"></i>
<i class="fe fe-star text-warning"></i>
<i class="fe fe-star text-warning"></i>
<i class="fe fe-star-o text-secondary"></i>
</td>
</tr>
<tr>
<td>
<h2 class="table-avatar">
<a href="profile.html" class="avatar avatar-sm me-2"><img class="avatar-img rounded-circle" src="<?php echo e(asset('assets/img/doctors/doctor-thumb-05.jpg')); ?>" alt="User Image"></a>
<a href="profile.html">Dr. Marvin Campbell</a>
</h2>
</td>
<td>Orthopaedics</td>
<td>$3500.00</td>
<td>
<i class="fe fe-star text-warning"></i>
<i class="fe fe-star text-warning"></i>
<i class="fe fe-star text-warning"></i>
<i class="fe fe-star text-warning"></i>
<i class="fe fe-star-o text-secondary"></i>
</td>
</tr>
</tbody>
</table>
</div>
</div>
</div>

</div>
<!-- Add custom styles for the timeline -->
<style>
    .timeline {
        position: relative;
        padding: 20px 0;
        margin-top: 20px;
    }

    .timeline ul {
        padding: 0;
        list-style: none;
        position: relative;
    }

    .timeline ul li {
        display: inline-block;
        padding: 10px;
        margin-bottom: 10px;
        background: #fff;
        border: 1px solid #ddd;
        border-radius: 5px;
        position: relative;
        width: 180px;
        margin-right: 10px;
        box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1);
    }

    .timeline ul li:before {
        content: '';
        position: absolute;
        left: 50%;
        width: 2px;
        height: 100%;
        background: #ddd;
        top: 0;
        transform: translateX(-50%);
    }

    .timeline ul li span {
        display: block;
        font-size: 14px;
        margin-bottom: 5px;
        font-weight: bold;
        color: #333;
    }
</style>
<div class="col-12">
    <div class="timeline">
    <ul id="appointment-timeline">
        <!-- Appointment items will be appended here dynamically -->
    </ul>
</div>
</div> 
<div class="col-md-12 d-flex">

<div class="card  card-table flex-fill">
<div class="card-header row">
<h4 class="card-title col-4">Appointments List</h4>
<div class="col-4" style="text-align:right;">Filter by date</div>
<div class="col-4">
<input type="text" class="form-control datetimepicker" id="app_date" value="<?php echo date('d/m/Y'); ?>">

</div>
</div>
<div class="card-body">
<div class="table-responsive">
<table class="table table-hover table-center mb-0">
<thead>
<tr>
<th>Patient Name</th>
<th>Phone</th>
<th>Last Visit</th>
<th>Address</th>
<th>Gender / Age</th>
<th>Height</th>
<th>Weight</th>
<th>BP</th>
<th>Pulse</th>
<th>BMI</th>
<th>WC</th>
<th>Status</th>
</tr>
</thead>
<tbody id="tb_appointment_dates">
  
</tbody>
</table>
</div>
</div>
</div>

</div>
</div>

<script type="text/javascript">
function app_date_change(date) {
    //console.log('app_date_change '+date);
    if (date.length > 1) {
        $.ajax({
            url: '<?php echo e(url("/search-appointment_dates")); ?>',  // Make sure this URL is correct
            type: "GET",
            data: { date: date },
            success: function(data) {
                let appointment_dates = $('#tb_appointment_dates');
                appointment_dates.empty(); // Clear previous results

                let timeline = $('#appointment-timeline');
                timeline.empty(); // Clear previous results

                if (data.length > 0) {
                    //console.log(data);
                    //debugger;
                    data.forEach(function(appointment_date) {
                        let patient = appointment_date.patient;  // Access the related patient data
                        /*
                        let imagePath = patient && patient.image ? '<?php echo e(url("/storage/media/patients/")); ?>/'+patient.image : '<?php echo e(url("/storage/media/NoImage.png")); ?>';
                        */
// Assuming 'appointment_date.status' holds the status code
let sc = '';
let st = '';

switch (appointment_date.status) {
    case 1:
        sc = 'btn-info';
        st = 'Active';
        break;
    case 2:
        sc = 'btn-warning';
        st = 'Appeared';
        break;
    case 3:
        sc = 'btn-success';
        st = 'Start';
        break;
    case 4:
        sc = 'btn-primary';
        st = 'Complete';
        break;
    case 5:
        sc = 'btn-secondary';
        st = 'Cancel';
        break;
    default:
        sc = 'btn-secondary';
        st = 'No status';
}                       
let buttonPath = `<div class="btn-group">
    <button type="button" class="btn ${sc} dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">${st}</button>
    <div class="dropdown-menu">
        <a class="dropdown-item" href="javascript:void(0)" onclick="changeAppointmentStatus(${appointment_date.id}, 1)">Make Active</a>
        <a class="dropdown-item" href="javascript:void(0)" onclick="changeAppointmentStatus(${appointment_date.id}, 2)">Make Appeared</a>
        <a class="dropdown-item" href="javascript:void(0)" onclick="changeAppointmentStatus(${appointment_date.id}, 3)">Make Start Treatment</a>
        <a class="dropdown-item" href="javascript:void(0)" onclick="changeAppointmentStatus(${appointment_date.id}, 4)">Make Complete</a>
        <div class="dropdown-divider"></div>
        <a class="dropdown-item" href="javascript:void(0)" onclick="changeAppointmentStatus(${appointment_date.id}, 5)">Make Cancel</a>
    </div>
</div>`;

                        let gender_id=patient.gender_id;
                        var gender='';
                        if(gender_id == 0)
                        {
                            gender = 'Not Mentioned';
                        }
                    else if(gender_id == 1)
                        {
                            gender = 'Male';
                        }
                    else if(gender_id == 2)
                        {
                            gender = 'Female';
                        }
                    else if(gender_id == 3)
                        { 
                            gender = 'Transgender';
                        }
                        appointment_dates.append(`<tr>
                            <td>${patient ? patient.first_name + ' ' + patient.last_name : 'No patient data'}</td>
                            <td>${patient ? patient.mobile : 'No phone'}</td>
                            <td>${appointment_date.app_date_time}</td>
                            <td>${patient ? patient.address : 'No address'}</td>
                            <td>${patient ? gender + ' / ' + patient.age : 'No Gender/Age'}</td>
                            <td>${patient ? patient.Height : 'No height'}</td>
                            <td>${patient ? patient.Weight : 'No weight'}</td>
                            <td>${patient ? patient.BP : 'No BP'}</td>
                            <td>${patient ? patient.Pulse : 'No pulse'}</td>
                            <td>${patient ? patient.BMI : 'No BMI'}</td>
                            <td>${patient ? patient.WC : 'No WC'}</td>
                            <td>${appointment_date.purpose}</td>
                        </tr>`);

                        let time = moment(appointment_date.app_date_time).format('HH:mm');
                        let status=appointment_date.status;
                        //var sc=''; var st='';
                        if(status == 1)
                        {
                            sc = 'bg-primary'; 
                            st = 'Active';
                        }
                    else if(status == 2)
                        {
                            sc = 'bg-info'; 
                            st = 'Appeared';
                        }
                    else if(status == 3)
                        {
                            sc = 'bg-warning'; 
                            st = 'Start';
                        }
                    else if(status == 4)
                        {
                            sc = 'bg-success'; 
                            st = 'Complete';
                        }
                    else if(status == 5)
                        {
                            sc = 'bg-danger'; 
                            st = 'Cancel';
                        }
                    else 
                        {
                            sc = 'bg-secondary'; 
                            st = 'No status';
                       }
   
                        // Append appointment details to the timeline
                        timeline.append(`
                            <li class="${sc}">
                                <span>${time}</span> <!-- Time displayed -->
                                <strong>${appointment_date.purpose}</strong> <!-- Purpose of appointment -->
                                <p>Patient: ${appointment_date.patient.first_name} ${appointment_date.patient.last_name}</p>
                                 ${buttonPath}
                            </li>
                        `);
                    });
                } else {
                    appointment_dates.append('<tr><td colspan="12">No results found</td></tr>');
                }
            }
        });
    } else {
        $('#tb_appointment_dates').empty(); 
    }
}


function changeAppointmentStatus(appointmentId, status) {
    $.ajax({
        url: '<?php echo e(url("/admin/appointment/update-status")); ?>', // Set this route in your web.php
        type: 'POST',
        data: {
            _token: '<?php echo e(csrf_token()); ?>', // CSRF token for security
            appointment_id: appointmentId,
            status: status
        },
        success: function(response) {
            if (response.success) {
                //console.log(response);
                app_date_change(response.date);
                // // Find the relevant appointment list item and update its status class and text
                // let timelineItem = $('#appointment-timeline').find(`li[data-appointment-id="${appointmentId}"]`);
                // timelineItem.removeClass().addClass(response.new_class); // Apply new status class
                // timelineItem.find('.btn').removeClass().addClass(`btn ${response.new_class}`).text(response.new_status); // Update status text


            } else {
                alert('Could not update the appointment status.');
            }
        },
        error: function(xhr) {
            alert('An error occurred while updating the status.');
        }
    });
}

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\prescription\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>