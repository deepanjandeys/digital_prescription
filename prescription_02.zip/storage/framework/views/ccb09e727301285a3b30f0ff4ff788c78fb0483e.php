
<?php $__env->startSection('content'); ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@400..700&display=swap" rel="stylesheet">
<script type="text/javascript">

function PrintContent() {
    var DocumentContainer = document.getElementById('printDiv');
    var WindowObject = window.open('', 'PrintWindow', 'width=750,height=650,top=10,left=50,toolbars=no,scrollbars=yes,status=no,resizable=yes');
    WindowObject.document.writeln(DocumentContainer.innerHTML);
    WindowObject.document.close();
    WindowObject.focus();
    WindowObject.print();
    //WindowObject.close();
}
</script>
<div style="text-align: center;">
<input type="button" name="printbtn" value="Print" onClick="PrintContent()" class="btn btn-success m-2" style="background-color:blue; margin: 10px; border-radius: 20px; color: white; font-weight: bold;" />
</div>
    <center>
<div class="page" id="printDiv">
    <style>
        /* General styles for the document */
        body, html {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
        }

        /* Set A4 page dimensions */
        @page  {
            size: A4;
            margin: 0;
        }

        .page {
            display: flex;
            flex-direction: column;
            height: 297mm;
            width: 210mm;
            position: relative;
            box-sizing: border-box;
        }

        .header, .footer {
            position: absolute;
            width: 100%;
            text-align: center;
        }

        .header {
            top: 0;
            height: 100px;
        }

        .footer {
            bottom: 0;
            height: 100px;
        }

        .header img, .footer img {
            width: 100%;
            height: auto;
            max-height: 100px;
        }

        .content {
            flex: 1;
            padding-top: 110px;
            padding-bottom: 110px;
            margin: 0 15px;
            overflow: hidden;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th, td {
            padding: 8px;
            text-align: left;
            font-size: 12px;
        }

        .section-title {
            background-color: #ffd966;
            padding: 3px;
            font-weight: bold;
            -webkit-print-color-adjust: exact; /* Force print color */
            color-adjust: exact;
        }

        .small-text {
            font-size: 10px;
        }

        .page-break {
            page-break-before: always;
        }

        /* Print styling */
        @media  print {
            .print-btn {
                display: none;
            }

            .header img, .footer img {
                width: 100%;
                height: auto;
                max-height: 80px;
            }

            .content {
                padding-top: 100px;
                padding-bottom: 100px;
                box-sizing: border-box;
            }
        }
    </style>

    <div class="header">
        <img src="<?php echo e($header1); ?>" alt="Header Image">
    </div>

    <!-- Main Content -->
    <div class="content">
        <table style="width:100%;" border="1">
            <tr>
                <td style="width: 30%;" rowspan="2">
                    <div style="text-align:center;">
                        <span style="background-color:#ffc61a; color:white; padding: 5px; border: 2px double whitesmoke; border-radius: 50px; text-transform: uppercase;-webkit-print-color-adjust: exact;">
                            Clinical Notes
                        </span>
                    </div>
                    <div>
                        <!-- Medical History Section -->
                        <?php if($treatment->treatment_medical_histories->isNotEmpty()): ?>
                            <table>
                                <thead>
                                    <tr>
                                        <th class="section-title">Medical History</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $treatment->treatment_medical_histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treatmentHistory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($treatmentHistory->medical_history->MedicalHistory ?? 'No history available'); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>

                        <!-- Oral Examination Section -->
                        <?php if($treatment->treatment_oral_examinations->isNotEmpty()): ?>
                            <table>
                                <thead>
                                    <tr>
                                    <th class="section-title">Oral Examination</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $treatment->treatment_oral_examinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treatmentOralExamination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($treatmentOralExamination->oral_examination->OralExamination ?? 'No examination available'); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>

                        <!-- Advice Section -->
                        <?php if($treatment->treatment_advices->isNotEmpty()): ?>
                            <table>
                                <thead>
                                    <tr>
                                    <th class="section-title">Advice</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $treatment->treatment_advices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treatmentAdvice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($treatmentAdvice->advice->Advice ?? 'No advice available'); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>

                        <!-- Treatment Type Section -->
                        <?php if($treatment->treatmentType): ?>
                            <table>
                                <thead>
                                    <tr>
                                        <th class="section-title">Type</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><?php echo e($treatment->treatmentType->TreatmentType); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </td>
                <td style="width: 40%; vertical-align: top;">
                    <p><strong>Name:</strong> <?php echo e($first_name); ?> <?php echo e($last_name); ?> (<?php echo e($gender); ?>, <?php echo e($age); ?> years)</p>
                    <p><strong>Date & Time:</strong> <?php echo e($start_date_time); ?></p>
                </td>
                <td style="width: 30%; vertical-align: top;">
                    <p><strong>Contact:</strong> <?php echo e($mobile); ?></p>
                    <p><strong>Patient ID:</strong> <?php echo e($id); ?></p>
                </td>
            </tr>
            
            <tr>
    <td colspan="2" style="border-right:dodgerblue dashed 1px;">
        <h2>On Examination</h2>
        <table>
            <tr>
                <th colspan="2"  style="text-align:center;">
                    Teeth
                </th>
                <th  style="text-align:center;">
                    Examination
                </th>
            </tr>
            <tr>
                <td style="text-align:center;border-right: 1px solid;border-bottom: 1px solid;">
                    <?php echo e($treatment->teeth_UL); ?>

                </td>
                <td style="text-align:center;border-bottom: 1px solid;">
                   <?php echo e($treatment->teeth_UR); ?>

                </td>
                <th style="text-align:center;" rowspan="2">
                    <?php echo e($treatment->teeth_exam); ?>

                </th>
            </tr>
            <tr>
                <td style="text-align:center;border-right: 1px solid;">
                    <?php echo e($treatment->teeth_LL); ?>

                </td>
                <td style="text-align:center;">
                   <?php echo e($treatment->teeth_LR); ?>

                </td>
            </tr>
        </table>

        <?php if($treatment->treatment_advices->isNotEmpty()): ?>
    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Medicine</th>
                <th>Dosage</th>
                <th>Frequency</th>
                <th>Duration</th>
                <th>Timing</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $treatment->treatment_medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treatmentMedicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($treatmentMedicine->medicine): ?> <!-- Ensure the medicine exists -->
                    <tr>
                        <td><?php echo e($treatmentMedicine->medicine->id); ?></td>
                        <td><?php echo e($treatmentMedicine->medicine->Medicine); ?></td>
                        <td>
                        <?php
    // Decode the JSON to access the values
    $dosage = json_decode($treatmentMedicine->Dosage, true);
?>

<label>
    <input type="checkbox" <?php echo e(isset($dosage['morning']) && $dosage['morning'] == 1 ? 'checked' : ''); ?>>
</label>
<label>
    <input type="checkbox" <?php echo e(isset($dosage['noon']) && $dosage['noon'] == 1 ? 'checked' : ''); ?>>
</label>
<label>
<input type="checkbox" <?php echo e(isset($dosage['night']) && $dosage['night'] == 1 ? 'checked' : ''); ?>>
</label>
</td>
<td>
                    <?php
    $frequencyLabel = match($treatmentMedicine->frequency) {
        1 => 'Daily',
        2 => 'Weekly',
        3 => 'Monthly',
        4 => 'Yearly',
        default => 'None',
    };
?>

<label><?php echo e($frequencyLabel); ?></label>
                </td>
                <td>
                    <?php echo e($treatmentMedicine->duration_quantity); ?>

                       <?php
    $durationLabel = match((int)$treatmentMedicine->duration_unit) {
        1 => 'Days',
        2 => 'Weeks',
        3 => 'Months',
        4 => 'Years',
        default => 'None',
    };
?>

<label><?php echo e($durationLabel); ?> </label>
                </td>
                <td>
                    <label>
    <input type="checkbox" <?php echo e($treatmentMedicine->timing === 0 ? 'checked' : ''); ?>> BF
</label>
<label>
    <input type="checkbox" <?php echo e($treatmentMedicine->timing === 1 ? 'checked' : ''); ?>> AF
</label>

                    </td>
                    </tr>
                <?php else: ?>
                    <tr>
                        <td colspan="3">No medicine associated with this record.</td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php else: ?>
    <p>No advices found for this treatment.</p>
<?php endif; ?>

    </td>
</tr>

        </table>
    </div>

    <!-- Footer -->
    <div class="footer">
        <img src="<?php echo e($footer1); ?>" alt="Footer Image">
    </div>
</div>
</center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.pdf_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\prescription\resources\views/admin/print_prescription.blade.php ENDPATH**/ ?>